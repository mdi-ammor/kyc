package fr.franfinance.fae.ellisphere.ws.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import fr.franfinance.ellisphere.wsclient.application.EllisphereClient;
import fr.franfinance.ellisphere.wsclient.exception.TechnicalException;
import fr.franfinance.ellisphere.wsclient.model.Request.FaeEllisphereRequest;
import fr.franfinance.ellisphere.wsclient.model.Response.BeneficiariesResponse;

@RestController
@RequestMapping("/")
public class EllisphereWsController {

  private static final Logger LOGGER = LoggerFactory.getLogger(EllisphereWsController.class);

  /**
   * @RequestParam BeneficiariesRequest
   * @return BeneficiariesResponse
   * @throws Exception
   **/
  @RequestMapping(value = "/faeOrderEffectiveBeneficiaries", method = RequestMethod.POST, consumes = "application/json",
      produces = "application/json")
  public BeneficiariesResponse faeOrderEffectiveBeneficiaries(@RequestBody FaeEllisphereRequest faeEllisphereRequest)
      throws Exception {
    BeneficiariesResponse beneficiariesResponse = new BeneficiariesResponse();
    try {
      LOGGER
          .info("=========== LANCEMENT WEB SERVICE ELLISPHERE: siren = " + faeEllisphereRequest.getSiren() + " ===========");
      beneficiariesResponse = new EllisphereClient().faeOrderEffectiveBeneficiaries(faeEllisphereRequest);
    } catch (TechnicalException e) {
      LOGGER.error("=== TIERS INTROUVABLE ===: ", e);
    }
    LOGGER
        .info("=========== FIN WEB SERVICE ELLISPHERE ===========================================");
    return beneficiariesResponse;
  }

}

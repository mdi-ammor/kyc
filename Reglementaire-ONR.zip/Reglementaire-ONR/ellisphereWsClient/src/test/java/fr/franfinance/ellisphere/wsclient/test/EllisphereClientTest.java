package fr.franfinance.ellisphere.wsclient.test;

import java.math.BigDecimal;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.franfinance.ellisphere.wsclient.application.EllisphereClient;
import fr.franfinance.ellisphere.wsclient.model.Request.FaeEllisphereRequest;
import fr.franfinance.ellisphere.wsclient.model.Response.BeneficiariesResponse;

public class EllisphereClientTest {
  public static void main(String[] args) throws Exception {

    ObjectMapper mapper = new ObjectMapper();
    EllisphereClient ellisphereClient = new EllisphereClient();

    //Create new faeEllisphereRequest
    FaeEllisphereRequest faeEllisphereRequest = new FaeEllisphereRequest();
    faeEllisphereRequest.setSiren("352830434");
    faeEllisphereRequest.setSeuilParticipation(BigDecimal.valueOf(80.5));
    faeEllisphereRequest.setSeuilMinimalActionnariat(BigDecimal.valueOf(10));
    faeEllisphereRequest.setNumeroOde(BigDecimal.valueOf(45));
    // Call Web service FAE baseTiers : methode Get Tier
    BeneficiariesResponse beneficiariesResponse =
        ellisphereClient.faeOrderEffectiveBeneficiaries(faeEllisphereRequest);

    // Object to JSON
    String beneficiariesResponseJson = mapper.writeValueAsString(beneficiariesResponse);
    System.out.println(beneficiariesResponse);
    System.out.println(beneficiariesResponseJson);
  }
}

package fr.franfinance.ellisphere.wsclient.model.Request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;

@XmlRootElement(name = "id")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Id {

  private String type;
  private String idValue;

  @XmlAttribute(name="type")
  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  @XmlValue
  public String getIdValue() {
    return idValue;
  }

  public void setIdValue(String idValue) {
    this.idValue = idValue;
  }

  @Override
  public String toString() {
    return "Id [type=" + type + ", idValue=" + idValue + "]";
  }
}

package fr.franfinance.ellisphere.wsclient.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import fr.franfinance.ellisphere.wsclient.configuration.bean.BeanParam;

@Configuration
@PropertySources({
    @PropertySource(value = "file:${springConfigPath}/ellis-client${envTarget:}.properties",
        ignoreResourceNotFound = true),
    @PropertySource(value = "classpath:../config/ellis-client${envTarget:}.properties",
        ignoreResourceNotFound = true),
    @PropertySource(value = "classpath:/config/ellis-client${envTarget:}.properties",
        ignoreResourceNotFound = true)})
public class ApplicationConfig {

  @Value("${GET_BE_URI}")
  private String getBeUri;

  @Value("${GET_TIERS_URI}")
  private String getTiersUri;

  @Value("${UPDATE_TIERS_URI}")
  private String updateTiersUri;

  @Value("${CALL_FUNCTION_URI}")
  private String callFunctionUri;

  @Value("${CALL_CREATION_TIERS_FUNCTION_URI}")
  private String callCreationTiersFunctionUri;

  @Value("${CLIENT_CONTRACTID}")
  private String clientContractId;

  @Value("${CLIENT_USERPREFIX}")
  private String clientUserPrefix;

  @Value("${CLIENT_USERID}")
  private String clientUserId;

  @Value("${CLIENT_PASSWORD}")
  private String clientPassword;

  @Value("${CLIENT_PRIVATEREFERENCE}")
  private String clientPrivateReference;

  @Value("${APPID_VERSION}")
  private String appIdVersion;

  @Value("${APPID_APPIDVALUE}")
  private String appIdAppIdValue;

  @Value("${ID_TYPE}")
  private String idType;

  @Value("${PRODUCT_RANGE}")
  private String productRange;

  @Value("${PRODUCT_VERSION}")
  private String productVersion;

  @Value("${REQUEST_ANALYSISFORCED}")
  private String requestAnalysisForced;

  @Value("${REQUEST_DELEVERYFORMAT}")
  private String requestDeleveryFormat;

  @Value("${BENEFICIARIESREQUEST_LANG}")
  private String beneficiariesRequestLang;

  @Value("${BENEFICIARIESREQUEST_VERSION}")
  private String beneficiariesRequestVersion;

  @Value("${SIREN_AUTHORIZED_LIST}")
  private String sirenAuthorized;



  @Bean
  public BeanParam getBeanParam() {
    BeanParam param = new BeanParam();
    param.setGetBeUri(getBeUri);
    param.setGetTiersUri(getTiersUri);
    param.setUpdateTiersUri(updateTiersUri);
    param.setCallFunctionUri(callFunctionUri);
    param.setCallCreationTiersFunctionUri(callCreationTiersFunctionUri);
    param.setClientContractId(clientContractId);
    param.setClientUserPrefix(clientUserPrefix);
    param.setClientUserId(clientUserId);
    param.setClientPassword(clientPassword);
    param.setClientPrivateReference(clientPrivateReference);
    param.setAppIdVersion(appIdVersion);
    param.setAppIdAppIdValue(appIdAppIdValue);
    param.setIdType(idType);
    param.setProductRange(productRange);
    param.setProductVersion(productVersion);
    param.setRequestAnalysisForced(requestAnalysisForced);
    param.setRequestDeleveryFormat(requestDeleveryFormat);
    param.setBeneficiariesRequestLang(beneficiariesRequestLang);
    param.setBeneficiariesRequestVersion(beneficiariesRequestVersion);
    param.setSirenAuthorizedList(sirenAuthorized);

    return param;
  }
}

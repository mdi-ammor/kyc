package fr.franfinance.ellisphere.wsclient.model.Response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;
import com.fasterxml.jackson.annotation.JsonInclude;

@XmlRootElement(name = "status")
@XmlAccessorType(XmlAccessType.PROPERTY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Status {

  private String code;
  private String statusValue;

  @XmlAttribute(name = "code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  @XmlValue
  public String getStatusValue() {
    return statusValue;
  }

  public void setStatusValue(String statusValue) {
    this.statusValue = statusValue;
  }

  @Override
  public String toString() {
    return "Status [code=" + code + ", statusValue=" + statusValue + "]";
  }
}

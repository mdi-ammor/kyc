package fr.franfinance.ellisphere.wsclient.model.Response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import com.fasterxml.jackson.annotation.JsonInclude;

@XmlRootElement(name = "result")
@XmlAccessorType(XmlAccessType.PROPERTY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Result {
  private String code;
  private String majorMessage;
  private String minorMessage;
  private String additionalInfo;
  private String majorCode;
  private String minorCode;

  @XmlAttribute(name = "code")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  @XmlElement(name="majorMessage")
  public String getMajorMessage() {
    return majorMessage;
  }

  public void setMajorMessage(String majorMessage) {
    this.majorMessage = majorMessage;
  }

  @XmlElement(name="minorMessage")
  public String getMinorMessage() {
    return minorMessage;
  }

  public void setMinorMessage(String minorMessage) {
    this.minorMessage = minorMessage;
  }

  @XmlElement(name="additionalInfo")
  public String getAdditionalInfo() {
    return additionalInfo;
  }

  public void setAdditionalInfo(String additionalInfo) {
    this.additionalInfo = additionalInfo;
  }

  @XmlElement(name="majorCode")
  public String getMajorCode() {
    return majorCode;
  }

  public void setMajorCode(String majorCode) {
    this.majorCode = majorCode;
  }

  @XmlElement(name="minorCode")
  public String getMinorCode() {
    return minorCode;
  }

  public void setMinorCode(String minorCode) {
    this.minorCode = minorCode;
  }

  @Override
  public String toString() {
    return "Result [code=" + code + ", majorMessage=" + majorMessage + ", minorMessage="
        + minorMessage + ", additionalInfo=" + additionalInfo + ", majorCode=" + majorCode
        + ", minorCode=" + minorCode + "]";
  }
}

package fr.franfinance.ellisphere.wsclient.model.Request;

import java.math.BigDecimal;

public class FaeEllisphereRequest {
  private String siren;
  private BigDecimal seuilParticipation;
  private BigDecimal seuilMinimalActionnariat;
  private BigDecimal numeroOde;
  
  public String getSiren() {
    return siren;
  }
  public void setSiren(String siren) {
    this.siren = siren;
  }
  
  public BigDecimal getSeuilParticipation() {
    return seuilParticipation;
  }
  public void setSeuilParticipation(BigDecimal seuilParticipation) {
    this.seuilParticipation = seuilParticipation;
  }
  public BigDecimal getSeuilMinimalActionnariat() {
    return seuilMinimalActionnariat;
  }
  public void setSeuilMinimalActionnariat(BigDecimal seuilMinimalActionnariat) {
    this.seuilMinimalActionnariat = seuilMinimalActionnariat;
  }
  public BigDecimal getNumeroOde() {
    return numeroOde;
  }
  public void setNumeroOde(BigDecimal numeroOde) {
    this.numeroOde = numeroOde;
  }
  @Override
  public String toString() {
    return "FaeEllisphereRequest [siren=" + siren + ", seuilParticipation=" + seuilParticipation
        + ", seuilMinimalActionnariat=" + seuilMinimalActionnariat + ", numeroOde=" + numeroOde
        + "]";
  }
}

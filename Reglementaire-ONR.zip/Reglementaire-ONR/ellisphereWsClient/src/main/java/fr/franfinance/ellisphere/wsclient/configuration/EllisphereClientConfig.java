package fr.franfinance.ellisphere.wsclient.configuration;

import java.util.Arrays;
import java.util.List;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import fr.franfinance.ellisphere.wsclient.configuration.bean.BeanParam;

public class EllisphereClientConfig {

  private static AnnotationConfigApplicationContext context;

  /**
   * @return FccrRestTemplate with logging interceptor
   */
  public static RestTemplate interceptFccrRestTemplate() {

    SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
    BufferingClientHttpRequestFactory bufferingClientHttpRequestFactory =
        new BufferingClientHttpRequestFactory(requestFactory);

    RestTemplate ellisphereRestTemplate = new RestTemplate(requestFactory);
    // add handler error
    ellisphereRestTemplate.setErrorHandler(new RestErrorHandler());
    // add request factory
    ellisphereRestTemplate.setRequestFactory(bufferingClientHttpRequestFactory);
    // add interceptors
    List<ClientHttpRequestInterceptor> interceptors = Arrays.asList(new LoggingInterceptor());
    ellisphereRestTemplate.setInterceptors(interceptors);
    return ellisphereRestTemplate;
  }


  /**
   * 
   * @return Urls Bean for Ellisphere web service
   */
  public static BeanParam getUrls() {
    context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
    return context.getBean(BeanParam.class);
  }

}

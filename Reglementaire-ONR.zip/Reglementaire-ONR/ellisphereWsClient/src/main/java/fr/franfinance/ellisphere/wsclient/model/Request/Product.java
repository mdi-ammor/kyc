package fr.franfinance.ellisphere.wsclient.model.Request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "product")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Product {

  private String range;
  private String version;

  @XmlAttribute(name = "range")
  public String getRange() {
    return range;
  }

  public void setRange(String range) {
    this.range = range;
  }

  @XmlAttribute(name = "version")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  @Override
  public String toString() {
    return " [range = " + range + ", version = " + version + "]";
  }
}

package fr.franfinance.ellisphere.wsclient.model.Request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "svcEffectiveBeneficiariesRequest")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class BeneficiariesRequest {

  private Request request;
  private Admin admin;
  private String lang;
  private String version;

  @XmlElement(name="request")
  public Request getRequest() {
    return request;
  }
 
  public void setRequest(Request request) {
    this.request = request;
  }

  @XmlElement(name="admin")
  public Admin getAdmin() {
    return admin;
  }

  public void setAdmin(Admin admin) {
    this.admin = admin;
  }

  @XmlAttribute(name = "lang")
  public String getLang() {
    return lang;
  }

  public void setLang(String lang) {
    this.lang = lang;
  }

  @XmlAttribute(name = "version")
  public String getVersion() {
    return version;
  }
  
  public void setVersion(String version) {
    this.version = version;
  }

  @Override
  public String toString() {
    return "BeneficiariesRequest [request=" + request + ", admin=" + admin + ", lang=" + lang
        + ", version=" + version + "]";
  }
}

package fr.franfinance.ellisphere.wsclient.configuration;

import java.io.IOException;
import java.nio.charset.Charset;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.StreamUtils;
import fr.franfinance.ellisphere.wsclient.util.EllisphereClientConstants;

public class LoggingInterceptor implements ClientHttpRequestInterceptor {

  private static final Logger LOGGER = LoggerFactory.getLogger(LoggingInterceptor.class);

  @Override
  public ClientHttpResponse intercept(HttpRequest request, byte[] body,
      ClientHttpRequestExecution execution) throws IOException {

    logRequestDetails(request, body);
    ClientHttpResponse response = execution.execute(request, body);
    logResponseDetails(response);

    return response;
  }

  private void logRequestDetails(HttpRequest request, byte[] body) throws IOException {

    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_REQUEST_BEGIN);
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_URI, request.getURI());
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_METHOD, request.getMethod());
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_HEADER, request.getHeaders());
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_REQUEST_BODY,
        new String(body, EllisphereClientConstants.MESSAGE_LOG_ENCODING));
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_REQUEST_END);

  }

  private void logResponseDetails(ClientHttpResponse response) throws IOException {

    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_RESPONSE_BEGIN);
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_STATUS_CODE, response.getStatusCode());
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_STATUS_TEXT, response.getStatusText());
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_HEADER, response.getHeaders());
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_RESPONSE_BODY,
        StreamUtils.copyToString(response.getBody(), Charset.defaultCharset()));
    LOGGER.info(EllisphereClientConstants.MESSAGE_LOG_RESPONSE_END);

  }

}

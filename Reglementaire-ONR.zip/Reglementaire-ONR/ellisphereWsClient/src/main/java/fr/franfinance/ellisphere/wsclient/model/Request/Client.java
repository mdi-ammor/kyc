package fr.franfinance.ellisphere.wsclient.model.Request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "client")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Client {
  private String password;
  private String contractId;
  private String userPrefix;
  private String userId;
  private String privateReference;

  @XmlElement(name = "password")
  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  @XmlElement(name = "contractId")
  public String getContractId() {
    return contractId;
  }

  public void setContractId(String contractId) {
    this.contractId = contractId;
  }

  @XmlElement(name = "userPrefix")
  public String getUserPrefix() {
    return userPrefix;
  }

  public void setUserPrefix(String userPrefix) {
    this.userPrefix = userPrefix;
  }

  @XmlElement(name = "userId")
  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  @XmlElement(name = "privateReference")
  public String getPrivateReference() {
    return privateReference;
  }

  public void setPrivateReference(String privateReference) {
    this.privateReference = privateReference;
  }

  @Override
  public String toString() {
    return "Client [password=" + password + ", contractId=" + contractId + ", userPrefix="
        + userPrefix + ", userId=" + userId + "]";
  }
}

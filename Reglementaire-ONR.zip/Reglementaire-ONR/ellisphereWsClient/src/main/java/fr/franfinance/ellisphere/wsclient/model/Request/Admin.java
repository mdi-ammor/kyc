package fr.franfinance.ellisphere.wsclient.model.Request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "admin")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Admin {
  private Context context;
  private Client client;

  @XmlElement(name="context")
  public Context getContext() {
    return context;
  }

  public void setContext(Context context) {
    this.context = context;
  }

  @XmlElement(name="client")
  public Client getClient() {
    return client;
  }

  public void setClient(Client client) {
    this.client = client;
  }

  @Override
  public String toString() {
    return "Admin [context=" + context + ", client=" + client + "]";
  }
}

package fr.franfinance.ellisphere.wsclient.configuration.bean;

import java.util.Arrays;
import java.util.List;
import fr.franfinance.ellisphere.wsclient.util.EllisphereClientConstants;

/**
 * @author adeq710
 *
 */
public class BeanParam {

  private String getBeUri;
  private String getTiersUri;
  private String updateTiersUri;
  private String callFunctionUri;
  private String callCreationTiersFunctionUri;
  private String clientContractId;
  private String clientUserPrefix;
  private String clientUserId;
  private String clientPassword;
  private String clientPrivateReference;
  private String appIdVersion;
  private String appIdAppIdValue;
  private String idType;
  private String productRange;
  private String productVersion;
  private String requestAnalysisForced;
  private String requestDeleveryFormat;
  private String beneficiariesRequestLang;
  private String beneficiariesRequestVersion;
  private List<String> sirenAuthorizedList;


  public String getGetBeUri() {
    return getBeUri;
  }

  public void setGetBeUri(String getBeUri) {
    this.getBeUri = getBeUri;
  }

  public String getGetTiersUri(String siren) {
    return getTiersUri.replace("{siren}", siren);
  }

  public void setGetTiersUri(String getTiersUri) {
    this.getTiersUri = getTiersUri;
  }
  
  public String getUpdateTiersUri() {
    return updateTiersUri;
  }

  public void setUpdateTiersUri(String updateTiersUri) {
    this.updateTiersUri = updateTiersUri;
  }
  
  public String getCallFunctionUri(String refAppel) {
    return callFunctionUri.replace("{refAppel}", refAppel);
  }

  public void setCallFunctionUri(String callFunctionUri) {
    this.callFunctionUri = callFunctionUri;
  }

  public String getCallCreationTiersFunctionUri(String siren) {
    return callCreationTiersFunctionUri.replace("{siren}", siren);
  }

  public void setCallCreationTiersFunctionUri(String callCreationTiersFunctionUri) {
    this.callCreationTiersFunctionUri = callCreationTiersFunctionUri;
  }

  public String getClientContractId() {
    return clientContractId;
  }

  public void setClientContractId(String clientContractId) {
    this.clientContractId = clientContractId;
  }

  public String getClientUserPrefix() {
    return clientUserPrefix;
  }

  public void setClientUserPrefix(String clientUserPrefix) {
    this.clientUserPrefix = clientUserPrefix;
  }

  public String getClientUserId() {
    return clientUserId;
  }

  public void setClientUserId(String clientUserId) {
    this.clientUserId = clientUserId;
  }

  public String getClientPassword() {
    return clientPassword;
  }

  public void setClientPassword(String clientPassword) {
    this.clientPassword = clientPassword;
  }

  public String getClientPrivateReference() {
    return clientPrivateReference;
  }

  public void setClientPrivateReference(String clientPrivateReference) {
    this.clientPrivateReference = clientPrivateReference;
  }

  public String getAppIdVersion() {
    return appIdVersion;
  }

  public void setAppIdVersion(String appIdVersion) {
    this.appIdVersion = appIdVersion;
  }

  public String getAppIdAppIdValue() {
    return appIdAppIdValue;
  }

  public void setAppIdAppIdValue(String appIdAppIdValue) {
    this.appIdAppIdValue = appIdAppIdValue;
  }

  public String getIdType() {
    return idType;
  }

  public void setIdType(String idType) {
    this.idType = idType;
  }

  public String getProductRange() {
    return productRange;
  }

  public void setProductRange(String productRange) {
    this.productRange = productRange;
  }

  public String getProductVersion() {
    return productVersion;
  }

  public void setProductVersion(String productVersion) {
    this.productVersion = productVersion;
  }

  public String getRequestAnalysisForced() {
    return requestAnalysisForced;
  }

  public void setRequestAnalysisForced(String requestAnalysisForced) {
    this.requestAnalysisForced = requestAnalysisForced;
  }

  public String getRequestDeleveryFormat() {
    return requestDeleveryFormat;
  }

  public void setRequestDeleveryFormat(String requestDeleveryFormat) {
    this.requestDeleveryFormat = requestDeleveryFormat;
  }

  public String getBeneficiariesRequestLang() {
    return beneficiariesRequestLang;
  }

  public void setBeneficiariesRequestLang(String beneficiariesRequestLang) {
    this.beneficiariesRequestLang = beneficiariesRequestLang;
  }

  public String getBeneficiariesRequestVersion() {
    return beneficiariesRequestVersion;
  }

  public void setBeneficiariesRequestVersion(String beneficiariesRequestVersion) {
    this.beneficiariesRequestVersion = beneficiariesRequestVersion;
  }

  public List<String> getSirenAuthorizedList() {
    return sirenAuthorizedList;
  }

  public void setSirenAuthorizedList(String sirenAuthorized) {
    System.out.println(sirenAuthorized.length());
    if (sirenAuthorized == null || sirenAuthorized.isEmpty() || sirenAuthorized.length() < EllisphereClientConstants.SIREN_LENGHT) {
      this.sirenAuthorizedList = null;
    } else {
      this.sirenAuthorizedList = Arrays.asList(sirenAuthorized.split(";"));
    }
  }
  
  

}

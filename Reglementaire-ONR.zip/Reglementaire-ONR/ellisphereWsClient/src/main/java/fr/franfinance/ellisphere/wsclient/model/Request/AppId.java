package fr.franfinance.ellisphere.wsclient.model.Request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlValue;

@XmlRootElement(name = "appId")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class AppId {
  
  private String version;
  private String appIdValue;

  @XmlAttribute(name="version")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  @XmlValue
  public String getAppIdValue() {
    return appIdValue;
  }

  public void setAppIdValue(String appIdValue) {
    this.appIdValue = appIdValue;
  }

  @Override
  public String toString() {
    return "AppId [version=" + version + ", appIdValue=" + appIdValue + "]";
  }
}

package fr.franfinance.ellisphere.wsclient.model.Request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "request")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Request {

  private Product product;
  private String analysisForced;
  private Id id;
  private String deleveryFormat;
  private Integer hresholdCalculPercentage;
  private Integer hresholdPositiveResultPercentage;

  @XmlElement(name = "product")
  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  @XmlElement(name = "analysisForced")
  public String getAnalysisForced() {
    return analysisForced;
  }

  public void setAnalysisForced(String analysisForced) {
    this.analysisForced = analysisForced;
  }

  @XmlElement(name = "id")
  public Id getId() {
    return id;
  }

  public void setId(Id id) {
    this.id = id;
  }

  @XmlElement(name = "deleveryFormat")
  public String getDeleveryFormat() {
    return deleveryFormat;
  }

  public void setDeleveryFormat(String deleveryFormat) {
    this.deleveryFormat = deleveryFormat;
  }

  @XmlElement(name = "hresholdCalculPercentage")
  public Integer getHresholdCalculPercentage() {
    return hresholdCalculPercentage;
  }

  public void setHresholdCalculPercentage(Integer hresholdCalculPercentage) {
    this.hresholdCalculPercentage = hresholdCalculPercentage;
  }

  @XmlElement(name = "hresholdPositiveResultPercentage")
  public Integer getHresholdPositiveResultPercentage() {
    return hresholdPositiveResultPercentage;
  }

  public void setHresholdPositiveResultPercentage(Integer hresholdPositiveResultPercentage) {
    this.hresholdPositiveResultPercentage = hresholdPositiveResultPercentage;
  }

  @Override
  public String toString() {
    return "Request [product=" + product + ", analysisForced=" + analysisForced + ", id=" + id
        + ", deleveryFormat=" + deleveryFormat + ", hresholdCalculPercentage="
        + hresholdCalculPercentage + ", hresholdPositiveResultPercentage="
        + hresholdPositiveResultPercentage + "]";
  }

}

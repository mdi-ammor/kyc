package fr.franfinance.ellisphere.wsclient.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import fr.franfinance.ellisphere.wsclient.configuration.EllisphereClientConfig;
import fr.franfinance.ellisphere.wsclient.configuration.bean.BeanParam;
import fr.franfinance.ellisphere.wsclient.model.Request.Admin;
import fr.franfinance.ellisphere.wsclient.model.Request.AppId;
import fr.franfinance.ellisphere.wsclient.model.Request.BeneficiariesRequest;
import fr.franfinance.ellisphere.wsclient.model.Request.Client;
import fr.franfinance.ellisphere.wsclient.model.Request.Context;
import fr.franfinance.ellisphere.wsclient.model.Request.Id;
import fr.franfinance.ellisphere.wsclient.model.Request.Product;
import fr.franfinance.ellisphere.wsclient.model.Request.Request;
import fr.franfinance.ellisphere.wsclient.model.Response.BeneficiariesResponse;
import fr.franfinance.ellisphere.wsclient.model.Response.Response;
import fr.franfinance.ellisphere.wsclient.model.Response.Result;
import fr.franfinance.ellisphere.wsclient.model.Response.Status;
import fr.franfinance.fae.base.tiers.model.database.SuiviAppelEllisphere;
import fr.franfinance.fae.base.tiers.model.response.ResponseError;



public class EllisphereClientUtil {
  BeanParam params = EllisphereClientConfig.getUrls();

  /**
   * 
   * @param String
   * @return BeneficiariesResponse from orderBe method
   * @throws Exception
   */
  public BeneficiariesRequest getBeneficiariesRequestBySiren(String siren) {

    BeneficiariesRequest beneficiariesRequest = new BeneficiariesRequest();

    Admin admin = new Admin();

    Client client = new Client();
    client.setContractId(params.getClientContractId());
    client.setUserPrefix(params.getClientUserPrefix());
    client.setUserId(params.getClientUserId());
    client.setPassword(params.getClientPassword());
    client.setPrivateReference(params.getClientPrivateReference());

    Context context = new Context();
    AppId appId = new AppId();
    appId.setVersion(params.getAppIdVersion());
    appId.setAppIdValue(params.getAppIdAppIdValue());
    context.setAppId(appId);
    context.setDate(new SimpleDateFormat(EllisphereClientConstants.DATE_FORMAT).format(new Date()));

    admin.setClient(client);
    admin.setContext(context);

    Request request = new Request();

    Id id = new Id();
    id.setType(params.getIdType());
    id.setIdValue(siren);

    Product product = new Product();
    product.setRange(params.getProductRange());
    product.setVersion(params.getProductVersion());

    request.setId(id);
    request.setProduct(product);
    request.setAnalysisForced(params.getRequestAnalysisForced());
    request.setDeleveryFormat(params.getRequestDeleveryFormat());
    request.setHresholdCalculPercentage(10);
    request.setHresholdPositiveResultPercentage(80);

    beneficiariesRequest.setLang(params.getBeneficiariesRequestLang());
    beneficiariesRequest.setVersion(params.getBeneficiariesRequestVersion());
    beneficiariesRequest.setAdmin(admin);
    beneficiariesRequest.setRequest(request);

    return beneficiariesRequest;
  }

  /**
   * 
   * @param SuiviAppelEllisphereJson
   * @return BeneficiariesResponse with ENCOURS status
   */
  public BeneficiariesResponse setBeneficiariesResponseEnCours(
      SuiviAppelEllisphere dernierAppelEllishere) {
    BeneficiariesResponse beneficiariesResponse = new BeneficiariesResponse();
    Response response = new Response();
    Status status = new Status();
    Result result = new Result();
    result.setCode(dernierAppelEllishere.getCodeReponseBe());
    status.setCode(EllisphereClientConstants.ENCOURS_STATUS);
    status.setStatusValue(dernierAppelEllishere.getNoTicket());
    response.setStatus(status);
    beneficiariesResponse.setResult(result);
    beneficiariesResponse.setLang(params.getBeneficiariesRequestLang());
    beneficiariesResponse.setVersion(params.getBeneficiariesRequestVersion());
    beneficiariesResponse.setResponse(response);
    return beneficiariesResponse;
  }

  /**
   * 
   * @param ResponseError
   * @return BeneficiariesResponse with FAILURE status
   */
  public BeneficiariesResponse setBeneficiariesResponseFailure(ResponseError error) {
    BeneficiariesResponse beneficiariesResponse = new BeneficiariesResponse();
    Result result = new Result();
    result.setCode(error.getCode());
    result.setMajorMessage(error.getMessage());
    result.setAdditionalInfo("");
    beneficiariesResponse.setResult(result);
    beneficiariesResponse.setLang(params.getBeneficiariesRequestLang());
    beneficiariesResponse.setVersion(params.getBeneficiariesRequestVersion());
    return beneficiariesResponse;
  }
}

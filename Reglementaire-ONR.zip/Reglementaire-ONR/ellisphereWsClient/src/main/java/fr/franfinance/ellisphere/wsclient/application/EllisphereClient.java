package fr.franfinance.ellisphere.wsclient.application;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import fr.franfinance.ellisphere.wsclient.configuration.EllisphereClientConfig;
import fr.franfinance.ellisphere.wsclient.configuration.bean.BeanParam;
import fr.franfinance.ellisphere.wsclient.exception.TechnicalException;
import fr.franfinance.ellisphere.wsclient.model.Request.BeneficiariesRequest;
import fr.franfinance.ellisphere.wsclient.model.Request.FaeEllisphereRequest;
import fr.franfinance.ellisphere.wsclient.model.Response.BeneficiariesResponse;
import fr.franfinance.ellisphere.wsclient.util.EllisphereClientConstants;
import fr.franfinance.ellisphere.wsclient.util.EllisphereClientUtil;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;
import fr.franfinance.fae.base.tiers.model.database.SuiviAppelEllisphere;
import fr.franfinance.fae.base.tiers.utils.BtnRepoConstants;
import fr.franfinance.fae.base.tiers.model.response.ResponseError;
import fr.franfinance.fae.base.tiers.model.response.TiersResponse;

public class EllisphereClient {
  private static final Logger LOGGER = LoggerFactory.getLogger(EllisphereClient.class);
  RestTemplate ellisphereRestTemplate;
  BeanParam beanParam;


  public EllisphereClient() {
    ellisphereRestTemplate = EllisphereClientConfig.interceptFccrRestTemplate();
    beanParam = EllisphereClientConfig.getUrls();
  }

  /**
   * 
   * @param String
   * @return BeneficiariesResponse from orderBe method
   * @throws Exception
   */
  public BeneficiariesResponse faeOrderEffectiveBeneficiaries(
      FaeEllisphereRequest faeEllisphereRequest) throws Exception {

    EllisphereClient ellisphereClient = new EllisphereClient();
    BeneficiariesResponse beneficiariesResponse = new BeneficiariesResponse();
    Boolean callEllisphere = false;
    // Check authorized Siren
    if (beanParam.getSirenAuthorizedList() == null
        || beanParam.getSirenAuthorizedList().contains(faeEllisphereRequest.getSiren())) {

      // Call Web service FAE baseTiers : methode Get Tier
      TiersResponse tiersResponse = new TiersResponse();
      Integer creationResult = 0;
      try {
        tiersResponse = getTiers(faeEllisphereRequest.getSiren());

        // If Tiers does not exist in BTN : call Creation Function
        if (tiersResponse.getTiers() == null) {
          creationResult = callCreationTiersFunction(faeEllisphereRequest.getSiren());
          if (creationResult > 0) {
            // Recall getTiers method after creation
            tiersResponse = getTiers(faeEllisphereRequest.getSiren());
          } else {
            tiersResponse.setStatus(null);
            // Erreur lors de la creation nouveau tiers BTN
            LOGGER.error("=========== ERROR CREATE NEW TIERS  =========== SIREN = "
                + faeEllisphereRequest.getSiren());
            beneficiariesResponse =
                new EllisphereClientUtil().setBeneficiariesResponseFailure(new ResponseError(
                    BtnRepoConstants.DATA_ERROR_CODE, BtnRepoConstants.DATA_UPDATE_ERROR_MESSAGE));
          }
        }
      } catch (Exception e) {
        // return BeneficiariesResponse FAILURE status
        LOGGER.error("=========== ERROR GET TIERS  ===========", e);
        beneficiariesResponse = new EllisphereClientUtil().setBeneficiariesResponseFailure(
            new ResponseError(BtnRepoConstants.TECHNICAL_ERROR_CODE, BtnRepoConstants.TECHNICAL_ERROR_MESSAGE));
      }

      if (tiersResponse.getStatus() != null) {
        if (EllisphereClientConstants.SUCCESS_STATUS.equals(tiersResponse.getStatus())
            && tiersResponse.getTiers().getSuiviAppelsEllisphere().size() > 0) {
          // Check status for last Elliphere call
          SuiviAppelEllisphere dernierAppelEllishere = tiersResponse.getTiers()
              .getSuiviAppelsEllisphere().stream()
              .filter(suivi -> EllisphereClientConstants.BOOLEAN_TRUE
                  .equals(suivi.getFlagDernierAppelEllisphere()))
              .filter(
                  suivi -> EllisphereClientConstants.ENCOURS_STATUS.equals(suivi.getStatutTicket()))
              .filter(suivi -> faeEllisphereRequest.getSeuilParticipation()
                  .equals(suivi.getSeuilParticipation()))
              .findAny().orElse(null);
          if (dernierAppelEllishere != null) {
            // return BeneficiariesResponse ENCOURS status
            beneficiariesResponse =
                new EllisphereClientUtil().setBeneficiariesResponseEnCours(dernierAppelEllishere);
          } else {
            callEllisphere = true;
          }
        } else if (EllisphereClientConstants.FAILURE_STATUS.equals(tiersResponse.getStatus())) {
          // return TECHNICAL ERROR
          beneficiariesResponse =
              new EllisphereClientUtil().setBeneficiariesResponseFailure(new ResponseError(
                  BtnRepoConstants.TECHNICAL_ERROR_CODE, BtnRepoConstants.TECHNICAL_ERROR_MESSAGE));
        } else {
          callEllisphere = true;
        }
      } else if (creationResult != -1) {
        // return BeneficiariesResponse FAILURE status
        LOGGER.error("=========== ERROR GET TIERS BEFORE CALLING ELLISPHERE WS =========== SIREN = "
            + faeEllisphereRequest.getSiren());
        beneficiariesResponse =
            new EllisphereClientUtil().setBeneficiariesResponseFailure(new ResponseError(
                BtnRepoConstants.TECHNICAL_ERROR_CODE, BtnRepoConstants.TECHNICAL_ERROR_MESSAGE));
      }
      if (callEllisphere) {
        // Call Web service distant ellisphere : methode Get BE
        Date dateAppelWsEllis = new Date();
        beneficiariesResponse = ellisphereClient.getBe(faeEllisphereRequest.getSiren());

        Date dateRetAppelWsEllis = new Date();
        // Update table SuiviAppelEllisphere, Call Web service FAE baseTiers : methode Update Tier
        NotationRefTier notationRefTier =
            new DozerBeanMapper().map(tiersResponse.getTiers(), NotationRefTier.class);
        // Set flag to false to all existing calls
        notationRefTier.getSuiviAppelsEllisphere()
            .forEach(suivi -> suivi.setFlagDernierAppelEllisphere(false));
        // Create new call Ellisphere
        SuiviAppelEllisphere newAppelEllisphere = new SuiviAppelEllisphere();

        newAppelEllisphere.setDateAppelWsEllis(dateAppelWsEllis);
        newAppelEllisphere.setDateRetAppelWsEllis(dateRetAppelWsEllis);
        newAppelEllisphere.setFlagDernierAppelEllisphere(true);

        newAppelEllisphere.setSiren(faeEllisphereRequest.getSiren());
        newAppelEllisphere.setIdTiersBnot(BigDecimal.valueOf(notationRefTier.getIdTiersBnot()));
        newAppelEllisphere.setSeuilParticipation(faeEllisphereRequest.getSeuilParticipation());
        newAppelEllisphere
            .setSeuilMinActionnariat(faeEllisphereRequest.getSeuilMinimalActionnariat());
        newAppelEllisphere.setNoOde(faeEllisphereRequest.getNumeroOde());

        if (beneficiariesResponse.getResponse() != null) {
          newAppelEllisphere
              .setCodeRetAppelWsEllis(beneficiariesResponse.getResponse().getStatus().getCode());
          newAppelEllisphere
              .setNoTicket(beneficiariesResponse.getResponse().getStatus().getStatusValue());
          newAppelEllisphere.setStatutTicket(EllisphereClientConstants.ENCOURS_STATUS);
        } else {
          newAppelEllisphere
              .setCodeRetAppelWsEllis(beneficiariesResponse.getResult().getMajorCode());
          newAppelEllisphere.setStatutTicket(EllisphereClientConstants.FAILURE_STATUS);
        }
        newAppelEllisphere.setStatutAppelWsEllis(beneficiariesResponse.getResult().getCode());
        // Add new call to the list
        notationRefTier.getSuiviAppelsEllisphere().add(newAppelEllisphere);
        // Update Tiers
        updateTiers(notationRefTier);
      }
    } else {
      // return BeneficiariesResponse FAILURE status
      LOGGER.error("=========== UNAUTHORIZED DATA ACCESS ===========  SIREN = "
          + faeEllisphereRequest.getSiren());
      beneficiariesResponse = new EllisphereClientUtil().setBeneficiariesResponseFailure(
          new ResponseError(BtnRepoConstants.UNAUTHORIZED_DATA_ACCESS_CODE,
              BtnRepoConstants.UNAUTHORIZED_DATA_ACCESS_MESSAGE));
    }
    return beneficiariesResponse;
  }

  /**
   * 
   * @param String
   * @return BeneficiariesResponse from orderBe method
   * @throws Exception
   */
  public BeneficiariesResponse getBe(String siren) throws Exception {
    BeneficiariesResponse response = new BeneficiariesResponse();
    try {
      // add Header and request
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_XML);
      HttpEntity<BeneficiariesRequest> entity = new HttpEntity<>(
          new EllisphereClientUtil().getBeneficiariesRequestBySiren(siren), headers);
      // call Ellisphere remote web service - method POST order BE
      ResponseEntity<BeneficiariesResponse> httpResponse = ellisphereRestTemplate
          .postForEntity(beanParam.getGetBeUri(), entity, BeneficiariesResponse.class);
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      LOGGER.error("=========== ERROR GET BE ELLISPHERE ===========", e);
    }
    return response;
  }

  /**
   * 
   * @param String
   * @return Tiers from getTiers method of baseTiers Fae Web Service
   * @throws Exception
   */
  public TiersResponse getTiers(String siren) throws Exception {
    TiersResponse response = new TiersResponse();
    try {
      // add Header and request
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
      // construct the GET URL
      String getTiersUri = beanParam.getGetTiersUri(siren);
      // call BaseTiers FAE web service - method GET getTiers
      ResponseEntity<TiersResponse> httpResponse =
          ellisphereRestTemplate.getForEntity(getTiersUri, TiersResponse.class);
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      LOGGER.error("=========== ERROR GET TIERS ===========", e);
    }
    return response;
  }

  /**
   * 
   * @param NotationRefTier
   * @return Tiers from updateTiers method of baseTiers Fae Web Service
   * @throws Exception
   */
  public TiersResponse updateTiers(NotationRefTier notationRefTier) throws Exception {
    TiersResponse response = new TiersResponse();
    try {
      // add Header and request
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
      HttpEntity<NotationRefTier> entity = new HttpEntity<>(notationRefTier, headers);
      // construct the UPDATE URL
      String getTiersUri = beanParam.getUpdateTiersUri();
      // call BaseTiers FAE web service - method UPDATE getTiers
      ResponseEntity<TiersResponse> httpResponse =
          ellisphereRestTemplate.postForEntity(getTiersUri, entity, TiersResponse.class);
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      LOGGER.error("=========== ERROR UPDATE TIERS ===========", e);
    }
    return response;
  }


  /**
   * 
   * @param Integer
   * @return Integer from callFunction method of baseTiers Fae Web Service
   * @throws Exception
   */
  public Integer callFunction(Long refAppel) throws Exception {
    Integer response = 0;
    try {
      // add Header and request
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
      // construct the GET URL
      String callFunctionUri = beanParam.getCallFunctionUri(refAppel.toString());

      // call BaseTiers FAE web service - method GET callFunction
      ResponseEntity<Integer> httpResponse =
          ellisphereRestTemplate.getForEntity(callFunctionUri, Integer.class);
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      LOGGER.error("=========== ERROR CALL FLUX TIERS FUNCTION ===========", e);
    }
    return response;
  }

  /**
   * 
   * @param Integer
   * @return Integer from callFunction method of baseTiers Fae Web Service
   * @throws Exception
   */
  public Integer callCreationTiersFunction(String siren) throws Exception {
    Integer response = 0;
    try {
      // add Header and request
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
      // construct the GET URL
      String callCreationTiersFunctionUri = beanParam.getCallCreationTiersFunctionUri(siren);

      // call BaseTiers FAE web service - method GET callCreationTiersFunctionUri
      ResponseEntity<Integer> httpResponse =
          ellisphereRestTemplate.getForEntity(callCreationTiersFunctionUri, Integer.class);
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      LOGGER.error("=========== ERROR CALL CREATION TIERS FUNCTION ===========", e);
    }
    return response;
  }
}

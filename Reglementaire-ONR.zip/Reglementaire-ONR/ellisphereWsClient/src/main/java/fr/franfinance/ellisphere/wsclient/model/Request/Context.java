package fr.franfinance.ellisphere.wsclient.model.Request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "context")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Context {

  private String date;
  private AppId appId;

  @XmlElement(name = "date")
  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  @XmlElement(name = "appId")
  public AppId getAppId() {
    return appId;
  }

  public void setAppId(AppId appId) {
    this.appId = appId;
  }

  @Override
  public String toString() {
    return "Context [date=" + date + ", appId=" + appId + "]";
  }
}

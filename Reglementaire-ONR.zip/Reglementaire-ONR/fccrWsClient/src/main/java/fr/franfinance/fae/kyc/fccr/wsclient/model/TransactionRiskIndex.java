package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;
import java.util.List;

public class TransactionRiskIndex implements Serializable {

  private static final long serialVersionUID = 1L;

  private List<IndexTransactionRisk> indexes = null;
  private String level;
  private Boolean levelDefaultIndicator;
  private Integer score;
  private Integer value;

  public String getLevel() {
    return level;
  }

  public void setLevel(String level) {
    this.level = level;
  }

  public Boolean getLevelDefaultIndicator() {
    return levelDefaultIndicator;
  }

  public void setLevelDefaultIndicator(Boolean levelDefaultIndicator) {
    this.levelDefaultIndicator = levelDefaultIndicator;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(Integer score) {
    this.score = score;
  }

  public Integer getValue() {
    return value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }

  public List<IndexTransactionRisk> getIndexes() {
    return indexes;
  }

  public void setIndexes(List<IndexTransactionRisk> indexes) {
    this.indexes = indexes;
  }

  @Override
  public String toString() {
    return "TransactionRiskIndex [indexes=" + indexes + ", level=" + level
        + ", levelDefaultIndicator=" + levelDefaultIndicator + ", score=" + score + ", value="
        + value + "]";
  }

}

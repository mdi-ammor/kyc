package fr.franfinance.fae.kyc.fccr.wsclient.model.response;

import java.util.List;
import fr.franfinance.fae.kyc.fccr.wsclient.model.Errors;
import fr.franfinance.fae.kyc.fccr.wsclient.model.Warnings;

public class CustomerResponse {

  private Customer customer;
  private List<Errors> errors;
  private String status;
  private List<Warnings> warnings;

  public Customer getCustomer() {
    return customer;
  }

  public void setCustomer(Customer customer) {
    this.customer = customer;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public List<Errors> getErrors() {
    return errors;
  }

  public void setErrors(List<Errors> errors) {
    this.errors = errors;
  }

  public List<Warnings> getWarnings() {
    return warnings;
  }

  public void setWarnings(List<Warnings> warnings) {
    this.warnings = warnings;
  }

  @Override
  public String toString() {
    return "CustomerResponse [customer=" + customer + ", errors=" + errors + ", status=" + status
        + ", warnings=" + warnings + "]";
  }

}

package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class User implements Serializable {

  private static final long serialVersionUID = 1L;
  private String applicationId;
  private String userid;
  private String username;
  private String division;
  private String organizationalEntityId;
  private String organizationalEntityName;
  private String organizationalPerimeter;

  public String getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
  }

  public String getUserid() {
    return userid;
  }

  public void setUserid(String userid) {
    this.userid = userid;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getDivision() {
    return division;
  }

  public void setDivision(String division) {
    this.division = division;
  }

  public String getOrganizationalEntityId() {
    return organizationalEntityId;
  }

  public void setOrganizationalEntityId(String organizationalEntityId) {
    this.organizationalEntityId = organizationalEntityId;
  }

  public String getOrganizationalEntityName() {
    return organizationalEntityName;
  }

  public void setOrganizationalEntityName(String organizationalEntityName) {
    this.organizationalEntityName = organizationalEntityName;
  }

  public String getOrganizationalPerimeter() {
    return organizationalPerimeter;
  }

  public void setOrganizationalPerimeter(String organizationalPerimeter) {
    this.organizationalPerimeter = organizationalPerimeter;
  }

  @Override
  public String toString() {
    return "User [applicationId=" + applicationId + ", userid=" + userid + ", username=" + username
        + ", division=" + division + ", organizationalEntityId=" + organizationalEntityId
        + ", organizationalEntityName=" + organizationalEntityName + ", organizationalPerimeter="
        + organizationalPerimeter + "]";
  }

}

package fr.franfinance.fae.kyc.fccr.wsclient.configuration;

import java.io.IOException;
import java.nio.charset.Charset;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.ResponseErrorHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.franfinance.fae.kyc.fccr.wsclient.exception.TechnicalException;
import fr.franfinance.fae.kyc.fccr.wsclient.model.Error;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;

@Component
public class RestErrorHandler implements ResponseErrorHandler {

  ObjectMapper mapper = new ObjectMapper();

  @Override
  public boolean hasError(ClientHttpResponse httpResponse) throws IOException {

    return (httpResponse.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR
        || httpResponse.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR);
  }

  @Override
  public void handleError(ClientHttpResponse httpResponse) throws IOException {

    if (httpResponse.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR) {
      // Handle SERVER_ERROR
      throw new TechnicalException(FccrClientConstants.SERVICE_UNAVAILABLE_EXCEPTION,
          FccrClientConstants.SERVICE_UNAVAILABLE_MESSAGE);
    } else if (httpResponse.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR) {
      if (httpResponse.getStatusCode() == HttpStatus.NOT_FOUND) {
        // Handle PAGE_NOT_FOUND
        throw new TechnicalException(FccrClientConstants.NOT_FOUND_EXCEPTION,
            StreamUtils.copyToString(httpResponse.getBody(), Charset.defaultCharset()));
        // Handle TOKEN_ERROR
      } else if (httpResponse.getStatusCode() == HttpStatus.UNAUTHORIZED) {
        Error error = mapper.readValue(
            StreamUtils.copyToString(httpResponse.getBody(), Charset.defaultCharset()),
            Error.class);
        throw new TechnicalException(error.getError().toUpperCase(), error.getErrorDescription());
      }
    }
  }
}

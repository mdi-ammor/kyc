package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;
import java.util.List;

public class IndexTransactionRisk implements Serializable {

  private static final long serialVersionUID = 1L;

  private List<String> countries = null;
  private String family;
  private String finalAggregateRisk;
  private Integer index;
  private Integer normalization;
  private Integer numbers;
  private Integer weight;

  public List<String> getCountries() {
    return countries;
  }

  public void setCountries(List<String> countries) {
    this.countries = countries;
  }

  public String getFamily() {
    return family;
  }

  public void setFamily(String family) {
    this.family = family;
  }

  public String getFinalAggregateRisk() {
    return finalAggregateRisk;
  }

  public void setFinalAggregateRisk(String finalAggregateRisk) {
    this.finalAggregateRisk = finalAggregateRisk;
  }

  public Integer getIndex() {
    return index;
  }

  public void setIndex(Integer index) {
    this.index = index;
  }

  public Integer getNormalization() {
    return normalization;
  }

  public void setNormalization(Integer normalization) {
    this.normalization = normalization;
  }

  public Integer getNumbers() {
    return numbers;
  }

  public void setNumbers(Integer numbers) {
    this.numbers = numbers;
  }

  public Integer getWeight() {
    return weight;
  }

  public void setWeight(Integer weight) {
    this.weight = weight;
  }

  @Override
  public String toString() {
    return "IndexTransactionRisk [countries=" + countries + ", family=" + family
        + ", finalAggregateRisk=" + finalAggregateRisk + ", index=" + index + ", normalization="
        + normalization + ", numbers=" + numbers + ", weight=" + weight + "]";
  }

}

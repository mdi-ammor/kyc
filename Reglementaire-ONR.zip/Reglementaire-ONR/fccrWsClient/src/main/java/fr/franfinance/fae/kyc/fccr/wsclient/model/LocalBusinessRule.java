package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;
import java.util.List;

public class LocalBusinessRule implements Serializable {

  private static final long serialVersionUID = 1L;

	private String description;
	private String id;
	private List<LocalBusinessRuleRiskFactor> impactedRiskFactors = null;
	private String minimumLevelOfRating;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public List<LocalBusinessRuleRiskFactor> getImpactedRiskFactors() {
		return impactedRiskFactors;
	}

	public void setImpactedRiskFactors(List<LocalBusinessRuleRiskFactor> impactedRiskFactors) {
		this.impactedRiskFactors = impactedRiskFactors;
	}

	public String getMinimumLevelOfRating() {
		return minimumLevelOfRating;
	}

	public void setMinimumLevelOfRating(String minimumLevelOfRating) {
		this.minimumLevelOfRating = minimumLevelOfRating;
	}

	@Override
	public String toString() {
		return "LocalBusinessRule [description=" + description + ", id=" + id + ", impactedRiskFactors="
				+ impactedRiskFactors + ", minimumLevelOfRating=" + minimumLevelOfRating + "]";
	}

}

package fr.franfinance.fae.kyc.fccr.wsclient.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Error {
  
  @JsonProperty("error")
  private String error;
  @JsonProperty("error_description")
  private String errorDescription;

  public String getError() {
    return error;
  }

  public void setError(String error) {
    this.error = error;
  }

  public String getErrorDescription() {
    return errorDescription;
  }

  public void setErrorDescription(String errorDescription) {
    this.errorDescription = errorDescription;
  }

  @Override
  public String toString() {
    return "Error [error=" + error + ", errorDescription=" + errorDescription + "]";
  }

}

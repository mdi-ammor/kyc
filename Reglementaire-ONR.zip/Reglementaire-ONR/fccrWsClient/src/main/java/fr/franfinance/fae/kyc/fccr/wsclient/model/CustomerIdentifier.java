package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class CustomerIdentifier implements Serializable {

  private static final long serialVersionUID = 1L;

  private String countryCode;
  private String localCountryCode;
  private String localDb;
  private String localId;
  private String rctId;

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getLocalCountryCode() {
    return localCountryCode;
  }

  public void setLocalCountryCode(String localCountryCode) {
    this.localCountryCode = localCountryCode;
  }

  public String getLocalDb() {
    return localDb;
  }

  public void setLocalDb(String localDb) {
    this.localDb = localDb;
  }

  public String getLocalId() {
    return localId;
  }

  public void setLocalId(String localId) {
    this.localId = localId;
  }

  public String getRctId() {
    return rctId;
  }

  public void setRctId(String rctId) {
    this.rctId = rctId;
  }

@Override
public String toString() {
	return "CustomerIdentifier [countryCode=" + countryCode + ", localCountryCode=" + localCountryCode + ", localDb="
			+ localDb + ", localId=" + localId + ", rctId=" + rctId + "]";
}
  
}

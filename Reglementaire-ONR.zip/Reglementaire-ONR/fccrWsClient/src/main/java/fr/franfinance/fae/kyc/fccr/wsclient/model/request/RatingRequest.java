/**
 * 
 */
package fr.franfinance.fae.kyc.fccr.wsclient.model.request;

import fr.franfinance.fae.kyc.fccr.wsclient.model.LocalBusinessRules;
import fr.franfinance.fae.kyc.fccr.wsclient.model.RatingRawData;

/**
 * @author adeq685
 *
 */
public class RatingRequest {

	private String dateTime;
	private LocalBusinessRules localBusinessRules;
	private RatingRawData rawData;
	private String userRatingStatus;

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public LocalBusinessRules getLocalBusinessRules() {
		return localBusinessRules;
	}

	public void setLocalBusinessRules(LocalBusinessRules localBusinessRules) {
		this.localBusinessRules = localBusinessRules;
	}

	

	public RatingRawData getRawData() {
		return rawData;
	}

	public void setRawData(RatingRawData rawData) {
		this.rawData = rawData;
	}

	public String getUserRatingStatus() {
		return userRatingStatus;
	}

	public void setUserRatingStatus(String userRatingStatus) {
		this.userRatingStatus = userRatingStatus;
	}

	@Override
	public String toString() {
		return "RatingRequest [dateTime=" + dateTime + ", localBusinessRules=" + localBusinessRules + ", rawData="
				+ rawData + ", userRatingStatus=" + userRatingStatus + "]";
	}
	

}

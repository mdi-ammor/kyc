package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class ErecaAuditInfo implements Serializable {

  private static final long serialVersionUID = 1L;
  private String erecaCountryCollectionTime;
  private String erecaNafCollectionTime;
  private String erecaProductCollectionTime;

  public String getErecaCountryCollectionTime() {
    return erecaCountryCollectionTime;
  }

  public void setErecaCountryCollectionTime(String erecaCountryCollectionTime) {
    this.erecaCountryCollectionTime = erecaCountryCollectionTime;
  }

  public String getErecaNafCollectionTime() {
    return erecaNafCollectionTime;
  }

  public void setErecaNafCollectionTime(String erecaNafCollectionTime) {
    this.erecaNafCollectionTime = erecaNafCollectionTime;
  }

  public String getErecaProductCollectionTime() {
    return erecaProductCollectionTime;
  }

  public void setErecaProductCollectionTime(String erecaProductCollectionTime) {
    this.erecaProductCollectionTime = erecaProductCollectionTime;
  }

  @Override
  public String toString() {
    return "ErecaAuditInfo [erecaCountryCollectionTime=" + erecaCountryCollectionTime
        + ", erecaNafCollectionTime=" + erecaNafCollectionTime + ", erecaProductCollectionTime="
        + erecaProductCollectionTime + "]";
  }
}

package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class RatingStatus implements Serializable {

  private static final long serialVersionUID = 1L;

  private User user;
  private String statusCode;
  private String statusTime;

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  public String getStatusCode() {
    return statusCode;
  }

  public void setStatusCode(String statusCode) {
    this.statusCode = statusCode;
  }

  public String getStatusTime() {
    return statusTime;
  }

  public void setStatusTime(String statusTime) {
    this.statusTime = statusTime;
  }

  @Override
  public String toString() {
    return "RatingStatus [user=" + user + ", statusCode=" + statusCode + ", statusTime="
        + statusTime + "]";
  }

}

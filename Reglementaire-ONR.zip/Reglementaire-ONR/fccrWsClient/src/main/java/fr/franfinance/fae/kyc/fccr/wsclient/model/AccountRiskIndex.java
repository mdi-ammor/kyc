package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;
import java.util.List;

public class AccountRiskIndex implements Serializable {

  private static final long serialVersionUID = 1L;

  private List<IndexAccountRisk> indexes = null;
  private String level;
  private Boolean levelDefaultIndicator;
  private Integer score;
  private Integer value;

  public List<IndexAccountRisk> getIndexes() {
    return indexes;
  }

  public void setIndexes(List<IndexAccountRisk> indexes) {
    this.indexes = indexes;
  }

  public String getLevel() {
    return level;
  }

  public void setLevel(String level) {
    this.level = level;
  }

  public Boolean getLevelDefaultIndicator() {
    return levelDefaultIndicator;
  }

  public void setLevelDefaultIndicator(Boolean levelDefaultIndicator) {
    this.levelDefaultIndicator = levelDefaultIndicator;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(Integer score) {
    this.score = score;
  }

  public Integer getValue() {
    return value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return "AccountRiskIndex [indexes=" + indexes + ", level=" + level + ", levelDefaultIndicator="
        + levelDefaultIndicator + ", score=" + score + ", value=" + value + "]";
  }

}

package fr.franfinance.fae.kyc.fccr.wsclient.model.response;

import java.io.Serializable;
import java.util.List;
import fr.franfinance.fae.kyc.fccr.wsclient.model.ErecaAuditInfo;
import fr.franfinance.fae.kyc.fccr.wsclient.model.LocalBusinessRules;
import fr.franfinance.fae.kyc.fccr.wsclient.model.RatingStatus;
import fr.franfinance.fae.kyc.fccr.wsclient.model.RatingRawData;
import fr.franfinance.fae.kyc.fccr.wsclient.model.RatingResultResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.User;
import fr.franfinance.fae.kyc.fccr.wsclient.model.Warnings;

public class RatingResponse implements Serializable {

  private static final long serialVersionUID = 1L;
  private String appVersion;
  private Integer customerId;
  private String dateTime;
  private ErecaAuditInfo erecaAuditInfo;
  private List<String> errors;
  private String fcrPerimeter;
  private Integer id;
  private LocalBusinessRules localBusinessRules;
  private String methodologyLevel;
  private String methodologyVersion;
  private String parametersName;
  private List<RatingStatus> ratingStatus = null;
  private RatingRawData rawData;
  private String referencePeriod;
  private RatingResultResponse result;
  private String reviewStatusDateTime;
  private Integer runId;
  private String status;
  private String type;
  private User user;
  private String userRatingStatus;
  private List<Warnings> warnings = null;

  public String getAppVersion() {
    return appVersion;
  }

  public void setAppVersion(String appVersion) {
    this.appVersion = appVersion;
  }

  public Integer getCustomerId() {
    return customerId;
  }

  public void setCustomerId(Integer customerId) {
    this.customerId = customerId;
  }

  public String getDateTime() {
    return dateTime;
  }

  public void setDateTime(String dateTime) {
    this.dateTime = dateTime;
  }

  public ErecaAuditInfo getErecaAuditInfo() {
    return erecaAuditInfo;
  }

  public void setErecaAuditInfo(ErecaAuditInfo erecaAuditInfo) {
    this.erecaAuditInfo = erecaAuditInfo;
  }

  public List<String> getErrors() {
    return errors;
  }

  public void setErrors(List<String> errors) {
    this.errors = errors;
  }

  public String getFcrPerimeter() {
    return fcrPerimeter;
  }

  public void setFcrPerimeter(String fcrPerimeter) {
    this.fcrPerimeter = fcrPerimeter;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public LocalBusinessRules getLocalBusinessRules() {
    return localBusinessRules;
  }

  public void setLocalBusinessRules(LocalBusinessRules localBusinessRules) {
    this.localBusinessRules = localBusinessRules;
  }

  public String getMethodologyLevel() {
    return methodologyLevel;
  }

  public void setMethodologyLevel(String methodologyLevel) {
    this.methodologyLevel = methodologyLevel;
  }

  public String getMethodologyVersion() {
    return methodologyVersion;
  }

  public void setMethodologyVersion(String methodologyVersion) {
    this.methodologyVersion = methodologyVersion;
  }

  public String getParametersName() {
    return parametersName;
  }

  public void setParametersName(String parametersName) {
    this.parametersName = parametersName;
  }

  public List<RatingStatus> getRatingStatus() {
    return ratingStatus;
  }

  public void setRatingStatus(List<RatingStatus> ratingStatus) {
    this.ratingStatus = ratingStatus;
  }

  public RatingRawData getRawData() {
    return rawData;
  }

  public void setRawData(RatingRawData rawData) {
    this.rawData = rawData;
  }

  public String getReferencePeriod() {
    return referencePeriod;
  }

  public void setReferencePeriod(String referencePeriod) {
    this.referencePeriod = referencePeriod;
  }

  public RatingResultResponse getResult() {
    return result;
  }

  public void setResult(RatingResultResponse result) {
    this.result = result;
  }

  public String getReviewStatusDateTime() {
    return reviewStatusDateTime;
  }

  public void setReviewStatusDateTime(String reviewStatusDateTime) {
    this.reviewStatusDateTime = reviewStatusDateTime;
  }

  public Integer getRunId() {
    return runId;
  }

  public void setRunId(Integer runId) {
    this.runId = runId;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public String getUserRatingStatus() {
    return userRatingStatus;
  }

  public void setUserRatingStatus(String userRatingStatus) {
    this.userRatingStatus = userRatingStatus;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public List<Warnings> getWarnings() {
    return warnings;
  }

  public void setWarnings(List<Warnings> warnings) {
    this.warnings = warnings;
  }

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  @Override
  public String toString() {
    return "RatingResponse [appVersion=" + appVersion + ", customerId=" + customerId + ", dateTime="
        + dateTime + ", erecaAuditInfo=" + erecaAuditInfo + ", errors=" + errors + ", fcrPerimeter="
        + fcrPerimeter + ", id=" + id + ", localBusinessRules=" + localBusinessRules
        + ", methodologyLevel=" + methodologyLevel + ", methodologyVersion=" + methodologyVersion
        + ", parametersName=" + parametersName + ", ratingStatus=" + ratingStatus + ", rawData="
        + rawData + ", referencePeriod=" + referencePeriod + ", result=" + result
        + ", reviewStatusDateTime=" + reviewStatusDateTime + ", runId=" + runId + ", status="
        + status + ", type=" + type + ", user=" + user + ", userRatingStatus=" + userRatingStatus
        + ", warnings=" + warnings + "]";
  }
}

package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class AssetManager implements Serializable {

  private static final long serialVersionUID = 1L;

  private String assetManagerLegalName;
  private String assetManagerLocalDb;
  private String assetManagerLocalId;
  private String assetManagerRatingDate;
  private String assetManagerRatingLevel;

  public String getAssetManagerLegalName() {
    return assetManagerLegalName;
  }

  public void setAssetManagerLegalName(String assetManagerLegalName) {
    this.assetManagerLegalName = assetManagerLegalName;
  }

  public String getAssetManagerLocalDb() {
    return assetManagerLocalDb;
  }

  public void setAssetManagerLocalDb(String assetManagerLocalDb) {
    this.assetManagerLocalDb = assetManagerLocalDb;
  }

  public String getAssetManagerLocalId() {
    return assetManagerLocalId;
  }

  public void setAssetManagerLocalId(String assetManagerLocalId) {
    this.assetManagerLocalId = assetManagerLocalId;
  }

  public String getAssetManagerRatingDate() {
    return assetManagerRatingDate;
  }

  public void setAssetManagerRatingDate(String assetManagerRatingDate) {
    this.assetManagerRatingDate = assetManagerRatingDate;
  }

  public String getAssetManagerRatingLevel() {
    return assetManagerRatingLevel;
  }

  public void setAssetManagerRatingLevel(String assetManagerRatingLevel) {
    this.assetManagerRatingLevel = assetManagerRatingLevel;
  }

  @Override
  public String toString() {
    return "AssetManager [assetManagerLegalName=" + assetManagerLegalName + ", assetManagerLocalDb="
        + assetManagerLocalDb + ", assetManagerLocalId=" + assetManagerLocalId
        + ", assetManagerRatingDate=" + assetManagerRatingDate + ", assetManagerRatingLevel="
        + assetManagerRatingLevel + "]";
  }

}

package fr.franfinance.fae.kyc.fccr.wsclient.model;

public class Errors {
  private String code;
  private String message;
  
  public Errors() {
  }

  public Errors(String code, String message) {
    this.code = code;
    this.message = message;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  @Override
  public String toString() {
    return "Errors [code=" + code + ", message=" + message + "]";
  }

}

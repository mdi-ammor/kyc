package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class IndexAccountRisk implements Serializable {

  private static final long serialVersionUID = 1L;

  private Integer count;
  private String productCode;
  private Integer rw;
  private String subfamilyCode;
  private Integer value;

  public Integer getCount() {
    return count;
  }

  public void setCount(Integer count) {
    this.count = count;
  }

  public String getProductCode() {
    return productCode;
  }

  public void setProductCode(String productCode) {
    this.productCode = productCode;
  }

  public Integer getRw() {
    return rw;
  }

  public void setRw(Integer rw) {
    this.rw = rw;
  }

  public String getSubfamilyCode() {
    return subfamilyCode;
  }

  public void setSubfamilyCode(String subfamilyCode) {
    this.subfamilyCode = subfamilyCode;
  }

  public Integer getValue() {
    return value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return "IndexAccountRisk [count=" + count + ", productCode=" + productCode + ", rw=" + rw
        + ", subfamilyCode=" + subfamilyCode + ", value=" + value + "]";
  }

}

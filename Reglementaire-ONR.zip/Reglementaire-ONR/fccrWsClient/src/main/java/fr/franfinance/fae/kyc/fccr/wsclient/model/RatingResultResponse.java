package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class RatingResultResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  private AccountRiskIndex accountRiskIndex;
  private ApprovedStockExchange approvedStockExchange;
  private AssetManagerResult assetManager;
  private Citizenship citizenship;
  private CitizenshipAndResidence citizenshipAndResidence;
  private ContractingRisk contractingRisk;
  private ContractingRiskCrossBorder contractingRiskCrossBorder;
  private CorrespondentBanking correspondentBanking;
  private EntityType entityType;
  private ExpectedActivity expectedActivity;
  private String fccrRating;
  private String fccrRatingComment;
  private FundType fundType;
  private Integer globalScore;
  private GovernmentCountry governmentCountry;
  private GovernmentOwnership governmentOwnership;
  private Industry industry;
  private InvestmentIndustry investmentIndustry;
  private LengthOfBusinessRelationship lengthOfBusinessRelationship;
  private String localBusinessRuleId;
  private String localBusinessRuleDescription;
  private NegativeNews negativeNews;
  private NestedAccount nestedAccount;
  private NewCustomer newCustomer;
  private NewEnterprise newEnterprise;
  private OperationsCountry operationsCountry;
  private String overLoadedRating;
  private Pep pep;
  private PepAndGovernmentOwnership pepAndGovernmentOwnership;
  private InvestmentCountry primaryInvestmentCountry;
  private PrimaryRegulatoryBody primaryRegulatoryBody;
  private PriorSars priorSars;
  private PriorSarsV2 priorSarsV2;
  private Registration registration;
  private RegistrationAndOperations registrationAndOperations;
  private Residence residence;
  private Sanctions sanctions;
  private TransactionRiskIndex transactionRiskIndex;

  public AccountRiskIndex getAccountRiskIndex() {
    return accountRiskIndex;
  }

  public void setAccountRiskIndex(AccountRiskIndex accountRiskIndex) {
    this.accountRiskIndex = accountRiskIndex;
  }

  public ApprovedStockExchange getApprovedStockExchange() {
    return approvedStockExchange;
  }

  public void setApprovedStockExchange(ApprovedStockExchange approvedStockExchange) {
    this.approvedStockExchange = approvedStockExchange;
  }

  public AssetManagerResult getAssetManager() {
    return assetManager;
  }

  public void setAssetManager(AssetManagerResult assetManager) {
    this.assetManager = assetManager;
  }

  public Citizenship getCitizenship() {
    return citizenship;
  }

  public void setCitizenship(Citizenship citizenship) {
    this.citizenship = citizenship;
  }

  public CitizenshipAndResidence getCitizenshipAndResidence() {
    return citizenshipAndResidence;
  }

  public void setCitizenshipAndResidence(CitizenshipAndResidence citizenshipAndResidence) {
    this.citizenshipAndResidence = citizenshipAndResidence;
  }

  public ContractingRisk getContractingRisk() {
    return contractingRisk;
  }

  public void setContractingRisk(ContractingRisk contractingRisk) {
    this.contractingRisk = contractingRisk;
  }

  public ContractingRiskCrossBorder getContractingRiskCrossBorder() {
    return contractingRiskCrossBorder;
  }

  public void setContractingRiskCrossBorder(ContractingRiskCrossBorder contractingRiskCrossBorder) {
    this.contractingRiskCrossBorder = contractingRiskCrossBorder;
  }

  public CorrespondentBanking getCorrespondentBanking() {
    return correspondentBanking;
  }

  public void setCorrespondentBanking(CorrespondentBanking correspondentBanking) {
    this.correspondentBanking = correspondentBanking;
  }

  public EntityType getEntityType() {
    return entityType;
  }

  public void setEntityType(EntityType entityType) {
    this.entityType = entityType;
  }

  public ExpectedActivity getExpectedActivity() {
    return expectedActivity;
  }

  public void setExpectedActivity(ExpectedActivity expectedActivity) {
    this.expectedActivity = expectedActivity;
  }

  public String getFccrRating() {
    return fccrRating;
  }

  public void setFccrRating(String fccrRating) {
    this.fccrRating = fccrRating;
  }

  public String getFccrRatingComment() {
    return fccrRatingComment;
  }

  public void setFccrRatingComment(String fccrRatingComment) {
    this.fccrRatingComment = fccrRatingComment;
  }

  public FundType getFundType() {
    return fundType;
  }

  public void setFundType(FundType fundType) {
    this.fundType = fundType;
  }

  public Integer getGlobalScore() {
    return globalScore;
  }

  public void setGlobalScore(Integer globalScore) {
    this.globalScore = globalScore;
  }

  public GovernmentCountry getGovernmentCountry() {
    return governmentCountry;
  }

  public void setGovernmentCountry(GovernmentCountry governmentCountry) {
    this.governmentCountry = governmentCountry;
  }

  public GovernmentOwnership getGovernmentOwnership() {
    return governmentOwnership;
  }

  public void setGovernmentOwnership(GovernmentOwnership governmentOwnership) {
    this.governmentOwnership = governmentOwnership;
  }

  public Industry getIndustry() {
    return industry;
  }

  public void setIndustry(Industry industry) {
    this.industry = industry;
  }

  public InvestmentIndustry getInvestmentIndustry() {
    return investmentIndustry;
  }

  public void setInvestmentIndustry(InvestmentIndustry investmentIndustry) {
    this.investmentIndustry = investmentIndustry;
  }

  public LengthOfBusinessRelationship getLengthOfBusinessRelationship() {
    return lengthOfBusinessRelationship;
  }

  public void setLengthOfBusinessRelationship(
      LengthOfBusinessRelationship lengthOfBusinessRelationship) {
    this.lengthOfBusinessRelationship = lengthOfBusinessRelationship;
  }

  public String getLocalBusinessRuleId() {
    return localBusinessRuleId;
  }

  public void setLocalBusinessRuleId(String localBusinessRuleId) {
    this.localBusinessRuleId = localBusinessRuleId;
  }

  public String getLocalBusinessRuleDescription() {
    return localBusinessRuleDescription;
  }

  public void setLocalBusinessRuleDescription(String localBusinessRuleDescription) {
    this.localBusinessRuleDescription = localBusinessRuleDescription;
  }

  public NegativeNews getNegativeNews() {
    return negativeNews;
  }

  public void setNegativeNews(NegativeNews negativeNews) {
    this.negativeNews = negativeNews;
  }

  public NestedAccount getNestedAccount() {
    return nestedAccount;
  }

  public void setNestedAccount(NestedAccount nestedAccount) {
    this.nestedAccount = nestedAccount;
  }

  public NewCustomer getNewCustomer() {
    return newCustomer;
  }

  public void setNewCustomer(NewCustomer newCustomer) {
    this.newCustomer = newCustomer;
  }

  public NewEnterprise getNewEnterprise() {
    return newEnterprise;
  }

  public void setNewEnterprise(NewEnterprise newEnterprise) {
    this.newEnterprise = newEnterprise;
  }

  public OperationsCountry getOperationsCountry() {
    return operationsCountry;
  }

  public void setOperationsCountry(OperationsCountry operationsCountry) {
    this.operationsCountry = operationsCountry;
  }

  public String getOverLoadedRating() {
    return overLoadedRating;
  }

  public void setOverLoadedRating(String overLoadedRating) {
    this.overLoadedRating = overLoadedRating;
  }

  public Pep getPep() {
    return pep;
  }

  public void setPep(Pep pep) {
    this.pep = pep;
  }

  public PepAndGovernmentOwnership getPepAndGovernmentOwnership() {
    return pepAndGovernmentOwnership;
  }

  public void setPepAndGovernmentOwnership(PepAndGovernmentOwnership pepAndGovernmentOwnership) {
    this.pepAndGovernmentOwnership = pepAndGovernmentOwnership;
  }

  public InvestmentCountry getPrimaryInvestmentCountry() {
    return primaryInvestmentCountry;
  }

  public void setPrimaryInvestmentCountry(InvestmentCountry primaryInvestmentCountry) {
    this.primaryInvestmentCountry = primaryInvestmentCountry;
  }

  public PrimaryRegulatoryBody getPrimaryRegulatoryBody() {
    return primaryRegulatoryBody;
  }

  public void setPrimaryRegulatoryBody(PrimaryRegulatoryBody primaryRegulatoryBody) {
    this.primaryRegulatoryBody = primaryRegulatoryBody;
  }

  public PriorSars getPriorSars() {
    return priorSars;
  }

  public void setPriorSars(PriorSars priorSars) {
    this.priorSars = priorSars;
  }

  public PriorSarsV2 getPriorSarsV2() {
    return priorSarsV2;
  }

  public void setPriorSarsV2(PriorSarsV2 priorSarsV2) {
    this.priorSarsV2 = priorSarsV2;
  }

  public Registration getRegistration() {
    return registration;
  }

  public void setRegistration(Registration registration) {
    this.registration = registration;
  }

  public RegistrationAndOperations getRegistrationAndOperations() {
    return registrationAndOperations;
  }

  public void setRegistrationAndOperations(RegistrationAndOperations registrationAndOperations) {
    this.registrationAndOperations = registrationAndOperations;
  }

  public Residence getResidence() {
    return residence;
  }

  public void setResidence(Residence residence) {
    this.residence = residence;
  }

  public Sanctions getSanctions() {
    return sanctions;
  }

  public void setSanctions(Sanctions sanctions) {
    this.sanctions = sanctions;
  }

  public TransactionRiskIndex getTransactionRiskIndex() {
    return transactionRiskIndex;
  }

  public void setTransactionRiskIndex(TransactionRiskIndex transactionRiskIndex) {
    this.transactionRiskIndex = transactionRiskIndex;
  }

  @Override
  public String toString() {
    return "RatingResultResponse [accountRiskIndex=" + accountRiskIndex + ", approvedStockExchange="
        + approvedStockExchange + ", assetManager=" + assetManager + ", citizenship=" + citizenship
        + ", citizenshipAndResidence=" + citizenshipAndResidence + ", contractingRisk="
        + contractingRisk + ", contractingRiskCrossBorder=" + contractingRiskCrossBorder
        + ", correspondentBanking=" + correspondentBanking + ", entityType=" + entityType
        + ", expectedActivity=" + expectedActivity + ", fccrRating=" + fccrRating
        + ", fccrRatingComment=" + fccrRatingComment + ", fundType=" + fundType + ", globalScore="
        + globalScore + ", governmentCountry=" + governmentCountry + ", governmentOwnership="
        + governmentOwnership + ", industry=" + industry + ", investmentIndustry="
        + investmentIndustry + ", lengthOfBusinessRelationship=" + lengthOfBusinessRelationship
        + ", localBusinessRuleId=" + localBusinessRuleId + ", localBusinessRuleDescription="
        + localBusinessRuleDescription + ", negativeNews=" + negativeNews + ", nestedAccount="
        + nestedAccount + ", newCustomer=" + newCustomer + ", newEnterprise=" + newEnterprise
        + ", operationsCountry=" + operationsCountry + ", overLoadedRating=" + overLoadedRating
        + ", pep=" + pep + ", pepAndGovernmentOwnership=" + pepAndGovernmentOwnership
        + ", primaryInvestmentCountry=" + primaryInvestmentCountry + ", primaryRegulatoryBody="
        + primaryRegulatoryBody + ", priorSars=" + priorSars + ", priorSarsV2=" + priorSarsV2
        + ", registration=" + registration + ", registrationAndOperations="
        + registrationAndOperations + ", residence=" + residence + ", sanctions=" + sanctions
        + ", transactionRiskIndex=" + transactionRiskIndex + "]";
  }
}

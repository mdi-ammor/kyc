package fr.franfinance.fae.kyc.fccr.wsclient.configuration;

import java.util.Arrays;
import java.util.List;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.bean.HeaderBean;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.bean.UriBean;
import fr.franfinance.fae.kyc.fccr.wsclient.exception.TechnicalException;
import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerIdentifier;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;

public class FccrRestClientConfig {

  private static AnnotationConfigApplicationContext context;

  /**
   * @return FccrRestTemplate with logging interceptor
   */
  public static RestTemplate interceptFccrRestTemplate() {

    SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
    BufferingClientHttpRequestFactory bufferingClientHttpRequestFactory =
        new BufferingClientHttpRequestFactory(requestFactory);
    requestFactory.setOutputStreaming(false);

    RestTemplate fccrRestTemplate = new RestTemplate();
    // add handler error
    fccrRestTemplate.setErrorHandler(new RestErrorHandler());
    // add request factory
    fccrRestTemplate.setRequestFactory(bufferingClientHttpRequestFactory);
    // add interceptors
    List<ClientHttpRequestInterceptor> interceptors = Arrays.asList(new LoggingInterceptor());
    fccrRestTemplate.setInterceptors(interceptors);
    // Add Converter
    MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
    // Ignore null fields in JSON
    ObjectMapper mapper = new ObjectMapper().setSerializationInclusion(Include.NON_NULL);
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    converter.setObjectMapper(mapper);
    fccrRestTemplate.setMessageConverters(Arrays.asList(converter));

    return fccrRestTemplate;

  }

  /**
   * 
   * @return a Header with user and basic access authentication informations
   */
  public static HttpHeaders createHttpHeaders(String token) {

    HttpHeaders headers = new HttpHeaders();
    context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
    HeaderBean header = context.getBean(HeaderBean.class);
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    headers.set(FccrClientConstants.USER_STRING, header.getUserId());
    headers.add(FccrClientConstants.AUTHORIZATION_STRING, token);

    return headers;
  }

  /**
   * 
   * @return token as a String Bearer Authorization
   */
  public static FccrToken loginAndGetAccessToken() {
    FccrToken token = new FccrToken();
    try {
      context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
      HeaderBean header = context.getBean(HeaderBean.class);
      
      ClientCredentialsResourceDetails details = new ClientCredentialsResourceDetails();
      // Set Credentials from properties FILE
      details.setClientId(header.getClientId());
      details.setClientSecret(header.getClientSecret());
      details.setAccessTokenUri(header.getTokenUri());

      DefaultOAuth2ClientContext clientContext = new DefaultOAuth2ClientContext();
      OAuth2RestTemplate restTemplate = new OAuth2RestTemplate(details, clientContext);
      restTemplate.setMessageConverters(Arrays.asList(new MappingJackson2HttpMessageConverter()));
      // Set Token fields
      token.setAccessToken(restTemplate.getAccessToken().toString());
      token.setTokenType(restTemplate.getAccessToken().getTokenType());
      token.setExpiresIn(restTemplate.getAccessToken().getExpiresIn());
      token.setExpirationDate(restTemplate.getAccessToken().getExpiration());
      token.setScope(restTemplate.getAccessToken().getScope());
    } catch (HttpServerErrorException e) {
      // Handle SERVER_ERROR
      throw new TechnicalException(FccrClientConstants.SERVICE_UNAVAILABLE_EXCEPTION,
          FccrClientConstants.SERVICE_UNAVAILABLE_MESSAGE);
    }
    return token;

  }

  /**
   * 
   * @return URI with parameters for ratings GET method
   */
  public static String getRatingsURI(CustomerIdentifier customerId) {

    context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
    UriBean uri = context.getBean(UriBean.class);
    UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uri.getReadRatingsUri());

    builder.queryParam(FccrClientConstants.CUSTOMER_IDENTIFIER_LOCAL_ID, customerId.getLocalId());
    builder.queryParam(FccrClientConstants.CUSTOMER_IDENTIFIER_LOCAL_DB, customerId.getLocalDb());
    builder.queryParam(FccrClientConstants.CUSTOMER_IDENTIFIER_RCT_ID, customerId.getRctId());
    builder.queryParam(FccrClientConstants.CUSTOMER_IDENTIFIER_COUNTRY_CODE,
        customerId.getCountryCode());
    builder.queryParam(FccrClientConstants.CUSTOMER_IDENTIFIER_LOCAL_COUNTRY_CODE,
        customerId.getLocalCountryCode());

    return builder.toUriString();

  }

  /**
   * 
   * @return Urls Bean for CALCULATOR web service
   */
  public static UriBean getUrls() {

    context = new AnnotationConfigApplicationContext(ApplicationConfig.class);

    return context.getBean(UriBean.class);
  }

}

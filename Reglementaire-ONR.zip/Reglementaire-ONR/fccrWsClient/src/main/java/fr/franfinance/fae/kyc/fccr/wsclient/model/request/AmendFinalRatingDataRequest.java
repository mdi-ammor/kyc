package fr.franfinance.fae.kyc.fccr.wsclient.model.request;

public class AmendFinalRatingDataRequest {
  private FccrRatingRequest amendedRating;
  private String ratingStatus;

  public FccrRatingRequest getAmendedRating() {
    return amendedRating;
  }

  public void setAmendedRating(FccrRatingRequest amendedRating) {
    this.amendedRating = amendedRating;
  }

  public String getRatingStatus() {
    return ratingStatus;
  }

  public void setRatingStatus(String ratingStatus) {
    this.ratingStatus = ratingStatus;
  }

  @Override
  public String toString() {
    return "AmendFinalRatingDataRequest [amendedRating=" + amendedRating + ", ratingStatus="
        + ratingStatus + "]";
  }
}

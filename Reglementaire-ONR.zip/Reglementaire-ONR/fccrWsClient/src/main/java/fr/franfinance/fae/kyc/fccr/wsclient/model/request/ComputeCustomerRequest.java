/**
 * 
 */
package fr.franfinance.fae.kyc.fccr.wsclient.model.request;

import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerData;
import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerIdentifier;

/**
 * @author adeq685
 *
 */
public class ComputeCustomerRequest {
	
	private CustomerData customerData;
	private CustomerIdentifier customerIdentifier;
	private RatingRequest rating;
	private String ratingStatus;
	
	
	public CustomerData getCustomerData() {
		return customerData;
	}
	public void setCustomerData(CustomerData customerData) {
		this.customerData = customerData;
	}
	public CustomerIdentifier getCustomerIdentifier() {
		return customerIdentifier;
	}
	public void setCustomerIdentifier(CustomerIdentifier customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}
	public RatingRequest getRating() {
		return rating;
	}
	public void setRating(RatingRequest rating) {
		this.rating = rating;
	}
	public String getRatingStatus() {
		return ratingStatus;
	}
	public void setRatingStatus(String ratingStatus) {
		this.ratingStatus = ratingStatus;
	}
	
	@Override
	public String toString() {
		return "ComputeCustomerRequest [customerData=" + customerData + ", customerIdentifier=" + customerIdentifier
				+ ", rating=" + rating + ", ratingStatus=" + ratingStatus + "]";
	}
	
	
}

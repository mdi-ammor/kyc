package fr.franfinance.fae.kyc.fccr.wsclient.exception;

import java.util.ArrayList;
import java.util.List;
import fr.franfinance.fae.kyc.fccr.wsclient.model.Errors;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;

public class TechnicalException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private String code;
  private String message;

  public TechnicalException(String code, String message) {
    this.code = code;
    this.message = message;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public FccrToken getTokenException() {
    FccrToken response = new FccrToken();
    Errors errors = new Errors(code, message);
    response.setErrors(errors);
    return response;
  }
  
  public CustomerResponse getTechnicalException() {
    CustomerResponse response = new CustomerResponse();
    Errors errors = new Errors(code, message);
    List<Errors> errorList = new ArrayList<>();
    errorList.add(errors);
    response.setErrors(errorList);
    response.setStatus(FccrClientConstants.FAILURE_STATUS);
    return response;
  }

  @Override
  public String toString() {
    return "InternalServerErrorException [code=" + code + ", message=" + message + "]";
  }
}

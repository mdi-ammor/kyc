package fr.franfinance.fae.kyc.fccr.wsclient.model.response;

import java.io.Serializable;
import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerData;
import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerIdentifier;

public class Customer implements Serializable {

  private static final long serialVersionUID = 1L;
  
  private RatingResponse amendedRating;
  private Integer id;
  private CustomerIdentifier customerIdentifier;
  private CustomerData customerData;
  private RatingResponse rating;

  public RatingResponse getAmendedRating() {
    return amendedRating;
  }

  public void setAmendedRating(RatingResponse amendedRating) {
    this.amendedRating = amendedRating;
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public CustomerIdentifier getCustomerIdentifier() {
    return customerIdentifier;
  }

  public void setCustomerIdentifier(CustomerIdentifier customerIdentifier) {
    this.customerIdentifier = customerIdentifier;
  }

  public CustomerData getCustomerData() {
    return customerData;
  }

  public void setCustomerData(CustomerData customerData) {
    this.customerData = customerData;
  }


  public RatingResponse getRating() {
    return rating;
  }

  public void setRating(RatingResponse rating) {
    this.rating = rating;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public String toString() {
    return "Customer [amendedRating=" + amendedRating + ", id=" + id + ", customerIdentifier="
        + customerIdentifier + ", customerData=" + customerData + ", rating=" + rating + "]";
  }

}

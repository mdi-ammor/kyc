package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class CustomerData implements Serializable {

  private static final long serialVersionUID = 1L;
  private String birthCity;
  private String birthCountry;
  private String birthDate;
  private String dateOfInitialBusinessRelationship;
  private String firstName;
  private String fundAssetManagerId;
  private String gender;
  private String lastName;
  private String legalName;
  private String leiCode;
  private String localBirthCountry;
  private String localRegistrationId;
  private String roc;
  private String zipCode;
  private String customerStatus;

  public String getBirthCity() {
    return birthCity;
  }

  public void setBirthCity(String birthCity) {
    this.birthCity = birthCity;
  }

  public String getBirthCountry() {
    return birthCountry;
  }

  public void setBirthCountry(String birthCountry) {
    this.birthCountry = birthCountry;
  }

  public String getBirthDate() {
    return birthDate;
  }

  public void setBirthDate(String birthDate) {
    this.birthDate = birthDate;
  }

  public String getDateOfInitialBusinessRelationship() {
    return dateOfInitialBusinessRelationship;
  }

  public void setDateOfInitialBusinessRelationship(String dateOfInitialBusinessRelationship) {
    this.dateOfInitialBusinessRelationship = dateOfInitialBusinessRelationship;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getFundAssetManagerId() {
    return fundAssetManagerId;
  }

  public void setFundAssetManagerId(String fundAssetManagerId) {
    this.fundAssetManagerId = fundAssetManagerId;
  }

  public String getGender() {
    return gender;
  }

  public void setGender(String gender) {
    this.gender = gender;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getLegalName() {
    return legalName;
  }

  public void setLegalName(String legalName) {
    this.legalName = legalName;
  }

  public String getLeiCode() {
    return leiCode;
  }

  public void setLeiCode(String leiCode) {
    this.leiCode = leiCode;
  }

  public String getLocalBirthCountry() {
    return localBirthCountry;
  }

  public void setLocalBirthCountry(String localBirthCountry) {
    this.localBirthCountry = localBirthCountry;
  }

  public String getLocalRegistrationId() {
    return localRegistrationId;
  }

  public void setLocalRegistrationId(String localRegistrationId) {
    this.localRegistrationId = localRegistrationId;
  }

  public String getRoc() {
    return roc;
  }

  public void setRoc(String roc) {
    this.roc = roc;
  }

  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  public String getCustomerStatus() {
    return customerStatus;
  }

  public void setCustomerStatus(String customerStatus) {
    this.customerStatus = customerStatus;
  }

  @Override
  public String toString() {
    return "CustomerData [birthCity=" + birthCity + ", birthCountry=" + birthCountry
        + ", birthDate=" + birthDate + ", dateOfInitialBusinessRelationship="
        + dateOfInitialBusinessRelationship + ", firstName=" + firstName + ", fundAssetManagerId="
        + fundAssetManagerId + ", gender=" + gender + ", lastName=" + lastName + ", legalName="
        + legalName + ", leiCode=" + leiCode + ", localBirthCountry=" + localBirthCountry
        + ", localRegistrationId=" + localRegistrationId + ", roc=" + roc + ", zipCode=" + zipCode
        + "]";
  }

}

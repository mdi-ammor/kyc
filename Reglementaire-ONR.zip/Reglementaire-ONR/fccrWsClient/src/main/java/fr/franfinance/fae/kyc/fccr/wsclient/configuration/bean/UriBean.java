package fr.franfinance.fae.kyc.fccr.wsclient.configuration.bean;

/**
 * @author adeq685
 *
 */
public class UriBean {

  private String readRatingsUri;
  private String computeRatingsUri;
  private String amendRatingsUri;
  private String computeBulkRatingsUri;

  public String getReadRatingsUri() {
    return readRatingsUri;
  }

  public void setReadRatingsUri(String readRatingsUri) {
    this.readRatingsUri = readRatingsUri;
  }

  public String getComputeRatingsUri() {
    return computeRatingsUri;
  }

  public void setComputeRatingsUri(String computeRatingsUri) {
    this.computeRatingsUri = computeRatingsUri;
  }

  public String getAmendRatingsUri(String ratingId) {
    return amendRatingsUri.replace("{ratingId}", ratingId);
  }

  public void setAmendRatingsUri(String amendRatingsUri) {
    this.amendRatingsUri = amendRatingsUri;
  }

  public String getComputeBulkRatingsUri() {
    return computeBulkRatingsUri;
  }

  public void setComputeBulkRatingsUri(String computeBulkRatingsUri) {
    this.computeBulkRatingsUri = computeBulkRatingsUri;
  }



}

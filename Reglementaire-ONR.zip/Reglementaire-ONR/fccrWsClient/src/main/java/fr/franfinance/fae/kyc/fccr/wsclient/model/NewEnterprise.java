package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class NewEnterprise implements Serializable {

  private static final long serialVersionUID = 1L;

  private Boolean level;
  private Boolean levelDefaultIndicator;
  private Integer score;
  private String value;

  public Boolean getLevel() {
    return level;
  }

  public void setLevel(Boolean level) {
    this.level = level;
  }

  public Boolean getLevelDefaultIndicator() {
    return levelDefaultIndicator;
  }

  public void setLevelDefaultIndicator(Boolean levelDefaultIndicator) {
    this.levelDefaultIndicator = levelDefaultIndicator;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(Integer score) {
    this.score = score;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return "NewEnterprise [level=" + level + ", levelDefaultIndicator=" + levelDefaultIndicator
        + ", score=" + score + ", value=" + value + "]";
  }

}

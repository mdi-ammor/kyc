package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;
import java.util.List;

public class LocalBusinessRules implements Serializable {

  private static final long serialVersionUID = 1L;

  private List<LocalBusinessRule> localBusinessRuleList = null;

  public List<LocalBusinessRule> getLocalBusinessRuleList() {
    return localBusinessRuleList;
  }

  public void setLocalBusinessRuleList(List<LocalBusinessRule> localBusinessRuleList) {
    this.localBusinessRuleList = localBusinessRuleList;
  }
}

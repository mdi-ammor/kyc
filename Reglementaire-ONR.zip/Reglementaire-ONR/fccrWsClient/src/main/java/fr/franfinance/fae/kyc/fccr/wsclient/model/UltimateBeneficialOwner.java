package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;
import org.dozer.Mapping;

public class UltimateBeneficialOwner implements Serializable {

  private static final long serialVersionUID = 1L;

  private String birthCountryCode;
  private String birthDate;
  private String firstName;
  private String gender;
  private String lastName;
  private String localBirthCountryCode;
  private String localResidenceCountryCode;
  private String residenceCountryCode;

  public String getBirthCountryCode() {
    return birthCountryCode;
  }

  public void setBirthCountryCode(String birthCountryCode) {
    this.birthCountryCode = birthCountryCode;
  }

  @Mapping("dateNai")
  public String getBirthDate() {
    return birthDate;
  }

  public void setBirthDate(String birthDate) {
    this.birthDate = birthDate;
  }

  @Mapping("prenom")
  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getGender() {
    return gender;
  }

  public void setGender(String gender) {
    this.gender = gender;
  }

  @Mapping("nom")
  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getLocalBirthCountryCode() {
    return localBirthCountryCode;
  }

  public void setLocalBirthCountryCode(String localBirthCountryCode) {
    this.localBirthCountryCode = localBirthCountryCode;
  }

  public String getLocalResidenceCountryCode() {
    return localResidenceCountryCode;
  }

  public void setLocalResidenceCountryCode(String localResidenceCountryCode) {
    this.localResidenceCountryCode = localResidenceCountryCode;
  }

  @Mapping("paysRes")
  public String getResidenceCountryCode() {
    return residenceCountryCode;
  }

  public void setResidenceCountryCode(String residenceCountryCode) {
    this.residenceCountryCode = residenceCountryCode;
  }

  @Override
  public String toString() {
    return "UltimateBeneficialOwner [birthCountryCode=" + birthCountryCode + ", birthDate="
        + birthDate + ", firstName=" + firstName + ", gender=" + gender + ", lastName=" + lastName
        + ", localBirthCountryCode=" + localBirthCountryCode + ", localResidenceCountryCode="
        + localResidenceCountryCode + ", residenceCountryCode=" + residenceCountryCode + "]";
  }

}

package fr.franfinance.fae.kyc.fccr.wsclient.model.request;

public class FccrRatingRequest {
  private FccrRating result;

  
  public FccrRatingRequest(FccrRating result) {
    super();
    this.result = result;
  }

  public FccrRating getResult() {
    return result;
  }

  public void setResult(FccrRating result) {
    this.result = result;
  }

  @Override
  public String toString() {
    return "FccrRatingRequest [result=" + result + "]";
  }

}

package fr.franfinance.fae.kyc.fccr.wsclient.model.response;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;
import fr.franfinance.fae.kyc.fccr.wsclient.model.Errors;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;

public class FccrToken {

  private String accessToken;
  private String tokenType;
  private Integer expiresIn;
  private String expirationDate;
  private Set<String> scope;
  private Errors errors;

  public String getAccessToken() {
    return accessToken;
  }

  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }

  public String getTokenType() {
    return tokenType;
  }

  public void setTokenType(String tokenType) {
    this.tokenType = tokenType;
  }

  public Integer getExpiresIn() {
    return expiresIn;
  }

  public void setExpiresIn(Integer expiresIn) {
    this.expiresIn = expiresIn;
  }

  public String getExpirationDate() {
    return expirationDate;
  }

  public void setExpirationDate(Date expirationDate) {
    DateFormat simple = new SimpleDateFormat(FccrClientConstants.DATE_FORMAT);
    this.expirationDate = simple.format(new Date(expirationDate.getTime()));
  }

  public Set<String> getScope() {
    return scope;
  }

  public void setScope(Set<String> scope) {
    this.scope = scope;
  }

  
  public Errors getErrors() {
    return errors;
  }

  public void setErrors(Errors errors) {
    this.errors = errors;
  }

  @Override
  public String toString() {
    return "FccrToken [accessToken=" + accessToken + ", tokenType=" + tokenType + ", expiresIn="
        + expiresIn + ", expirationDate=" + expirationDate + ", scope=" + scope + "]";
  }

}

package fr.franfinance.fae.kyc.fccr.wsclient.util;

public final class FccrClientConstants {

  public static final String CUSTOMER_IDENTIFIER_LOCAL_ID = "localId";
  public static final String CUSTOMER_IDENTIFIER_LOCAL_DB = "localDb";
  public static final String CUSTOMER_IDENTIFIER_RCT_ID = "rctId";
  public static final String CUSTOMER_IDENTIFIER_COUNTRY_CODE = "countryCode";
  public static final String CUSTOMER_IDENTIFIER_LOCAL_COUNTRY_CODE = "localCountryCode";
  public static final String AUTHORIZATION_STRING = "Authorization";
  public static final String USER_STRING = "User";
  public static final String TOKEN_STRING = "token";
  public static final String TOKEN_BEARER_STRING = "Bearer ";
  public static final String SUCCESS_STATUS = "SUCCESS";
  public static final String FAILURE_STATUS = "FAILURE";
  public static final String NOT_FOUND_EXCEPTION = "PAGE_NOT_FOUND";
  public static final String SERVICE_UNAVAILABLE_EXCEPTION = "FCCR_SERVICE_UNAVAILABLE";
  public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
  public static final String MESSAGE_LOG_REQUEST_BEGIN =
      "=========================== REQUEST BEGIN ================================================";
  public static final String MESSAGE_LOG_REQUEST_END =
      "=========================== REQUEST END ================================================";
  public static final String MESSAGE_LOG_RESPONSE_BEGIN =
      "=========================== RESPONSE BEGIN ================================================";
  public static final String MESSAGE_LOG_RESPONSE_END =
      "=========================== RESPONSE END ================================================";
  public static final String MESSAGE_LOG_ENCODING = "UTF-8";
  public static final String MESSAGE_LOG_URI = "URI         : {}";
  public static final String MESSAGE_LOG_METHOD = "Method      : {}";
  public static final String MESSAGE_LOG_HEADER = "Headers     : {}";
  public static final String MESSAGE_LOG_REQUEST_BODY = "Request body: {}";
  public static final String MESSAGE_LOG_STATUS_CODE = "Status code  : {}";
  public static final String MESSAGE_LOG_STATUS_TEXT = "Status text  : {}";
  public static final String MESSAGE_LOG_RESPONSE_BODY = "Response body  : {}";
  public static final String SERVICE_UNAVAILABLE_MESSAGE =
      "The FCCR server is temporarily unable to service your request due to maintenance downtime or capacity problems. Please try again later.";
}

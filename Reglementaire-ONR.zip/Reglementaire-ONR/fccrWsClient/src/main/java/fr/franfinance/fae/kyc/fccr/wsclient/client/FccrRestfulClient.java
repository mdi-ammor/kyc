package fr.franfinance.fae.kyc.fccr.wsclient.client;

import java.util.ArrayList;
import java.util.List;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.FccrRestClientConfig;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.bean.UriBean;
import fr.franfinance.fae.kyc.fccr.wsclient.exception.FunctionalException;
import fr.franfinance.fae.kyc.fccr.wsclient.exception.TechnicalException;
import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerIdentifier;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.AmendFinalRatingDataRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;

public class FccrRestfulClient {

  RestTemplate fccrRestTemplate;
  UriBean urls;

  public FccrRestfulClient() {

    fccrRestTemplate = FccrRestClientConfig.interceptFccrRestTemplate();
    urls = FccrRestClientConfig.getUrls();
  }

  /**
   * 
   * @return token as a fccrToken
   */
  public static FccrToken getToken() {
    FccrToken fccrToken = new FccrToken();
    try {
      fccrToken = FccrRestClientConfig.loginAndGetAccessToken();
    } catch (TechnicalException e) {
      fccrToken = e.getTokenException();
    }
    return fccrToken;
  }

  /**
   * 
   * @param customerId
   * @return a customer response from ratings READ method
   * @throws Exception
   */
  public CustomerResponse readRatingsCustomer(CustomerIdentifier customerId, String token)
      throws Exception {

    CustomerResponse response = new CustomerResponse();
    // construct the GET URL
    String uri = FccrRestClientConfig.getRatingsURI(customerId);
    // add Header and request
    HttpEntity<CustomerIdentifier> entity =
        new HttpEntity<>(customerId, FccrRestClientConfig.createHttpHeaders(token));

    // call FCCR calculator web service - method GET ratings
    try {
      ResponseEntity<CustomerResponse> httpResponse =
          fccrRestTemplate.exchange(uri, HttpMethod.GET, entity, CustomerResponse.class);
      response = httpResponse.getBody();
      // throw functional exceptions
      if (httpResponse.getStatusCode().is2xxSuccessful()
          && response.getStatus().equals(FccrClientConstants.FAILURE_STATUS)) {
        throw new FunctionalException(response);
      }
    } catch (TechnicalException e) {
      response = e.getTechnicalException();
    }
    return response;
  }

  /**
   * 
   * @param customer
   * @return a customer response from ratings COMPUTE method
   * @throws Exception
   */
  public CustomerResponse computeRatingsCustomer(ComputeRequest computeCustomer, String token)
      throws Exception {

    CustomerResponse response = new CustomerResponse();
    // add Header and request
    HttpEntity<ComputeRequest> entity =
        new HttpEntity<>(computeCustomer, FccrRestClientConfig.createHttpHeaders(token));

    // call FCCR calculator web service - method POST compute ratings
    try {
      ResponseEntity<CustomerResponse> httpResponse = fccrRestTemplate
          .postForEntity(urls.getComputeRatingsUri(), entity, CustomerResponse.class);
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      response = e.getTechnicalException();
    }
    return response;
  }

  /**
   * 
   * @param customer
   * @return a customer response from ratings COMPUTE_BULK method
   * @throws Exception
   */
  public List<CustomerResponse> computeBulkRatingsCustomer(List<ComputeRequest> computeRequestList,
      String token) throws Exception {

    List<CustomerResponse> response = new ArrayList<CustomerResponse>();
    // add Header and request
    HttpEntity<List<ComputeRequest>> entity =
        new HttpEntity<>(computeRequestList, FccrRestClientConfig.createHttpHeaders(token));

    // call FCCR calculator web service - method POST compute bulk ratings
    try {
      ResponseEntity<List<CustomerResponse>> httpResponse =
          fccrRestTemplate.exchange(urls.getComputeBulkRatingsUri(), HttpMethod.POST, entity,
              new ParameterizedTypeReference<List<CustomerResponse>>() {});
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      response.add(e.getTechnicalException());
    }
    return response;
  }

  /**
   * 
   * @param customer
   * @return a customer response from ratings AMEND method
   * @throws Exception
   */
  public CustomerResponse amendRatingsCustomer(AmendFinalRatingDataRequest amendRequest,
      String ratingId, String token) throws Exception {

    CustomerResponse response = new CustomerResponse();
    // add Header and request
    HttpEntity<AmendFinalRatingDataRequest> entity =
        new HttpEntity<>(amendRequest, FccrRestClientConfig.createHttpHeaders(token));

    // call FCCR calculator web service - method POST amend ratings
    try {
      ResponseEntity<CustomerResponse> httpResponse = fccrRestTemplate
          .postForEntity(urls.getAmendRatingsUri(ratingId), entity, CustomerResponse.class);
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      response = e.getTechnicalException();
    }
    return response;
  }

}

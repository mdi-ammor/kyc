package fr.franfinance.fae.kyc.fccr.wsclient.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import fr.franfinance.fae.kyc.fccr.wsclient.configuration.bean.HeaderBean;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.bean.UriBean;

@Configuration
@PropertySource("classpath:application-${envTarget:DEV}.properties")
public class ApplicationConfig {

	@Value("${OAUTH_TOKEN_URI}")
	private String tokenUri;

	@Value("${AUTHENT_TOKEN_CLIENT_ID}")
	private String clientId;

	@Value("${AUTHENT_TOKEN_CLIENT_SECRET}")
	private String clientSecret;

	@Value("${AUTHENT_TOKEN_GRANT}")
	private String grantType;

	@Value("${HEADER_USER_ID}")
	private String userId;
	
	@Value("${READ_RATINGS_URI}")
	private String readRatingsUri;
	
	@Value("${COMPUTE_RATINGS_URI}")
	private String computeRatingsUri;
	
	@Value("${AMEND_RATINGS_URI}")
    private String amendRatingsUri;
	
	@Value("${COMPUTE_BULK_RATINGS_URI}")
	private String computeBulkRatingsUri;

	@Bean
	public HeaderBean getHeader() {
		
		HeaderBean header = new HeaderBean();
		header.setTokenUri(tokenUri);
		header.setClientSecret(clientSecret);
		header.setGrantType(grantType);
		header.setUserId(userId);
		header.setClientId(clientId);
		
		return header;
	}

	
	@Bean
	public UriBean getUriBean() {
		
		UriBean uri = new UriBean();
		uri.setReadRatingsUri(readRatingsUri);
		uri.setComputeRatingsUri(computeRatingsUri);
		uri.setAmendRatingsUri(amendRatingsUri);
		uri.setComputeBulkRatingsUri(computeBulkRatingsUri);
		
		return uri;
	}

	

}

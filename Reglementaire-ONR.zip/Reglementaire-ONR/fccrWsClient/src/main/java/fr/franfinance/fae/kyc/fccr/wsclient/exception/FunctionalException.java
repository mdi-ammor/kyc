package fr.franfinance.fae.kyc.fccr.wsclient.exception;

import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;

public class FunctionalException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private CustomerResponse response;

  public FunctionalException(CustomerResponse response) {
    this.response = response;
  }

  public CustomerResponse getResponse() {
    return response;
  }

  public void setResponse(CustomerResponse response) {
    this.response = response;
  }

  @Override
  public String toString() {
    return "FunctionnalException [response=" + response + "]";
  }
}

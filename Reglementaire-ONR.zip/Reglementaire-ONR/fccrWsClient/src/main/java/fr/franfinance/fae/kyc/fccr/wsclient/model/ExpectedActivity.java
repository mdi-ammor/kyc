package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class ExpectedActivity implements Serializable {

  private static final long serialVersionUID = 1L;

  private String level;
  private Boolean levelDefaultIndicator;
  private Integer score;
  private Integer type;
  private String value;

  public String getLevel() {
    return level;
  }

  public void setLevel(String level) {
    this.level = level;
  }

  public Boolean getLevelDefaultIndicator() {
    return levelDefaultIndicator;
  }

  public void setLevelDefaultIndicator(Boolean levelDefaultIndicator) {
    this.levelDefaultIndicator = levelDefaultIndicator;
  }

  public Integer getScore() {
    return score;
  }

  public void setScore(Integer score) {
    this.score = score;
  }

  public Integer getType() {
    return type;
  }

  public void setType(Integer type) {
    this.type = type;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
  }

  @Override
  public String toString() {
    return "ExpectedActivity [level=" + level + ", levelDefaultIndicator=" + levelDefaultIndicator
        + ", score=" + score + ", type=" + type + ", value=" + value + "]";
  }
}

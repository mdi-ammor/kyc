package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class InvestmentCountry implements Serializable{

  private static final long serialVersionUID = 1L;

  private String code;
  private String localCode;
  private Long percentage;

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getLocalCode() {
    return localCode;
  }

  public void setLocalCode(String localCode) {
    this.localCode = localCode;
  }

  public Long getPercentage() {
    return percentage;
  }

  public void setPercentage(Long percentage) {
    this.percentage = percentage;
  }
}

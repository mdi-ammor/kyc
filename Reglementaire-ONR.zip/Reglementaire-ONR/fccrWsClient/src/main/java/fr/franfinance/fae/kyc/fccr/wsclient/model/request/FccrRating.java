package fr.franfinance.fae.kyc.fccr.wsclient.model.request;

public class FccrRating {

  private String fccrRating;
  private String fccrRatingComment;

  public String getFccrRating() {
    return fccrRating;
  }

  public void setFccrRating(String fccrRating) {
    this.fccrRating = fccrRating;
  }

  public String getFccrRatingComment() {
    return fccrRatingComment;
  }

  public void setFccrRatingComment(String fccrRatingComment) {
    this.fccrRatingComment = fccrRatingComment;
  }

  @Override
  public String toString() {
    return "FccrRating [fccrRating=" + fccrRating + ", fccrRatingComment=" + fccrRatingComment
        + "]";
  }
}

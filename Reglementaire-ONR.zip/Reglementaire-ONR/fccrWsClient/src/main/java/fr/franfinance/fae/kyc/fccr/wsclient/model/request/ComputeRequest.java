/**
 * 
 */
package fr.franfinance.fae.kyc.fccr.wsclient.model.request;

/**
 * @author adeq685
 *
 */

public class ComputeRequest {
	
	private ComputeCustomerRequest customer;

	public ComputeCustomerRequest getCustomer() {
		return customer;
	}

	public void setCustomer(ComputeCustomerRequest customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "ComputeCustomer [customer=" + customer + "]";
	}

	

}

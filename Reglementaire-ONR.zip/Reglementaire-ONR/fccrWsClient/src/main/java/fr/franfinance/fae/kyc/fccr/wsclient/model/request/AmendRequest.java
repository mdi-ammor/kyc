package fr.franfinance.fae.kyc.fccr.wsclient.model.request;

public class AmendRequest {

  String localDb;
  String localId;
  String fccrRating;
  String fccrRatingComment;

  public String getLocalDb() {
    return localDb;
  }

  public void setLocalDb(String localDb) {
    this.localDb = localDb;
  }

  public String getLocalId() {
    return localId;
  }

  public void setLocalId(String localId) {
    this.localId = localId;
  }

  public String getFccrRating() {
    return fccrRating;
  }

  public void setFccrRating(String fccrRating) {
    this.fccrRating = fccrRating;
  }

  public String getFccrRatingComment() {
    return fccrRatingComment;
  }

  public void setFccrRatingComment(String fccrRatingComment) {
    this.fccrRatingComment = fccrRatingComment;
  }

  @Override
  public String toString() {
    return "AmendRequest [localDb=" + localDb + ", localId=" + localId + ", fccrRating="
        + fccrRating + ", fccrRatingComment=" + fccrRatingComment + "]";
  }

}

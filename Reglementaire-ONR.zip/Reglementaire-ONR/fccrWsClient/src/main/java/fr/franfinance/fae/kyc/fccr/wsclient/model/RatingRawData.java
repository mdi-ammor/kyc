package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;
import java.util.List;

public class RatingRawData implements Serializable {

  private static final long serialVersionUID = 1L;

  private String accountOpeningCountriesComment;
  private List<String> accountOpeningCountryCodes = null;
  private String annualTurnover;
  private AssetManager assetManager;
  private String assetManagerComment;
  private String citizenshipCountriesComment;
  private List<String> citizenshipCountryCodes = null;
  private Boolean correspondentBanking;
  private String correspondentBankingComment;
  private String correspondentBankingCurrency;
  private String dateOfCreation;
  private String dateOfCreationComment;
  private String dateOfInitialBusinessRelationship;
  private String dateOfInitialBusinessRelationshipComment;
  private String defaultAccountOpeningCountryIndicator;
  private String defaultCitizenshipCountryIndicator;
  private String defaultCorrespondentBankingIndicator;
  private String defaultDateOfCreationIndicator;
  private String defaultDateOfInitialBusinessRelationshipIndicator;
  private String defaultEntityTypeIndicator;
  private String defaultFundTypeIndicator;
  private String defaultGovernmentCountryIndicator;
  private String defaultGovernmentOwnershipIndicator;
  private String defaultIndustryIndicator;
  private String defaultInvestmentIndustriesIndicator;
  private String defaultNegativeNewsIndicator;
  private String defaultNestedAccountIndicator;
  private String defaultOperationsCountryIndicator;
  private String defaultPepIndicator;
  private String defaultPrimaryInvestmentCountriesIndicator;
  private String defaultPrimaryRegulatoryBodiesIndicator;
  private String defaultProductsIndicator;
  private String defaultRegistrationCountryIndicator;
  private String defaultResidenceCountryIndicator;
  private String defaultSanctionsIndicator;
  private String defaultStockExchangesIndicator;
  private String defaultSubFamiliesIndicator;
  private String entityType;
  private String entityTypeComment;
  private String expectedActivityComment;
  private String fundType;
  private String fundTypeComment;
  private String governmentCountryCode;
  private String governmentCountryComment;
  private Boolean governmentOwnership;
  private String governmentOwnershipComment;
  private String industry;
  private String industryComment;
  private List<InvestmentIndustry> investmentIndustries = null;
  private String investmentIndustriesComment;
  private String investmentLocationComment;
  private List<String> localAccountOpeningCountryCodes = null;
  private List<String> localCitizenshipCountryCodes = null;
  private String localGovernmentCountryCode;
  private String localIndustry;
  private String localNafDivision;
  private List<String> localOperationsCountryCodes = null;
  private List<String> localPrimaryRegulatoryBodies = null;
  private List<String> localProducts = null;
  private String localRegistrationCountryCode;
  private String localResidenceCountryCode;
  private List<String> localStockExchanges = null;
  private List<String> localSubFamilies = null;
  private String nafDivision;
  private Boolean negativeNews;
  private String negativeNewsComment;
  private Boolean nestedAccount;
  private String nestedAccountComment;
  private Integer numberOfPriorSars;
  private String operationsCountriesComment;
  private List<String> operationsCountryCodes = null;
  private String pep;
  private String pepComment;
  private List<InvestmentCountry> primaryInvestmentCountries = null;
  private List<String> primaryRegulatoryBodies = null;
  private String primaryRegulatoryBodiesComment;
  private List<String> products = null;
  private String registrationComment;
  private String registrationCountryCode;
  private String residenceCountryCode;
  private String residenceCountryCodeComment;
  private Boolean sanctions;
  private String sanctionsComment;
  private String segment;
  private List<String> stockExchanges = null;
  private String stockExchangesComment;
  private List<String> subFamilies = null;
  private String subSegment;
  private List<UltimateBeneficialOwner> ultimateBeneficialOwners = null;
  private String ultimateBeneficialOwnersComment;

  public String getAccountOpeningCountriesComment() {
    return accountOpeningCountriesComment;
  }

  public void setAccountOpeningCountriesComment(String accountOpeningCountriesComment) {
    this.accountOpeningCountriesComment = accountOpeningCountriesComment;
  }

  public List<String> getAccountOpeningCountryCodes() {
    return accountOpeningCountryCodes;
  }

  public void setAccountOpeningCountryCodes(List<String> accountOpeningCountryCodes) {
    this.accountOpeningCountryCodes = accountOpeningCountryCodes;
  }

  public String getAnnualTurnover() {
    return annualTurnover;
  }

  public void setAnnualTurnover(String annualTurnover) {
    this.annualTurnover = annualTurnover;
  }

  public AssetManager getAssetManager() {
    return assetManager;
  }

  public void setAssetManager(AssetManager assetManager) {
    this.assetManager = assetManager;
  }

  public String getAssetManagerComment() {
    return assetManagerComment;
  }

  public void setAssetManagerComment(String assetManagerComment) {
    this.assetManagerComment = assetManagerComment;
  }

  public String getCitizenshipCountriesComment() {
    return citizenshipCountriesComment;
  }

  public void setCitizenshipCountriesComment(String citizenshipCountriesComment) {
    this.citizenshipCountriesComment = citizenshipCountriesComment;
  }

  public List<String> getCitizenshipCountryCodes() {
    return citizenshipCountryCodes;
  }

  public void setCitizenshipCountryCodes(List<String> citizenshipCountryCodes) {
    this.citizenshipCountryCodes = citizenshipCountryCodes;
  }

  public Boolean getCorrespondentBanking() {
    return correspondentBanking;
  }

  public void setCorrespondentBanking(Boolean correspondentBanking) {
    this.correspondentBanking = correspondentBanking;
  }

  public String getCorrespondentBankingComment() {
    return correspondentBankingComment;
  }

  public void setCorrespondentBankingComment(String correspondentBankingComment) {
    this.correspondentBankingComment = correspondentBankingComment;
  }

  public String getCorrespondentBankingCurrency() {
    return correspondentBankingCurrency;
  }

  public void setCorrespondentBankingCurrency(String correspondentBankingCurrency) {
    this.correspondentBankingCurrency = correspondentBankingCurrency;
  }

  public String getDateOfCreation() {
    return dateOfCreation;
  }

  public void setDateOfCreation(String dateOfCreation) {
    this.dateOfCreation = dateOfCreation;
  }

  public String getDateOfCreationComment() {
    return dateOfCreationComment;
  }

  public void setDateOfCreationComment(String dateOfCreationComment) {
    this.dateOfCreationComment = dateOfCreationComment;
  }

  public String getDateOfInitialBusinessRelationship() {
    return dateOfInitialBusinessRelationship;
  }

  public void setDateOfInitialBusinessRelationship(String dateOfInitialBusinessRelationship) {
    this.dateOfInitialBusinessRelationship = dateOfInitialBusinessRelationship;
  }

  public String getDateOfInitialBusinessRelationshipComment() {
    return dateOfInitialBusinessRelationshipComment;
  }

  public void setDateOfInitialBusinessRelationshipComment(
      String dateOfInitialBusinessRelationshipComment) {
    this.dateOfInitialBusinessRelationshipComment = dateOfInitialBusinessRelationshipComment;
  }

  public String getDefaultAccountOpeningCountryIndicator() {
    return defaultAccountOpeningCountryIndicator;
  }

  public void setDefaultAccountOpeningCountryIndicator(
      String defaultAccountOpeningCountryIndicator) {
    this.defaultAccountOpeningCountryIndicator = defaultAccountOpeningCountryIndicator;
  }

  public String getDefaultCitizenshipCountryIndicator() {
    return defaultCitizenshipCountryIndicator;
  }

  public void setDefaultCitizenshipCountryIndicator(String defaultCitizenshipCountryIndicator) {
    this.defaultCitizenshipCountryIndicator = defaultCitizenshipCountryIndicator;
  }

  public String getDefaultCorrespondentBankingIndicator() {
    return defaultCorrespondentBankingIndicator;
  }

  public void setDefaultCorrespondentBankingIndicator(String defaultCorrespondentBankingIndicator) {
    this.defaultCorrespondentBankingIndicator = defaultCorrespondentBankingIndicator;
  }

  public String getDefaultDateOfCreationIndicator() {
    return defaultDateOfCreationIndicator;
  }

  public void setDefaultDateOfCreationIndicator(String defaultDateOfCreationIndicator) {
    this.defaultDateOfCreationIndicator = defaultDateOfCreationIndicator;
  }

  public String getDefaultDateOfInitialBusinessRelationshipIndicator() {
    return defaultDateOfInitialBusinessRelationshipIndicator;
  }

  public void setDefaultDateOfInitialBusinessRelationshipIndicator(
      String defaultDateOfInitialBusinessRelationshipIndicator) {
    this.defaultDateOfInitialBusinessRelationshipIndicator =
        defaultDateOfInitialBusinessRelationshipIndicator;
  }

  public String getDefaultEntityTypeIndicator() {
    return defaultEntityTypeIndicator;
  }

  public void setDefaultEntityTypeIndicator(String defaultEntityTypeIndicator) {
    this.defaultEntityTypeIndicator = defaultEntityTypeIndicator;
  }

  public String getDefaultFundTypeIndicator() {
    return defaultFundTypeIndicator;
  }

  public void setDefaultFundTypeIndicator(String defaultFundTypeIndicator) {
    this.defaultFundTypeIndicator = defaultFundTypeIndicator;
  }

  public String getDefaultGovernmentCountryIndicator() {
    return defaultGovernmentCountryIndicator;
  }

  public void setDefaultGovernmentCountryIndicator(String defaultGovernmentCountryIndicator) {
    this.defaultGovernmentCountryIndicator = defaultGovernmentCountryIndicator;
  }

  public String getDefaultGovernmentOwnershipIndicator() {
    return defaultGovernmentOwnershipIndicator;
  }

  public void setDefaultGovernmentOwnershipIndicator(String defaultGovernmentOwnershipIndicator) {
    this.defaultGovernmentOwnershipIndicator = defaultGovernmentOwnershipIndicator;
  }

  public String getDefaultIndustryIndicator() {
    return defaultIndustryIndicator;
  }

  public void setDefaultIndustryIndicator(String defaultIndustryIndicator) {
    this.defaultIndustryIndicator = defaultIndustryIndicator;
  }

  public String getDefaultInvestmentIndustriesIndicator() {
    return defaultInvestmentIndustriesIndicator;
  }

  public void setDefaultInvestmentIndustriesIndicator(String defaultInvestmentIndustriesIndicator) {
    this.defaultInvestmentIndustriesIndicator = defaultInvestmentIndustriesIndicator;
  }

  public String getDefaultNegativeNewsIndicator() {
    return defaultNegativeNewsIndicator;
  }

  public void setDefaultNegativeNewsIndicator(String defaultNegativeNewsIndicator) {
    this.defaultNegativeNewsIndicator = defaultNegativeNewsIndicator;
  }

  public String getDefaultNestedAccountIndicator() {
    return defaultNestedAccountIndicator;
  }

  public void setDefaultNestedAccountIndicator(String defaultNestedAccountIndicator) {
    this.defaultNestedAccountIndicator = defaultNestedAccountIndicator;
  }

  public String getDefaultOperationsCountryIndicator() {
    return defaultOperationsCountryIndicator;
  }

  public void setDefaultOperationsCountryIndicator(String defaultOperationsCountryIndicator) {
    this.defaultOperationsCountryIndicator = defaultOperationsCountryIndicator;
  }

  public String getDefaultPepIndicator() {
    return defaultPepIndicator;
  }

  public void setDefaultPepIndicator(String defaultPepIndicator) {
    this.defaultPepIndicator = defaultPepIndicator;
  }

  public String getDefaultPrimaryInvestmentCountriesIndicator() {
    return defaultPrimaryInvestmentCountriesIndicator;
  }

  public void setDefaultPrimaryInvestmentCountriesIndicator(
      String defaultPrimaryInvestmentCountriesIndicator) {
    this.defaultPrimaryInvestmentCountriesIndicator = defaultPrimaryInvestmentCountriesIndicator;
  }

  public String getDefaultPrimaryRegulatoryBodiesIndicator() {
    return defaultPrimaryRegulatoryBodiesIndicator;
  }

  public void setDefaultPrimaryRegulatoryBodiesIndicator(
      String defaultPrimaryRegulatoryBodiesIndicator) {
    this.defaultPrimaryRegulatoryBodiesIndicator = defaultPrimaryRegulatoryBodiesIndicator;
  }

  public String getDefaultProductsIndicator() {
    return defaultProductsIndicator;
  }

  public void setDefaultProductsIndicator(String defaultProductsIndicator) {
    this.defaultProductsIndicator = defaultProductsIndicator;
  }

  public String getDefaultRegistrationCountryIndicator() {
    return defaultRegistrationCountryIndicator;
  }

  public void setDefaultRegistrationCountryIndicator(String defaultRegistrationCountryIndicator) {
    this.defaultRegistrationCountryIndicator = defaultRegistrationCountryIndicator;
  }

  public String getDefaultResidenceCountryIndicator() {
    return defaultResidenceCountryIndicator;
  }

  public void setDefaultResidenceCountryIndicator(String defaultResidenceCountryIndicator) {
    this.defaultResidenceCountryIndicator = defaultResidenceCountryIndicator;
  }

  public String getDefaultSanctionsIndicator() {
    return defaultSanctionsIndicator;
  }

  public void setDefaultSanctionsIndicator(String defaultSanctionsIndicator) {
    this.defaultSanctionsIndicator = defaultSanctionsIndicator;
  }

  public String getDefaultStockExchangesIndicator() {
    return defaultStockExchangesIndicator;
  }

  public void setDefaultStockExchangesIndicator(String defaultStockExchangesIndicator) {
    this.defaultStockExchangesIndicator = defaultStockExchangesIndicator;
  }

  public String getDefaultSubFamiliesIndicator() {
    return defaultSubFamiliesIndicator;
  }

  public void setDefaultSubFamiliesIndicator(String defaultSubFamiliesIndicator) {
    this.defaultSubFamiliesIndicator = defaultSubFamiliesIndicator;
  }

  public String getEntityType() {
    return entityType;
  }

  public void setEntityType(String entityType) {
    this.entityType = entityType;
  }

  public String getEntityTypeComment() {
    return entityTypeComment;
  }

  public void setEntityTypeComment(String entityTypeComment) {
    this.entityTypeComment = entityTypeComment;
  }

  public String getExpectedActivityComment() {
    return expectedActivityComment;
  }

  public void setExpectedActivityComment(String expectedActivityComment) {
    this.expectedActivityComment = expectedActivityComment;
  }

  public String getFundType() {
    return fundType;
  }

  public void setFundType(String fundType) {
    this.fundType = fundType;
  }

  public String getFundTypeComment() {
    return fundTypeComment;
  }

  public void setFundTypeComment(String fundTypeComment) {
    this.fundTypeComment = fundTypeComment;
  }

  public String getGovernmentCountryCode() {
    return governmentCountryCode;
  }

  public void setGovernmentCountryCode(String governmentCountryCode) {
    this.governmentCountryCode = governmentCountryCode;
  }

  public String getGovernmentCountryComment() {
    return governmentCountryComment;
  }

  public void setGovernmentCountryComment(String governmentCountryComment) {
    this.governmentCountryComment = governmentCountryComment;
  }

  public Boolean getGovernmentOwnership() {
    return governmentOwnership;
  }

  public void setGovernmentOwnership(Boolean governmentOwnership) {
    this.governmentOwnership = governmentOwnership;
  }

  public String getGovernmentOwnershipComment() {
    return governmentOwnershipComment;
  }

  public void setGovernmentOwnershipComment(String governmentOwnershipComment) {
    this.governmentOwnershipComment = governmentOwnershipComment;
  }

  public String getIndustry() {
    return industry;
  }

  public void setIndustry(String industry) {
    this.industry = industry;
  }

  public String getIndustryComment() {
    return industryComment;
  }

  public void setIndustryComment(String industryComment) {
    this.industryComment = industryComment;
  }

  public List<InvestmentIndustry> getInvestmentIndustries() {
    return investmentIndustries;
  }

  public void setInvestmentIndustries(List<InvestmentIndustry> investmentIndustries) {
    this.investmentIndustries = investmentIndustries;
  }

  public String getInvestmentIndustriesComment() {
    return investmentIndustriesComment;
  }

  public void setInvestmentIndustriesComment(String investmentIndustriesComment) {
    this.investmentIndustriesComment = investmentIndustriesComment;
  }

  public String getInvestmentLocationComment() {
    return investmentLocationComment;
  }

  public void setInvestmentLocationComment(String investmentLocationComment) {
    this.investmentLocationComment = investmentLocationComment;
  }

  public List<String> getLocalAccountOpeningCountryCodes() {
    return localAccountOpeningCountryCodes;
  }

  public void setLocalAccountOpeningCountryCodes(List<String> localAccountOpeningCountryCodes) {
    this.localAccountOpeningCountryCodes = localAccountOpeningCountryCodes;
  }

  public List<String> getLocalCitizenshipCountryCodes() {
    return localCitizenshipCountryCodes;
  }

  public void setLocalCitizenshipCountryCodes(List<String> localCitizenshipCountryCodes) {
    this.localCitizenshipCountryCodes = localCitizenshipCountryCodes;
  }

  public String getLocalGovernmentCountryCode() {
    return localGovernmentCountryCode;
  }

  public void setLocalGovernmentCountryCode(String localGovernmentCountryCode) {
    this.localGovernmentCountryCode = localGovernmentCountryCode;
  }

  public String getLocalIndustry() {
    return localIndustry;
  }

  public void setLocalIndustry(String localIndustry) {
    this.localIndustry = localIndustry;
  }

  public String getLocalNafDivision() {
    return localNafDivision;
  }

  public void setLocalNafDivision(String localNafDivision) {
    this.localNafDivision = localNafDivision;
  }

  public List<String> getLocalOperationsCountryCodes() {
    return localOperationsCountryCodes;
  }

  public void setLocalOperationsCountryCodes(List<String> localOperationsCountryCodes) {
    this.localOperationsCountryCodes = localOperationsCountryCodes;
  }

  public List<String> getLocalPrimaryRegulatoryBodies() {
    return localPrimaryRegulatoryBodies;
  }

  public void setLocalPrimaryRegulatoryBodies(List<String> localPrimaryRegulatoryBodies) {
    this.localPrimaryRegulatoryBodies = localPrimaryRegulatoryBodies;
  }

  public List<String> getLocalProducts() {
    return localProducts;
  }

  public void setLocalProducts(List<String> localProducts) {
    this.localProducts = localProducts;
  }

  public String getLocalRegistrationCountryCode() {
    return localRegistrationCountryCode;
  }

  public void setLocalRegistrationCountryCode(String localRegistrationCountryCode) {
    this.localRegistrationCountryCode = localRegistrationCountryCode;
  }

  public String getLocalResidenceCountryCode() {
    return localResidenceCountryCode;
  }

  public void setLocalResidenceCountryCode(String localResidenceCountryCode) {
    this.localResidenceCountryCode = localResidenceCountryCode;
  }

  public List<String> getLocalStockExchanges() {
    return localStockExchanges;
  }

  public void setLocalStockExchanges(List<String> localStockExchanges) {
    this.localStockExchanges = localStockExchanges;
  }

  public List<String> getLocalSubFamilies() {
    return localSubFamilies;
  }

  public void setLocalSubFamilies(List<String> localSubFamilies) {
    this.localSubFamilies = localSubFamilies;
  }

  public String getNafDivision() {
    return nafDivision;
  }

  public void setNafDivision(String nafDivision) {
    this.nafDivision = nafDivision;
  }

  public Boolean getNegativeNews() {
    return negativeNews;
  }

  public void setNegativeNews(Boolean negativeNews) {
    this.negativeNews = negativeNews;
  }

  public String getNegativeNewsComment() {
    return negativeNewsComment;
  }

  public void setNegativeNewsComment(String negativeNewsComment) {
    this.negativeNewsComment = negativeNewsComment;
  }

  public Boolean getNestedAccount() {
    return nestedAccount;
  }

  public void setNestedAccount(Boolean nestedAccount) {
    this.nestedAccount = nestedAccount;
  }

  public String getNestedAccountComment() {
    return nestedAccountComment;
  }

  public void setNestedAccountComment(String nestedAccountComment) {
    this.nestedAccountComment = nestedAccountComment;
  }

  public Integer getNumberOfPriorSars() {
    return numberOfPriorSars;
  }

  public void setNumberOfPriorSars(Integer numberOfPriorSars) {
    this.numberOfPriorSars = numberOfPriorSars;
  }

  public String getOperationsCountriesComment() {
    return operationsCountriesComment;
  }

  public void setOperationsCountriesComment(String operationsCountriesComment) {
    this.operationsCountriesComment = operationsCountriesComment;
  }

  public List<String> getOperationsCountryCodes() {
    return operationsCountryCodes;
  }

  public void setOperationsCountryCodes(List<String> operationsCountryCodes) {
    this.operationsCountryCodes = operationsCountryCodes;
  }

  public String getPep() {
    return pep;
  }

  public void setPep(String pep) {
    this.pep = pep;
  }

  public String getPepComment() {
    return pepComment;
  }

  public void setPepComment(String pepComment) {
    this.pepComment = pepComment;
  }

  public List<InvestmentCountry> getPrimaryInvestmentCountries() {
    return primaryInvestmentCountries;
  }

  public void setPrimaryInvestmentCountries(List<InvestmentCountry> primaryInvestmentCountries) {
    this.primaryInvestmentCountries = primaryInvestmentCountries;
  }

  public List<String> getPrimaryRegulatoryBodies() {
    return primaryRegulatoryBodies;
  }

  public void setPrimaryRegulatoryBodies(List<String> primaryRegulatoryBodies) {
    this.primaryRegulatoryBodies = primaryRegulatoryBodies;
  }

  public String getPrimaryRegulatoryBodiesComment() {
    return primaryRegulatoryBodiesComment;
  }

  public void setPrimaryRegulatoryBodiesComment(String primaryRegulatoryBodiesComment) {
    this.primaryRegulatoryBodiesComment = primaryRegulatoryBodiesComment;
  }

  public List<String> getProducts() {
    return products;
  }

  public void setProducts(List<String> products) {
    this.products = products;
  }

  public String getRegistrationComment() {
    return registrationComment;
  }

  public void setRegistrationComment(String registrationComment) {
    this.registrationComment = registrationComment;
  }

  public String getRegistrationCountryCode() {
    return registrationCountryCode;
  }

  public void setRegistrationCountryCode(String registrationCountryCode) {
    this.registrationCountryCode = registrationCountryCode;
  }

  public String getResidenceCountryCode() {
    return residenceCountryCode;
  }

  public void setResidenceCountryCode(String residenceCountryCode) {
    this.residenceCountryCode = residenceCountryCode;
  }

  public String getResidenceCountryCodeComment() {
    return residenceCountryCodeComment;
  }

  public void setResidenceCountryCodeComment(String residenceCountryCodeComment) {
    this.residenceCountryCodeComment = residenceCountryCodeComment;
  }

  public Boolean getSanctions() {
    return sanctions;
  }

  public void setSanctions(Boolean sanctions) {
    this.sanctions = sanctions;
  }

  public String getSanctionsComment() {
    return sanctionsComment;
  }

  public void setSanctionsComment(String sanctionsComment) {
    this.sanctionsComment = sanctionsComment;
  }

  public String getSegment() {
    return segment;
  }

  public void setSegment(String segment) {
    this.segment = segment;
  }

  public List<String> getStockExchanges() {
    return stockExchanges;
  }

  public void setStockExchanges(List<String> stockExchanges) {
    this.stockExchanges = stockExchanges;
  }

  public String getStockExchangesComment() {
    return stockExchangesComment;
  }

  public void setStockExchangesComment(String stockExchangesComment) {
    this.stockExchangesComment = stockExchangesComment;
  }

  public List<String> getSubFamilies() {
    return subFamilies;
  }

  public void setSubFamilies(List<String> subFamilies) {
    this.subFamilies = subFamilies;
  }

  public String getSubSegment() {
    return subSegment;
  }

  public void setSubSegment(String subSegment) {
    this.subSegment = subSegment;
  }

  public List<UltimateBeneficialOwner> getUltimateBeneficialOwners() {
    return ultimateBeneficialOwners;
  }

  public void setUltimateBeneficialOwners(List<UltimateBeneficialOwner> ultimateBeneficialOwners) {
    this.ultimateBeneficialOwners = ultimateBeneficialOwners;
  }

  public String getUltimateBeneficialOwnersComment() {
    return ultimateBeneficialOwnersComment;
  }

  public void setUltimateBeneficialOwnersComment(String ultimateBeneficialOwnersComment) {
    this.ultimateBeneficialOwnersComment = ultimateBeneficialOwnersComment;
  }

  @Override
  public String toString() {
    return "RawData [accountOpeningCountriesComment=" + accountOpeningCountriesComment
        + ", accountOpeningCountryCodes=" + accountOpeningCountryCodes + ", annualTurnover="
        + annualTurnover + ", assetManager=" + assetManager + ", assetManagerComment="
        + assetManagerComment + ", citizenshipCountriesComment=" + citizenshipCountriesComment
        + ", citizenshipCountryCodes=" + citizenshipCountryCodes + ", correspondentBanking="
        + correspondentBanking + ", correspondentBankingComment=" + correspondentBankingComment
        + ", correspondentBankingCurrency=" + correspondentBankingCurrency + ", dateOfCreation="
        + dateOfCreation + ", dateOfCreationComment=" + dateOfCreationComment
        + ", dateOfInitialBusinessRelationship=" + dateOfInitialBusinessRelationship
        + ", dateOfInitialBusinessRelationshipComment=" + dateOfInitialBusinessRelationshipComment
        + ", defaultAccountOpeningCountryIndicator=" + defaultAccountOpeningCountryIndicator
        + ", defaultCitizenshipCountryIndicator=" + defaultCitizenshipCountryIndicator
        + ", defaultCorrespondentBankingIndicator=" + defaultCorrespondentBankingIndicator
        + ", defaultDateOfCreationIndicator=" + defaultDateOfCreationIndicator
        + ", defaultDateOfInitialBusinessRelationshipIndicator="
        + defaultDateOfInitialBusinessRelationshipIndicator + ", defaultEntityTypeIndicator="
        + defaultEntityTypeIndicator + ", defaultFundTypeIndicator=" + defaultFundTypeIndicator
        + ", defaultGovernmentCountryIndicator=" + defaultGovernmentCountryIndicator
        + ", defaultGovernmentOwnershipIndicator=" + defaultGovernmentOwnershipIndicator
        + ", defaultIndustryIndicator=" + defaultIndustryIndicator
        + ", defaultInvestmentIndustriesIndicator=" + defaultInvestmentIndustriesIndicator
        + ", defaultNegativeNewsIndicator=" + defaultNegativeNewsIndicator
        + ", defaultNestedAccountIndicator=" + defaultNestedAccountIndicator
        + ", defaultOperationsCountryIndicator=" + defaultOperationsCountryIndicator
        + ", defaultPepIndicator=" + defaultPepIndicator
        + ", defaultPrimaryInvestmentCountriesIndicator="
        + defaultPrimaryInvestmentCountriesIndicator + ", defaultPrimaryRegulatoryBodiesIndicator="
        + defaultPrimaryRegulatoryBodiesIndicator + ", defaultProductsIndicator="
        + defaultProductsIndicator + ", defaultRegistrationCountryIndicator="
        + defaultRegistrationCountryIndicator + ", defaultResidenceCountryIndicator="
        + defaultResidenceCountryIndicator + ", defaultSanctionsIndicator="
        + defaultSanctionsIndicator + ", defaultStockExchangesIndicator="
        + defaultStockExchangesIndicator + ", defaultSubFamiliesIndicator="
        + defaultSubFamiliesIndicator + ", entityType=" + entityType + ", entityTypeComment="
        + entityTypeComment + ", expectedActivityComment=" + expectedActivityComment + ", fundType="
        + fundType + ", fundTypeComment=" + fundTypeComment + ", governmentCountryCode="
        + governmentCountryCode + ", governmentCountryComment=" + governmentCountryComment
        + ", governmentOwnership=" + governmentOwnership + ", governmentOwnershipComment="
        + governmentOwnershipComment + ", industry=" + industry + ", industryComment="
        + industryComment + ", investmentIndustries=" + investmentIndustries
        + ", investmentIndustriesComment=" + investmentIndustriesComment
        + ", investmentLocationComment=" + investmentLocationComment
        + ", localAccountOpeningCountryCodes=" + localAccountOpeningCountryCodes
        + ", localCitizenshipCountryCodes=" + localCitizenshipCountryCodes
        + ", localGovernmentCountryCode=" + localGovernmentCountryCode + ", localIndustry="
        + localIndustry + ", localNafDivision=" + localNafDivision
        + ", localOperationsCountryCodes=" + localOperationsCountryCodes
        + ", localPrimaryRegulatoryBodies=" + localPrimaryRegulatoryBodies + ", localProducts="
        + localProducts + ", localRegistrationCountryCode=" + localRegistrationCountryCode
        + ", localResidenceCountryCode=" + localResidenceCountryCode + ", localStockExchanges="
        + localStockExchanges + ", localSubFamilies=" + localSubFamilies + ", nafDivision="
        + nafDivision + ", negativeNews=" + negativeNews + ", negativeNewsComment="
        + negativeNewsComment + ", nestedAccount=" + nestedAccount + ", nestedAccountComment="
        + nestedAccountComment + ", numberOfPriorSars=" + numberOfPriorSars
        + ", operationsCountriesComment=" + operationsCountriesComment + ", operationsCountryCodes="
        + operationsCountryCodes + ", pep=" + pep + ", pepComment=" + pepComment
        + ", primaryInvestmentCountries=" + primaryInvestmentCountries
        + ", primaryRegulatoryBodies=" + primaryRegulatoryBodies
        + ", primaryRegulatoryBodiesComment=" + primaryRegulatoryBodiesComment + ", products="
        + products + ", registrationComment=" + registrationComment + ", registrationCountryCode="
        + registrationCountryCode + ", residenceCountryCode=" + residenceCountryCode
        + ", residenceCountryCodeComment=" + residenceCountryCodeComment + ", sanctions="
        + sanctions + ", sanctionsComment=" + sanctionsComment + ", segment=" + segment
        + ", stockExchanges=" + stockExchanges + ", stockExchangesComment=" + stockExchangesComment
        + ", subFamilies=" + subFamilies + ", subSegment=" + subSegment
        + ", ultimateBeneficialOwners=" + ultimateBeneficialOwners
        + ", ultimateBeneficialOwnersComment=" + ultimateBeneficialOwnersComment + "]";
  }

}

package fr.franfinance.fae.kyc.fccr.wsclient.model;

import java.io.Serializable;

public class InvestmentIndustry implements Serializable {

  private static final long serialVersionUID = 1L;

  private String code;
  private String localCode;
  private String localNafDivision;
  private String nafDivision;
  private Integer percentage;
  private String version;

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getLocalCode() {
    return localCode;
  }

  public void setLocalCode(String localCode) {
    this.localCode = localCode;
  }

  public String getLocalNafDivision() {
    return localNafDivision;
  }

  public void setLocalNafDivision(String localNafDivision) {
    this.localNafDivision = localNafDivision;
  }

  public String getNafDivision() {
    return nafDivision;
  }

  public void setNafDivision(String nafDivision) {
    this.nafDivision = nafDivision;
  }

  public Integer getPercentage() {
    return percentage;
  }

  public void setPercentage(Integer percentage) {
    this.percentage = percentage;
  }

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  @Override
  public String toString() {
    return "InvestmentIndustry [code=" + code + ", localCode=" + localCode + ", localNafDivision="
        + localNafDivision + ", nafDivision=" + nafDivision + ", percentage=" + percentage
        + ", version=" + version + "]";
  }

}

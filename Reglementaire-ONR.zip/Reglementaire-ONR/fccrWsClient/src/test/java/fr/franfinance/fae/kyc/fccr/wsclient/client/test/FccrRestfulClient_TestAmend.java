package fr.franfinance.fae.kyc.fccr.wsclient.client.test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;
import fr.franfinance.fae.kyc.fccr.wsclient.client.FccrRestfulClient;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.ApplicationConfig;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.FccrRestClientConfig;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.bean.UriBean;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.AmendFinalRatingDataRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.FccrRating;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.FccrRatingRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;

public class FccrRestfulClient_TestAmend {
  private AnnotationConfigApplicationContext context;
  private UriBean uri;
  private String amendUri;
  private MockRestServiceServer mockServer;
  private FccrRestfulClient fccrRestfulClient;
  private RestTemplate fccrRestTemplate;
  private FccrRating result;
  private AmendFinalRatingDataRequest amendRequest;
  private CustomerResponse readResponse;

  @Before
  public void setUp() throws Exception {
    context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
    uri = context.getBean(UriBean.class);
    amendUri = uri.getAmendRatingsUri("3419874");
    fccrRestfulClient = new FccrRestfulClient();
    fccrRestTemplate = FccrRestClientConfig.interceptFccrRestTemplate();
    mockServer = MockRestServiceServer.createServer(fccrRestTemplate);

    // getToken
    FccrToken token = FccrRestfulClient.getToken();

    // Amend request
    // create fccrRating object
    result = new FccrRating();
    result.setFccrRating("LOW");
    result.setFccrRatingComment("Fccr Rating Comment");
    // create amend request
    amendRequest = new AmendFinalRatingDataRequest();
    amendRequest.setAmendedRating(new FccrRatingRequest(result));
    amendRequest.setRatingStatus("VALIDATED");
    readResponse =
        fccrRestfulClient.amendRatingsCustomer(amendRequest, "3419874", token.getAccessToken());
  }

  @Test
  public void testGetStatus() {
    mockServer.expect(requestTo(amendUri)).andExpect(method(HttpMethod.GET))
        .andRespond(withSuccess("resultSuccess", MediaType.TEXT_PLAIN));
    String status = readResponse.getStatus();
    assertThat(status, containsString("FAILURE"));
  }

  @Test
  public void testGetError() {
    mockServer.expect(requestTo(amendUri)).andExpect(method(HttpMethod.GET))
        .andRespond(withSuccess("resultSuccess", MediaType.TEXT_PLAIN));
    String amendedNoteLab = readResponse.getErrors().toString();
    assertThat(amendedNoteLab, containsString("Amendment not allowed"));
  }

}

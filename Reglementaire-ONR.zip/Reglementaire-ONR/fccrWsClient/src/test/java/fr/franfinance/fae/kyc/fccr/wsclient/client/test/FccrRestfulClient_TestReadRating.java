package fr.franfinance.fae.kyc.fccr.wsclient.client.test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;
import fr.franfinance.fae.kyc.fccr.wsclient.client.FccrRestfulClient;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.ApplicationConfig;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.FccrRestClientConfig;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.bean.UriBean;
import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerIdentifier;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;

public class FccrRestfulClient_TestReadRating {
  private AnnotationConfigApplicationContext context;
  private UriBean uri;
  private String readRatingsUri;
  private MockRestServiceServer mockServer;
  private FccrRestfulClient fccrRestfulClient;
  private RestTemplate fccrRestTemplate;
  private CustomerIdentifier customerId;
  private CustomerResponse readResponse;

  @Before
  public void setUp() throws Exception {
    context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
    uri = context.getBean(UriBean.class);
    readRatingsUri = uri.getReadRatingsUri();
    fccrRestfulClient = new FccrRestfulClient();
    fccrRestTemplate = FccrRestClientConfig.interceptFccrRestTemplate();
    mockServer = MockRestServiceServer.createServer(fccrRestTemplate);

    // getToken
    FccrToken token = FccrRestfulClient.getToken();

    // Read request
    customerId = new CustomerIdentifier();
    customerId.setLocalId("123456789012");
    customerId.setLocalDb("BDR");
    readResponse = fccrRestfulClient.readRatingsCustomer(customerId, token.getAccessToken());
  }

  @Test
  public void testGetStatus() {
    mockServer.expect(requestTo(readRatingsUri)).andExpect(method(HttpMethod.GET))
        .andRespond(withSuccess("resultSuccess", MediaType.TEXT_PLAIN));
    String status = readResponse.getStatus();
    assertThat(status, containsString("SUCCESS"));
  }

  @Test
  public void testGetNoteLab() {
    mockServer.expect(requestTo(readRatingsUri)).andExpect(method(HttpMethod.GET))
        .andRespond(withSuccess("resultSuccess", MediaType.TEXT_PLAIN));
    String noteLab = readResponse.getCustomer().getRating().getResult().getFccrRating();
    assertThat(noteLab, containsString("MEDIUM_LOW"));
  }

}

package fr.franfinance.fae.kyc.fccr.wsclient.client.test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;
import fr.franfinance.fae.kyc.fccr.wsclient.client.FccrRestfulClient;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.ApplicationConfig;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.FccrRestClientConfig;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.bean.UriBean;
import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerIdentifier;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeCustomerRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.RatingRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;

public class FccrRestfulClient_TestCompute {
  private AnnotationConfigApplicationContext context;
  private UriBean uri;
  private String computeUri;
  private MockRestServiceServer mockServer;
  private FccrRestfulClient fccrRestfulClient;
  private RestTemplate fccrRestTemplate;
  private CustomerIdentifier customerId;
  private CustomerResponse readResponse;
  private CustomerResponse compuetResponse;
  private RatingRequest rating;
  private ComputeCustomerRequest computeCustomerRequest;
  private ComputeRequest computeCustomer;

  @Before
  public void setUp() throws Exception {
    context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
    uri = context.getBean(UriBean.class);
    computeUri = uri.getComputeRatingsUri();
    fccrRestfulClient = new FccrRestfulClient();
    fccrRestTemplate = FccrRestClientConfig.interceptFccrRestTemplate();
    mockServer = MockRestServiceServer.createServer(fccrRestTemplate);

    // getToken
    FccrToken token = FccrRestfulClient.getToken();

    // Read request
    customerId = new CustomerIdentifier();
    customerId.setLocalId("123456789012");
    customerId.setLocalDb("BDR");
    readResponse = fccrRestfulClient.readRatingsCustomer(customerId, token.getAccessToken());

    // Compute request
    // create rating object
    rating = new RatingRequest();
    rating.setDateTime(readResponse.getCustomer().getRating().getDateTime());
    rating.setLocalBusinessRules(readResponse.getCustomer().getRating().getLocalBusinessRules());
    rating.setRawData(readResponse.getCustomer().getRating().getRawData());
    rating.setUserRatingStatus("VALIDATED");
    // create request customer
    computeCustomerRequest = new ComputeCustomerRequest();
    computeCustomerRequest.setCustomerData(readResponse.getCustomer().getCustomerData());
    computeCustomerRequest
        .setCustomerIdentifier(readResponse.getCustomer().getCustomerIdentifier());
    computeCustomerRequest.setRatingStatus("");
    computeCustomerRequest.setRating(rating);
    // create customer
    computeCustomer = new ComputeRequest();
    computeCustomer.setCustomer(computeCustomerRequest);
    compuetResponse =
        fccrRestfulClient.computeRatingsCustomer(computeCustomer, token.getAccessToken());
  }

  @Test
  public void testGetMessage() {
    mockServer.expect(requestTo(computeUri)).andExpect(method(HttpMethod.GET))
        .andRespond(withSuccess("resultSuccess", MediaType.TEXT_PLAIN));
    String result = compuetResponse.getStatus();
    assertThat(result, containsString("SUCCESS"));
  }

  @Test
  public void testGetType() {
    mockServer.expect(requestTo(computeUri)).andExpect(method(HttpMethod.GET))
        .andRespond(withSuccess("resultSuccess", MediaType.TEXT_PLAIN));
    String type = compuetResponse.getCustomer().getRating().getType();
    assertThat(type, containsString("COMPUTED"));
  }

}

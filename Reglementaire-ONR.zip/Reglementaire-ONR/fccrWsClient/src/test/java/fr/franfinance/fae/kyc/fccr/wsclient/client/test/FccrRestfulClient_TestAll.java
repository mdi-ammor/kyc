package fr.franfinance.fae.kyc.fccr.wsclient.client.test;

import java.util.ArrayList;
import java.util.List;
import fr.franfinance.fae.kyc.fccr.wsclient.client.FccrRestfulClient;
import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerIdentifier;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeCustomerRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.FccrRating;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.FccrRatingRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.AmendFinalRatingDataRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.RatingRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;

public class FccrRestfulClient_TestAll {

  public static void main(String[] args) throws Exception {
    // getToken
    FccrToken fccrToken = FccrRestfulClient.getToken();
    String token = FccrClientConstants.TOKEN_BEARER_STRING + fccrToken.getAccessToken();
    // Read method
    FccrRestfulClient fccrRestClient = new FccrRestfulClient();
    CustomerIdentifier customerId = new CustomerIdentifier();
    customerId.setLocalId("FAE000000001302");
    customerId.setLocalDb("FRF_FAE");
    CustomerResponse response = fccrRestClient.readRatingsCustomer(customerId, token);

    // Compute method
    // create rating object
    RatingRequest rating = new RatingRequest();
    rating.setDateTime(response.getCustomer().getRating().getDateTime());
    rating.setLocalBusinessRules(response.getCustomer().getRating().getLocalBusinessRules());
    rating.setRawData(response.getCustomer().getRating().getRawData());
    rating.setUserRatingStatus("VALIDATED");

    // create request customer
    ComputeCustomerRequest computeCustomerRequest = new ComputeCustomerRequest();
    computeCustomerRequest.setCustomerData(response.getCustomer().getCustomerData());
    computeCustomerRequest.setCustomerIdentifier(response.getCustomer().getCustomerIdentifier());
    computeCustomerRequest.setRatingStatus("");

    computeCustomerRequest.setRating(rating);

    // create customer
    ComputeRequest computeCustomer = new ComputeRequest();
    computeCustomer.setCustomer(computeCustomerRequest);
    fccrRestClient.computeRatingsCustomer(computeCustomer, token);

    // Compute_bulk method
    // create compute bulk customer request
    List<ComputeRequest> computeRequestList = new ArrayList<>();
    computeRequestList.add(computeCustomer);
    fccrRestClient.computeBulkRatingsCustomer(computeRequestList, token);

    // Amend method
    // create fccrRating object
    
    FccrRating result = new FccrRating();
    result.setFccrRating("MEDIUM_HIGH");
    result.setFccrRatingComment("4 CFT vers 3");

    // create amend request
    AmendFinalRatingDataRequest amendRequest = new AmendFinalRatingDataRequest();
    amendRequest.setAmendedRating(new FccrRatingRequest(result));
    amendRequest.setRatingStatus("VALIDATED");

    fccrRestClient.amendRatingsCustomer(amendRequest, response.getCustomer().getRating().getId().toString(), token);
    
  }

}

#! /bin/ksh
/usr/java8_64/jre/bin/java -jar -DenvTarget=$1 $2/lib/ellisphereFaeBatch.jar
STATUS=$?
echo $STATUS
exit $STATUS
/**
 * 
 */
package fr.franfinance.fae.kyc.ellisphere.batch.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import fr.franfinance.fae.kyc.ellisphere.batch.config.bean.BatchGedBean;
import fr.franfinance.fae.kyc.ellisphere.batch.config.bean.BatchPathFilesBean;
import fr.franfinance.fae.kyc.ellisphere.batch.config.bean.BatchUriBean;
import fr.franfinance.fae.kyc.ellisphere.batch.util.GedDepotWsClient;

/**
 * @author adeq710
 *
 */

@Configuration
@PropertySources({
  @PropertySource(value = "file:${springConfigPath}/ellis-batch${envTarget:}.properties",
      ignoreResourceNotFound = true),
  @PropertySource(value = "classpath:../config/ellis-batch${envTarget:}.properties",
      ignoreResourceNotFound = true),
  @PropertySource(value = "classpath:/config/ellis-batch${envTarget:}.properties",
      ignoreResourceNotFound = true)})
public class EllisphereBatchConfigTest {

  @Value("${ELLISPHERE_SPOOLOUT}")
  private String ellisphereSpoolout;

  @Value("${ELLISPHERE_ARCHIVE}")
  private String ellisphereArchive;
  
  @Value("${ELLISPHERE_REPRISE}")
  private String ellisphereReprise;

  @Value("${WORKSPACE_JAVA}")
  private String workspaceJava;

  @Value("${WORKSPACE_SQL}")
  private String workspaceSql;

  @Value("${GET_TIERS_URI}")
  private String getTiersUri;

  @Value("${UPDATE_TIERS_URI}")
  private String updateTiersUri;

  @Value("${CALL_FUNCTION_URI}")
  private String callFunctionUri;

  @Value("${GED_WS_URI}")
  private String gedWsUri;

  @Value("${GED_DOCUMENT_TYPE_VALUE}")
  private String documentType;

  @Value("${GED_DOCUMENT_ORIGINAL_VALUE}")
  private String documentOriginal;

  @Value("${GED_DOCUMENT_COPIE_VALUE}")
  private String documentCopie;

  @Value("${GED_GROUPE_MARCHE_VALUE}")
  private String groupeMarche;

  @Value("${GED_IDENTIFIANT_UTILISATEUR_VALUE}")
  private String identifiantUtilisateur;
  
  
  @Bean
  public BatchUriBean getBatchUriBean() {
    BatchUriBean uriBean = new BatchUriBean();
   
    uriBean.setGetTiersUri(getTiersUri);
    uriBean.setUpdateTiersUri(updateTiersUri);
    uriBean.setCallFunctionUri(callFunctionUri);
    uriBean.setGedWsUri(gedWsUri);

    return uriBean;
  }

  @Bean
  public BatchPathFilesBean getBatchPathFilesBean() {
    
    BatchPathFilesBean pathFilesBean = new BatchPathFilesBean();
    pathFilesBean.setEllisphereSpoolout(ellisphereSpoolout);
    pathFilesBean.setEllisphereArchive(ellisphereArchive);
    pathFilesBean.setEllisphereReprise(ellisphereReprise);
    pathFilesBean.setWorkspaceJava(workspaceJava);
    pathFilesBean.setWorkspaceSql(workspaceSql);
    
    
    return pathFilesBean;  
  }
  
  @Bean
  public BatchGedBean getBatchGedBean() {
    
    BatchGedBean gedBean = new BatchGedBean ();
    
    gedBean.setDocumentType(documentType);
    gedBean.setDocumentOriginal(documentOriginal);
    gedBean.setDocumentCopie(documentCopie);
    gedBean.setGroupeMarche(groupeMarche);
    gedBean.setIdentifiantUtilisateur(identifiantUtilisateur);
    
    return gedBean;  
  }

  @Bean
  public Jaxb2Marshaller marshaller() {
    Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
    marshaller.setContextPath("fr.franfinance.fae.depotreindexation.webservices");
    return marshaller;
  }

  @Bean
  public GedDepotWsClient gedDepotWsClient(Jaxb2Marshaller marshaller) {
    GedDepotWsClient client = new GedDepotWsClient();
    client.setDefaultUri(gedWsUri);
    client.setMarshaller(marshaller);
    client.setUnmarshaller(marshaller);
    return client;
  }

}

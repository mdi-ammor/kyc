/**
 * 
 */
package fr.franfinance.fae.kyc.ellisphere.batch.service;

/**
 * @author adeq685
 *
 */
public class EllisphereFaeBatchServiceTest {

}

package fr.franfinance.fae.kyc.ellisphere.batch.util;

import java.io.File;
import java.io.IOException;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import fr.franfinance.fae.depotreindexation.webservices.PutDocumentRequest;
import fr.franfinance.fae.depotreindexation.webservices.PutDocumentResponse;
import fr.franfinance.fae.kyc.ellisphere.batch.config.bean.BatchGedBean;

public class GedDepotWsClient extends WebServiceGatewaySupport  {
  
 
  public PutDocumentResponse callGedWebService(String url, String siren, File file, BatchGedBean gedBean) throws IOException{
    
    //Prepare request for GED WS
    PutDocumentRequest request = EllisphereBatchUtil.prepareGedDocumentRequest(siren, file, gedBean);
   
    return (PutDocumentResponse) getWebServiceTemplate().marshalSendAndReceive(url, request);
}

}

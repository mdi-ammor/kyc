package fr.franfinance.fae.kyc.ellisphere.batch.application;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.io.FileUtils;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import fr.franfinance.ellisphere.wsclient.application.EllisphereClient;
import fr.franfinance.ellisphere.wsclient.util.EllisphereClientConstants;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;
import fr.franfinance.fae.base.tiers.model.database.SuiviAppelEllisphere;
import fr.franfinance.fae.base.tiers.model.response.TiersResponse;
import fr.franfinance.fae.depotreindexation.webservices.PutDocumentResponse;
import fr.franfinance.fae.kyc.ellisphere.batch.config.EllisphereBatchConfig;
import fr.franfinance.fae.kyc.ellisphere.batch.config.bean.BatchGedBean;
import fr.franfinance.fae.kyc.ellisphere.batch.config.bean.BatchPathFilesBean;
import fr.franfinance.fae.kyc.ellisphere.batch.config.bean.BatchUriBean;
import fr.franfinance.fae.kyc.ellisphere.batch.util.EllisphereBatchConstants;
import fr.franfinance.fae.kyc.ellisphere.batch.util.EllisphereBatchUtil;
import fr.franfinance.fae.kyc.ellisphere.batch.util.GedDepotWsClient;


public class EllisphereBatchApplication {
  private static AnnotationConfigApplicationContext context;

  BatchUriBean uriBean;
  BatchGedBean gedBean;
  BatchPathFilesBean pathFilesBean;
  GedDepotWsClient gedDepotWsClient;

  String nomFichierZip = "";
  String nomFichierBeXml = "";
  BigDecimal nbFichierCarto;
  BigDecimal nbFichierPreuve;
  EllisphereClient ellisphereClient;
  static Boolean problemExist;
  static Boolean returnOk;

  private static final Logger LOGGER = LoggerFactory.getLogger(EllisphereBatchApplication.class);

  public EllisphereBatchApplication() {

    LOGGER.info("=========== INIT DU BATCH FAE ELLISPHERE ============");

    context = new AnnotationConfigApplicationContext(EllisphereBatchConfig.class);
    uriBean = context.getBean(BatchUriBean.class);
    pathFilesBean = context.getBean(BatchPathFilesBean.class);
    gedBean = context.getBean(BatchGedBean.class);
    gedDepotWsClient = context.getBean(GedDepotWsClient.class);

    ellisphereClient = new EllisphereClient();
    problemExist = false;
    returnOk = true;
  }

  public static void main(String[] args) throws IOException {

    LOGGER.info("=========== LANCEMENT DU BATCH FAE ELLISPHERE ============");

    EllisphereBatchApplication batchApplication = new EllisphereBatchApplication();
    batchApplication.movesAndUnzip();
    batchApplication.treatEllisphereFolders();

    LOGGER.info("============= FIN DU BATCH FAE ELLISPHERE ============");

    // Return exist status
    if (returnOk) {
      System.exit(0);
    } else {
      System.exit(1);
    }


  }


  /**
   * Moves And Unzip Ellisphere Files
   * 
   */
  public void movesAndUnzip() throws IOException {
    File ellisphereDirectory = new File(pathFilesBean.getEllisphereSpoolout());
    if (ellisphereDirectory.isDirectory()) {
      File[] filesIn = ellisphereDirectory.listFiles();
      LOGGER.info("+ ELLISPHERE IN DIRECTORY: " + ellisphereDirectory.getAbsolutePath());

      Integer zipFileNumber = 0;
      for (int i = 0; i < filesIn.length; i++) {
        if (!filesIn[i].isDirectory()
            && filesIn[i].getName().endsWith(EllisphereBatchConstants.ZIP_FILE_EXTENSION)) {
          LOGGER.info("Zip file name: " + filesIn[i].getName());
          // Move zip file from ELLISPHERE_SPOOLOUT to WORKSPACE_JAVA
          EllisphereBatchUtil.moveEllisphereFile(Paths.get(pathFilesBean.getEllisphereSpoolout()),
              Paths.get(pathFilesBean.getWorkspaceJava()), filesIn[i].getName());
          // Unzip file in WORKSPACE_JAVA
          EllisphereBatchUtil.unzipEllisphereFile(pathFilesBean.getWorkspaceJava(),
              filesIn[i].getName());
          zipFileNumber++;
        }
      }
      LOGGER.info("+ COUNT ZIP FILES IN (MOVED + UNZIPPED): " + zipFileNumber);
    }
  }

  /**
   * Treat Ellisphere Folders
   * 
   */
  public void treatEllisphereFolders() throws IOException {
    List<Path> paths = Files.walk(Paths.get(pathFilesBean.getWorkspaceJava()))
        .filter(Files::isDirectory).collect(Collectors.toList());
    LOGGER.info("COUNT_ELLIS_FOLDER: " + (paths.size() - 1));
    paths.forEach(path -> {
      if (!path.equals(Paths.get(pathFilesBean.getWorkspaceJava()))) {
        treatEllisphereFolder(path);
      }
    });
  }

  public void treatEllisphereFolder(Path path) {
    problemExist = false;
    String folderName = path.getFileName().toString();
    nomFichierZip = folderName + EllisphereBatchConstants.ZIP_FILE_EXTENSION;
    String[] folderNameInfo = folderName.split(EllisphereBatchConstants.UNDERSCORE);

    String siren = folderNameInfo[1];
    String noTicket = folderNameInfo[2];
    String dateReceptFichierBeXml = folderNameInfo[3];

    LOGGER.info("+ ELLIS_FOLDER_NAME: " + folderName);
    LOGGER.info(" + SIREN: " + siren);
    LOGGER.info(" + NO TICKET: " + noTicket);
    LOGGER.info(" + DATE_RECEPTION: " + dateReceptFichierBeXml);

    // Identify BE file : regex SIREN_BE.xml
    File beXmlFile = null;
    try {
      beXmlFile = EllisphereBatchUtil.getFilesMatchingPattern(path.toAbsolutePath().toFile(),
          EllisphereBatchConstants.REGEX_BE_XML)[0];
    } catch (Exception e) {
      e.printStackTrace();
      LOGGER.error("GET XML FILE ERROR : ", e);
      problemExist = true;
    }

    if (beXmlFile != null) {
      try {
        // Copy file BE.xml to WORKSPACE_SQL
        nomFichierBeXml = beXmlFile.getName().toString();
        FileUtils.copyFile(beXmlFile, new File(Paths.get(pathFilesBean.getWorkspaceSql())
            + EllisphereBatchConstants.SLASH + EllisphereBatchConstants.BE_XML_FILE_NAME));
        LOGGER.info(" + XML_FILE: " + nomFichierBeXml + " ==> copied to: "
            + pathFilesBean.getWorkspaceSql());
      } catch (IOException e) {
        e.printStackTrace();
        LOGGER.error("MOVE XML FILE ERROR : ", e);
        problemExist = true;
      }

      // Count files with prefix SIREN-Liens- : champ NB_FICHIER_PREUVE
      File[] liensPdfFiles = EllisphereBatchUtil.getFilesMatchingPattern(
          path.toAbsolutePath().toFile(), EllisphereBatchConstants.REGEX_LIENS_PDF);
      // Count files with prefix SIREN-Cartographie- : champ NB_FICHIER_CARTO
      File[] cartoPdfFiles = EllisphereBatchUtil.getFilesMatchingPattern(
          path.toAbsolutePath().toFile(), EllisphereBatchConstants.REGEX_CARTO_PDF);
      nbFichierPreuve = new BigDecimal(liensPdfFiles.length);
      nbFichierCarto = new BigDecimal(cartoPdfFiles.length);
      LOGGER.info(" + COUNT_LIENS_PDF_FILE: " + nbFichierPreuve);
      LOGGER.info(" + COUNT_CARTO_PDF_FILE: " + nbFichierCarto);

      // get SuiviAppelEllisphere by No Ticket before executing sql function
      SuiviAppelEllisphere suiviAppelEllisByTicket =
          EllisphereBatchUtil.getSuiviAppelEllisByTicket(ellisphereClient, siren, noTicket);
      if (suiviAppelEllisByTicket != null) {
        Integer functionResult = 0;
        try {
          // call sql Function
          Long refAppelEllisphere = suiviAppelEllisByTicket.getRefAppelEllisphere();
          if (refAppelEllisphere != null) {
            LOGGER.info(" + REF_APPEL_ELLI = " + refAppelEllisphere);
            functionResult = ellisphereClient.callFunction(refAppelEllisphere);
            LOGGER.info(" + FUNCTION_RESULT = " + functionResult);
          }
        } catch (Exception e) {
          e.printStackTrace();
          LOGGER.error("CALL FUNCTION ERROR : ", e);
          problemExist = true;
        }

        // Get tiers by Siren
        TiersResponse tiersResponse = new TiersResponse();
        try {
          tiersResponse = ellisphereClient.getTiers(siren);
        } catch (Exception e) {
          e.printStackTrace();
          LOGGER.error("GET TIERS ERROR : ", e);
          problemExist = true;
        }

        NotationRefTier notationRefTier = new NotationRefTier();
        if (tiersResponse.getStatus() != null
            && EllisphereClientConstants.SUCCESS_STATUS.equals(tiersResponse.getStatus())
            && tiersResponse.getTiers().getSuiviAppelsEllisphere().size() > 0) {
          notationRefTier =
              new DozerBeanMapper().map(tiersResponse.getTiers(), NotationRefTier.class);
          // get Last SuiviAppelEllisphere after executing sql function to get updated fields
          suiviAppelEllisByTicket = notationRefTier.getSuiviAppelsEllisphere().stream()
              .filter(suivi -> noTicket.equals(suivi.getNoTicket())).findAny().orElse(null);
        }

        try {
          // Call WS GED if functionResult = OK
          if (functionResult == 0) {
            PutDocumentResponse response = gedDepotWsClient.callGedWebService(uriBean.getGedWsUri(),
                siren, new File(pathFilesBean.getWorkspaceJava() + EllisphereBatchConstants.SLASH
                    + nomFichierZip),
                gedBean);
            String gedWsResult = response.getResult().value();
            LOGGER.info(" + GED_WS_RESULT = " + gedWsResult);
            if ("OK".equals(gedWsResult)) {
              // BTN status = GED_OK
              suiviAppelEllisByTicket.setStatutTicket(EllisphereBatchConstants.STATUS_TRAI);
            } else {
              // BTN status = GED_KO
              suiviAppelEllisByTicket.setStatutTicket(EllisphereBatchConstants.STATUS_GED_KO);
              LOGGER.error("GED WS RESPONSE ERROR : ", gedWsResult);
              problemExist = true;
            }
          } else {
            // Update BTN : UPDATE BTN STATUT INT_KO
            suiviAppelEllisByTicket.setStatutTicket(EllisphereBatchConstants.STATUS_ERR);
            LOGGER.error("FUNCTION ONR.F_TRT_FLUX_ELLIS RESULT ERROR : ", functionResult);
            problemExist = true;
          }
        } catch (Exception e) {
          e.printStackTrace();
          LOGGER.error("CALL GED WS ERROR : ", e);
          problemExist = true;
        }

        try {

          // Set fields for dernierAppelEllishere
          suiviAppelEllisByTicket.setNomFichierZip(nomFichierZip);
          suiviAppelEllisByTicket.setNomFichierBeXml(nomFichierBeXml);
          suiviAppelEllisByTicket.setNbFichierPreuve(nbFichierPreuve);
          suiviAppelEllisByTicket.setNbFichierCarto(nbFichierCarto);
          suiviAppelEllisByTicket.setDateReceptFichierBeXml(
              EllisphereBatchUtil.convertStringToDate(dateReceptFichierBeXml));
          // Update BTN
          ellisphereClient.updateTiers(notationRefTier);
        } catch (Exception e) {
          e.printStackTrace();
          LOGGER.error("UPDATE TIES ERROR : ", e);
          problemExist = true;
        }
      }
    }

    // Archive zip
    if (problemExist) {
      EllisphereBatchUtil.moveZipFile(nomFichierZip, Paths.get(pathFilesBean.getWorkspaceJava()),
          Paths.get(pathFilesBean.getEllisphereReprise()));
      returnOk = false;
    } else {
      EllisphereBatchUtil.moveZipFile(nomFichierZip, Paths.get(pathFilesBean.getWorkspaceJava()),
          Paths.get(pathFilesBean.getEllisphereArchive()));
    }

    // Delete treated folder
    EllisphereBatchUtil.deleteFolderRecursively(path);
  }

}

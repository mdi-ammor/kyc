/**
 * 
 */
package fr.franfinance.fae.kyc.ellisphere.batch.config.bean;

/**
 * @author adeq685
 *
 */
public class BatchUriBean {
  
  private String getTiersUri;
  private String updateTiersUri;
  private String callFunctionUri;
  private String gedWsUri;
  /**
   * @return the getTiersUri
   */
  public String getGetTiersUri() {
    return getTiersUri;
  }
  /**
   * @param getTiersUri the getTiersUri to set
   */
  public void setGetTiersUri(String getTiersUri) {
    this.getTiersUri = getTiersUri;
  }
  /**
   * @return the updateTiersUri
   */
  public String getUpdateTiersUri() {
    return updateTiersUri;
  }
  /**
   * @param updateTiersUri the updateTiersUri to set
   */
  public void setUpdateTiersUri(String updateTiersUri) {
    this.updateTiersUri = updateTiersUri;
  }
  /**
   * @return the callFunctionUri
   */
  public String getCallFunctionUri() {
    return callFunctionUri;
  }
  /**
   * @param callFunctionUri the callFunctionUri to set
   */
  public void setCallFunctionUri(String callFunctionUri) {
    this.callFunctionUri = callFunctionUri;
  }
  /**
   * @return the gedWsUri
   */
  public String getGedWsUri() {
    return gedWsUri;
  }
  /**
   * @param gedWsUri the gedWsUri to set
   */
  public void setGedWsUri(String gedWsUri) {
    this.gedWsUri = gedWsUri;
  }
  
  

}

/**
 * 
 */
package fr.franfinance.fae.kyc.ellisphere.batch.config.bean;

/**
 * @author adeq685
 *
 */
public class BatchGedBean {
  
  private String documentType;
  private String documentOriginal;
  private String documentCopie;
  private String groupeMarche;
  private String identifiantUtilisateur;
  /**
   * @return the documentType
   */
  public String getDocumentType() {
    return documentType;
  }
  /**
   * @param documentType the documentType to set
   */
  public void setDocumentType(String documentType) {
    this.documentType = documentType;
  }
  /**
   * @return the documentOriginal
   */
  public String getDocumentOriginal() {
    return documentOriginal;
  }
  /**
   * @param documentOriginal the documentOriginal to set
   */
  public void setDocumentOriginal(String documentOriginal) {
    this.documentOriginal = documentOriginal;
  }
  /**
   * @return the documentCopie
   */
  public String getDocumentCopie() {
    return documentCopie;
  }
  /**
   * @param documentCopie the documentCopie to set
   */
  public void setDocumentCopie(String documentCopie) {
    this.documentCopie = documentCopie;
  }
  /**
   * @return the groupeMarche
   */
  public String getGroupeMarche() {
    return groupeMarche;
  }
  /**
   * @param groupeMarche the groupeMarche to set
   */
  public void setGroupeMarche(String groupeMarche) {
    this.groupeMarche = groupeMarche;
  }
  /**
   * @return the identifiantUtilisateur
   */
  public String getIdentifiantUtilisateur() {
    return identifiantUtilisateur;
  }
  /**
   * @param identifiantUtilisateur the identifiantUtilisateur to set
   */
  public void setIdentifiantUtilisateur(String identifiantUtilisateur) {
    this.identifiantUtilisateur = identifiantUtilisateur;
  }
  
  

}

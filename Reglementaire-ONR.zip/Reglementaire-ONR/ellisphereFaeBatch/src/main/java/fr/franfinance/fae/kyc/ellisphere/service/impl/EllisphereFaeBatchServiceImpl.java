/**
 * 
 */
package fr.franfinance.fae.kyc.ellisphere.service.impl;

import org.springframework.stereotype.Service;
import fr.franfinance.fae.kyc.ellisphere.service.EllisphereFaeBatchService;



/**
 * @author adeq685
 *
 */

@Service
public class EllisphereFaeBatchServiceImpl implements EllisphereFaeBatchService {
  
 


}

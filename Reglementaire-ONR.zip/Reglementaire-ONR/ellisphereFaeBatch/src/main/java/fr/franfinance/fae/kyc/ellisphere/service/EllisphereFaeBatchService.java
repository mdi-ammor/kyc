/**
 * 
 */
package fr.franfinance.fae.kyc.ellisphere.service;

/**
 * @author adeq685
 *
 */
public interface EllisphereFaeBatchService {
  
 
}

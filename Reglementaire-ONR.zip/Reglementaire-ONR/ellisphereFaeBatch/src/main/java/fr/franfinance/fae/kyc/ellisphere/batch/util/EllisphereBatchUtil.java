package fr.franfinance.fae.kyc.ellisphere.batch.util;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import fr.franfinance.ellisphere.wsclient.application.EllisphereClient;
import fr.franfinance.ellisphere.wsclient.util.EllisphereClientConstants;
import fr.franfinance.fae.base.tiers.model.database.SuiviAppelEllisphere;
import fr.franfinance.fae.base.tiers.model.response.TiersResponse;
import fr.franfinance.fae.depotreindexation.webservices.PutDocumentRequest;
import fr.franfinance.fae.depotreindexation.webservices.PutDocumentRequest.Metadatas;
import fr.franfinance.fae.depotreindexation.webservices.metadata.Metadata;
import fr.franfinance.fae.depotreindexation.webservices.metadata.ObjectFactory;
import fr.franfinance.fae.kyc.ellisphere.batch.config.bean.BatchGedBean;


public final class EllisphereBatchUtil {

  private static final Logger LOGGER = LoggerFactory.getLogger(EllisphereBatchUtil.class);

  private EllisphereBatchUtil() {

  }

  /**
   * Unzip Ellisphe reFile
   * 
   * @param workspaceJava, nomFichierZip
   */
  public static void moveEllisphereFile(Path ellisphereSpoolout, Path workspaceJava,
      String nomFichierZip) throws IOException {
    Files.move(ellisphereSpoolout.resolve(nomFichierZip), workspaceJava.resolve(nomFichierZip));
  }

  /**
   * Unzip Ellisphe reFile
   * 
   * @param workspaceJava, nomFichierZip
   */
  public static void unzipEllisphereFile(String workspaceJava, String nomFichierZip)
      throws IOException {
    String fileZip = workspaceJava + EllisphereBatchConstants.SLASH + nomFichierZip;
    Path pathUnzip = Paths.get(
        workspaceJava + EllisphereBatchConstants.SLASH + getFileNameBase(nomFichierZip));
    Files.createDirectories(pathUnzip);
    File destDir = new File(pathUnzip.toString());
    byte[] buffer = new byte[1024];
    ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip));
    ZipEntry zipEntry = zis.getNextEntry();
    while (zipEntry != null) {
      final File newFile = newFile(destDir, zipEntry);
      FileOutputStream fos = new FileOutputStream(newFile);
      int len;
      while ((len = zis.read(buffer)) > 0) {
        fos.write(buffer, 0, len);
      }
      fos.close();
      zipEntry = zis.getNextEntry();
    }
    zis.closeEntry();
    zis.close();
  }

  /**
   * New file UnZip
   * 
   * @param File, ZipEntry
   * @return File
   */
  public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
    File destFile = new File(destinationDir, zipEntry.getName());
    String destDirPath = destinationDir.getCanonicalPath();
    String destFilePath = destFile.getCanonicalPath();
    if (!destFilePath.startsWith(destDirPath + File.separator)) {
      throw new IOException("ENTRY IS OUTSIDE OF THE TARGET DIR: " + zipEntry.getName());
    }
    return destFile;
  }

  /**
   * Split String to tab
   * 
   * @param String
   * @return String[]
   */
  public static String getFileNameBase(String fileName) {
    return (fileName.lastIndexOf(EllisphereBatchConstants.POINT) > 0
        ? fileName.substring(0, fileName.lastIndexOf(EllisphereBatchConstants.POINT))
        : fileName);
  }

  /**
   * Archive zip File
   * 
   * @param Path
   */
  public static void moveZipFile(String zipFileName, Path sourceLocation,
      Path destinationLocation) {
    try {
      Files.move(sourceLocation.resolve(zipFileName), destinationLocation.resolve(zipFileName),
          StandardCopyOption.REPLACE_EXISTING);
      LOGGER.info("ZIP FILE : " + zipFileName + " MOVED TO " + destinationLocation);
    } catch (NoSuchFileException e) {
      LOGGER.error("FILE NO EXISTS", e);
    } catch (IOException e) {
      LOGGER.error("MOVING ZIP FILE ERROR ", e);
    }
  }

  /**
   * Delete treated folder
   * 
   * @param Path
   */
  public static void deleteFolderRecursively(Path path) {
    try {
      Files.walk(path).sorted(Comparator.reverseOrder()).map(Path::toFile).forEach(File::delete);
    } catch (NoSuchFileException x) {
      LOGGER.error(path + " NO EXISTS");
    } catch (DirectoryNotEmptyException x) {
      LOGGER.error(path + " DIRECTORY NOT EMPTY");
    } catch (IOException x) {
      LOGGER.error(path + " FILE PERMISSION ISSUE");
    }
  }

  /**
   * Get list files by pattern
   * 
   * @param String
   * @return String
   */
  public static File[] getFilesMatchingPattern(File rootDirectory, String regex) {
    if (!rootDirectory.isDirectory()) {
      throw new IllegalArgumentException(rootDirectory + " IS NO DIRECTORY");
    }
    final Pattern p = Pattern.compile(regex);
    return rootDirectory.listFiles(new FileFilter() {
      @Override
      public boolean accept(File file) {
        return p.matcher(file.getName()).matches();
      }
    });
  }

  /**
   * Parsing Date
   * 
   * @param String
   * @return Date
   */
  public static Date convertStringToDate(String dateInString) {
    SimpleDateFormat formatter =
        new SimpleDateFormat(EllisphereBatchConstants.FILE_DATE_FORMAT, Locale.FRANCE);
    formatter.setTimeZone(TimeZone.getTimeZone(EllisphereBatchConstants.DATE_TIMEZONE));
    Date date = null;
    try {
      date = formatter.parse(dateInString);
    } catch (ParseException e) {
      e.printStackTrace();
    }
    return date;
  }

  /**
   * get Last SuiviAppelEllisphere calling WS BaseTiers
   * 
   * @param String
   * @return SuiviAppelEllisphere
   */
  public static SuiviAppelEllisphere getSuiviAppelEllisByTicket(EllisphereClient ellisphereClient,
      String siren, String noTicket) {
    // Call WS BT : get Tiers by SIREN
    TiersResponse tiersResponse = new TiersResponse();
    try {
      tiersResponse = ellisphereClient.getTiers(siren);
    } catch (Exception e) {
      e.printStackTrace();
      LOGGER.error("GET TIERS ERROR : ", e);
    }
    // get correspondent SuiviAppelEllisphere by noTicket
    SuiviAppelEllisphere suiviAppelEllisByTicket = new SuiviAppelEllisphere();
    if (tiersResponse.getStatus() != null
        && EllisphereClientConstants.SUCCESS_STATUS.equals(tiersResponse.getStatus())
        && tiersResponse.getTiers().getSuiviAppelsEllisphere().size() > 0) {
      suiviAppelEllisByTicket = tiersResponse.getTiers().getSuiviAppelsEllisphere().stream()
          .filter(suivi -> noTicket.equals(suivi.getNoTicket())).findAny().orElse(null);
    }
    return suiviAppelEllisByTicket;
  }

  /**
   * prepare Ged Document Request
   * 
   * @param String, File, BatchGedBean
   * @return PutDocumentRequest
   */
  public static PutDocumentRequest prepareGedDocumentRequest(String siren, File file,
      BatchGedBean gedBean) throws IOException {

    PutDocumentRequest request = new PutDocumentRequest();

    Metadatas meta = new PutDocumentRequest.Metadatas();

    Metadata sirenBenef = new ObjectFactory().createMetadata();
    sirenBenef.setKey(EllisphereBatchConstants.GED_BENEFICIAIRE_SIREN_KEY);
    sirenBenef.setValue(siren);
    meta.getMetadata().add(sirenBenef);

    Metadata documentType = new ObjectFactory().createMetadata();
    documentType.setKey(EllisphereBatchConstants.GED_DOCUMENT_TYPE_KEY);
    documentType.setValue(gedBean.getDocumentType());
    meta.getMetadata().add(documentType);

    Metadata documentOriginal = new ObjectFactory().createMetadata();
    documentOriginal.setKey(EllisphereBatchConstants.GED_DOCUMENT_ORIGINAL_KEY);
    documentOriginal.setValue(gedBean.getDocumentOriginal());
    meta.getMetadata().add(documentOriginal);

    Metadata documentCopie = new ObjectFactory().createMetadata();
    documentCopie.setKey(EllisphereBatchConstants.GED_DOCUMENT_COPIE_KEY);
    documentCopie.setValue(gedBean.getDocumentCopie());
    meta.getMetadata().add(documentCopie);

    Metadata groupeMarche = new ObjectFactory().createMetadata();
    groupeMarche.setKey(EllisphereBatchConstants.GED_GROUPE_MARCHE_KEY);
    groupeMarche.setValue(gedBean.getGroupeMarche());
    meta.getMetadata().add(groupeMarche);

    Metadata idUser = new ObjectFactory().createMetadata();
    idUser.setKey(EllisphereBatchConstants.GED_IDENTIFIANT_UTILISATEUR_KEY);
    idUser.setValue(gedBean.getIdentifiantUtilisateur());
    meta.getMetadata().add(idUser);

    SimpleDateFormat formatter = new SimpleDateFormat(EllisphereBatchConstants.GED_DATE_FORMAT);
    String sDate = formatter.format(new Date());

    Metadata documentDateNum = new ObjectFactory().createMetadata();
    documentDateNum.setKey(EllisphereBatchConstants.GED_DOCUMENT_DATE_NUMERISATION_KEY);
    documentDateNum.setValue(sDate);
    meta.getMetadata().add(documentDateNum);

    Metadata documentDateRecep = new ObjectFactory().createMetadata();
    documentDateRecep.setKey(EllisphereBatchConstants.GED_DOCUMENT_DATE_RECEPTION_KEY);
    documentDateRecep.setValue(sDate);
    meta.getMetadata().add(documentDateRecep);

    byte[] zipContent = Files.readAllBytes(file.toPath());

    request.setFilename(file.getName());
    request.setRawDocument(zipContent);
    request.setNotifyAfterIndexation(false);
    request.setMetadatas(meta);

    return request;

  }



}

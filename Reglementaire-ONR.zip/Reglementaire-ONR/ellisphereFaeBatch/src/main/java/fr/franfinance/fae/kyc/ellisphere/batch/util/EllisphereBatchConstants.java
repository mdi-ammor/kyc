package fr.franfinance.fae.kyc.ellisphere.batch.util;

public final class EllisphereBatchConstants {
    
  public static final String POINT = ".";
  public static final String SLASH = "/";
  public static final String UNDERSCORE = "_";
  public static final String BE_XML_FILE_NAME = "BE.xml";
  public static final String ZIP_FILE_EXTENSION = ".zip";
  public static final String REGEX_BE_XML = ".*_BE.xml";
  public static final String REGEX_LIENS_PDF = "\\d{9}-Link.*.pdf";
  public static final String REGEX_CARTO_PDF = "\\d{9}_Cartographie.pdf";
  
  public static final String FILE_DATE_FORMAT = "yyyyMMddHHmm";
  public static final String DATE_TIMEZONE = "Europe/Paris";
  
  public static final Integer DATE_FORMAT_LENGTH = 12;
  
  public static final String STATUS_GED_OK = "GED_OK";
  public static final String STATUS_GED_KO = "GED_KO";
  public static final String STATUS_ERR = "ERR";
  public static final String STATUS_TRAI = "TRAI";
  
  public static final String GED_BENEFICIAIRE_SIREN_KEY = "BENEFICIAIRE_SIREN";
  public static final String GED_DOCUMENT_TYPE_KEY = "DOCUMENT_TYPE";
  public static final String GED_DOCUMENT_ORIGINAL_KEY = "DOCUMENT_ORIGINAL";
  public static final String GED_DOCUMENT_COPIE_KEY = "DOCUMENT_COPIE";
  public static final String GED_GROUPE_MARCHE_KEY = "GROUPE_MARCHE";
  public static final String GED_IDENTIFIANT_UTILISATEUR_KEY = "IDENTIFIANT_UTILISATEUR";
  public static final String GED_DATE_FORMAT = "dd/MM/YYYY";
  public static final String GED_DOCUMENT_DATE_NUMERISATION_KEY = "DOCUMENT_DATE_NUMERISATION";
  public static final String GED_DOCUMENT_DATE_RECEPTION_KEY = "DOCUMENT_DATE_RECEPTION";  
}

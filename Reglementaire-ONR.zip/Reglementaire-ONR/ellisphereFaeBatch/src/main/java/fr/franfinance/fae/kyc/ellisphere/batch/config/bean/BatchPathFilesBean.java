/**
 * 
 */
package fr.franfinance.fae.kyc.ellisphere.batch.config.bean;

/**
 * @author adeq685
 *
 */
public class BatchPathFilesBean {
  
  private String ellisphereSpoolout;
  private String ellisphereArchive;
  private String workspaceJava;
  private String workspaceSql;
  private String ellisphereReprise;
  
  
  /**
   * @return the ellisphereSpoolout
   */
  public String getEllisphereSpoolout() {
    return ellisphereSpoolout;
  }
  /**
   * @param ellisphereSpoolout the ellisphereSpoolout to set
   */
  public void setEllisphereSpoolout(String ellisphereSpoolout) {
    this.ellisphereSpoolout = ellisphereSpoolout;
  }
  /**
   * @return the ellisphereArchive
   */
  public String getEllisphereArchive() {
    return ellisphereArchive;
  }
  /**
   * @param ellisphereArchive the ellisphereArchive to set
   */
  public void setEllisphereArchive(String ellisphereArchive) {
    this.ellisphereArchive = ellisphereArchive;
  }
  /**
   * @return the workspaceJava
   */
  public String getWorkspaceJava() {
    return workspaceJava;
  }
  /**
   * @param workspaceJava the workspaceJava to set
   */
  public void setWorkspaceJava(String workspaceJava) {
    this.workspaceJava = workspaceJava;
  }
  /**
   * @return the workspaceSql
   */
  public String getWorkspaceSql() {
    return workspaceSql;
  }
  /**
   * @param workspaceSql the workspaceSql to set
   */
  public void setWorkspaceSql(String workspaceSql) {
    this.workspaceSql = workspaceSql;
  }
  /**
   * @return the ellisphereReprise
   */
  public String getEllisphereReprise() {
    return ellisphereReprise;
  }
  /**
   * @param ellisphereReprise the ellisphereReprise to set
   */
  public void setEllisphereReprise(String ellisphereReprise) {
    this.ellisphereReprise = ellisphereReprise;
  }
  
  

}

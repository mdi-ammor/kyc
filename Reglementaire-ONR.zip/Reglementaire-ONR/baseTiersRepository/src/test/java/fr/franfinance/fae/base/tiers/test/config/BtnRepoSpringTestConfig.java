package fr.franfinance.fae.base.tiers.test.config;

import java.util.Properties;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import fr.franfinance.fae.base.tiers.model.database.CaractTier;
import fr.franfinance.fae.base.tiers.model.database.CaractTierLie;
import fr.franfinance.fae.base.tiers.model.database.TiersLie;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTierLie;
import fr.franfinance.fae.base.tiers.model.database.ParamCaractTier;
import fr.franfinance.fae.base.tiers.model.database.SuiviAppelEllisphere;
import fr.franfinance.fae.base.tiers.utils.BtnRepoConstants;

/**
 * @author adeq710
 *
 */

@Configuration
@PropertySources({
    @PropertySource(value = "file:${springConfigPath}/jdbc${envTarget:}.properties",
        ignoreResourceNotFound = true),
    @PropertySource(value = "classpath:../config/jdbc${envTarget:}.properties",
        ignoreResourceNotFound = true),
    @PropertySource(value = "classpath:/config/jdbc${envTarget:}.properties",
        ignoreResourceNotFound = true)})
@EnableTransactionManagement
@ComponentScans(value = {@ComponentScan("fr.franfinance.fae.base.tiers.dao"),
    @ComponentScan("fr.franfinance.fae.base.tiers.service")})
public class BtnRepoSpringTestConfig {

  @Autowired
  private Environment env;

  @Bean
  public DataSource getDataSource() {
    BasicDataSource dataSource = new BasicDataSource();
    dataSource.setDriverClassName(env.getProperty(BtnRepoConstants.JDBC_DRIVER_NAME));
    dataSource.setUrl(env.getProperty(BtnRepoConstants.JDBC_URL));
    dataSource.setUsername(env.getProperty(BtnRepoConstants.JDBC_USERNAME));
    dataSource.setPassword(env.getProperty(BtnRepoConstants.JDBC_PASSWORD));
    return dataSource;
  }

  @Bean
  public LocalSessionFactoryBean getSessionFactory() {
    LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
    sessionFactory.setDataSource(getDataSource());
    sessionFactory.setHibernateProperties(additionalProperties());

    sessionFactory.setAnnotatedClasses(NotationRefTier.class, NotationRefTierLie.class,
        CaractTier.class, CaractTierLie.class, TiersLie.class, ParamCaractTier.class,
        SuiviAppelEllisphere.class);

    return sessionFactory;
  }

  @Bean
  public HibernateTransactionManager getTransactionManager() {
    HibernateTransactionManager transactionManager = new HibernateTransactionManager();
    transactionManager.setSessionFactory(getSessionFactory().getObject());
    return transactionManager;
  }

  Properties additionalProperties() {
    Properties props = new Properties();
    props.put(BtnRepoConstants.HIBERNATE_SHOW_SQL,
        env.getProperty(BtnRepoConstants.HIBERNATE_SHOW_SQL));
    props.put(BtnRepoConstants.HIBERNATE_HBM_DDL_AUTO,
        env.getProperty(BtnRepoConstants.HIBERNATE_HBM_DDL_AUTO));
    props.put(BtnRepoConstants.HIBERNATE_SCHEMA,
        env.getProperty(BtnRepoConstants.HIBERNATE_SCHEMA));
    return props;
  }
}

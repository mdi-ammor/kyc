package fr.franfinance.fae.base.tiers.test;

import java.util.Date;
import org.dozer.DozerBeanMapper;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import fr.franfinance.fae.base.tiers.application.BtnRepoApplication;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;
import fr.franfinance.fae.base.tiers.model.database.SuiviAppelEllisphere;
import fr.franfinance.fae.base.tiers.model.json.TiersJson;
import fr.franfinance.fae.base.tiers.service.BtnRepoService;
import fr.franfinance.fae.base.tiers.test.config.BtnRepoSpringTestConfig;
import fr.franfinance.fae.base.tiers.utils.BaseTiersWsUtil;

public class BtnRepoServiceTestUpdateTiers {
  private static final Logger LOGGER = LoggerFactory.getLogger(BtnRepoApplication.class);
  public static ApplicationContext context;

  @Test
  public void btnRepoService_TestGetTiers() throws Exception {
    // Initialize spring context and get Service bean
    context = new AnnotationConfigApplicationContext(BtnRepoSpringTestConfig.class);
    BtnRepoService btnService = context.getBean(BtnRepoService.class);
    // Get Tier by Siren
    TiersJson tiers =
        BaseTiersWsUtil.convertBtnTierToWsTier(btnService.getTiersBySiren("317959815"));
    NotationRefTier notationRefTier =
        new DozerBeanMapper().map(tiers, NotationRefTier.class);
    //SuiviAppelEllisphere suiviAppelEllisphere = notationRefTier.getSuiviAppelsEllisphere().get(0);
    //Update
    //suiviAppelEllisphere.setCodeRetAppelWsEllis("updatedCode");
    //Object updatedObject = btnService.updateTiers(notationRefTier);
    //System.out.println(updatedObject);
    // Verify result IdTiersBnot
    Assert.assertEquals(tiers.getIdTiersBnot(), 168922);
  }

}

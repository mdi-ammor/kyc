package fr.franfinance.fae.base.tiers.test;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import fr.franfinance.fae.base.tiers.service.BtnRepoService;
import fr.franfinance.fae.base.tiers.test.config.BtnRepoSpringTestConfig;

public class BtnRepoServiceTestCallFluxEllisFunction {

  public static ApplicationContext context;

  @Test
  public void btnRepoService_TestCallFluxElliFunction() throws Exception {
    // Initialize spring context and get Service bean
    context = new AnnotationConfigApplicationContext(BtnRepoSpringTestConfig.class);
    BtnRepoService btnService = context.getBean(BtnRepoService.class);


    // call SQL procedure
    Integer retour = btnService.callFluxElliFunction(-1l);
    Integer retour_2 = btnService.callFluxElliFunction(5661l);
    Assert.assertEquals(retour.intValue(), 0);
    Assert.assertNotEquals(retour_2.intValue(), 0);
  }
}

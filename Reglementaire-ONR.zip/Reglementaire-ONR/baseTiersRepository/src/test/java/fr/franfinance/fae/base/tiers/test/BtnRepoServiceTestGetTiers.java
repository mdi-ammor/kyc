package fr.franfinance.fae.base.tiers.test;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.franfinance.fae.base.tiers.application.BtnRepoApplication;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;
import fr.franfinance.fae.base.tiers.model.json.TiersJson;
import fr.franfinance.fae.base.tiers.service.BtnRepoService;
import fr.franfinance.fae.base.tiers.test.config.BtnRepoSpringTestConfig;
import fr.franfinance.fae.base.tiers.utils.BaseTiersWsUtil;

public class BtnRepoServiceTestGetTiers {
  private static final Logger LOGGER = LoggerFactory.getLogger(BtnRepoApplication.class);
  public static ApplicationContext context;

  @Test
  public void btnRepoService_TestGetTiers() throws Exception {
    // Initialize spring context and get Service bean
    context = new AnnotationConfigApplicationContext(BtnRepoSpringTestConfig.class);
    BtnRepoService btnService = context.getBean(BtnRepoService.class);
    // Get Tier by Siren
    NotationRefTier notationRefTier = btnService.getTiersBySiren("418044178");
    TiersJson tiers =
        BaseTiersWsUtil.convertBtnTierToWsTier(notationRefTier);
    LOGGER.info("+++ NotationRefTier =  " + notationRefTier + " +++");
    LOGGER.info("+++ TIERS =  " + tiers + " +++");
    // Serialization
    ObjectMapper mapper = new ObjectMapper();
    // Object to JSON in String
    String tierJson = mapper.writeValueAsString(tiers);
    LOGGER.info("+++ TIERS JSON =  " + tierJson + " +++");
    Assert.assertEquals(tiers.getIdTiersBnot(), 168922);
  }

}

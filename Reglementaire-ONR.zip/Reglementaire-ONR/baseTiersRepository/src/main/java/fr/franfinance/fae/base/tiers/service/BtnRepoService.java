package fr.franfinance.fae.base.tiers.service;

import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;

public interface BtnRepoService {
	
	public NotationRefTier getTiersBySiren(String siren) throws Exception;
	public NotationRefTier updateTiers(NotationRefTier tiers);
	public Integer callFluxElliFunction(Long refAppel);
	public Integer callCreateTiersFunction (String siren);
}

package fr.franfinance.fae.base.tiers.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import fr.franfinance.fae.base.tiers.dao.BtnRepoDao;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;
import fr.franfinance.fae.base.tiers.service.BtnRepoService;

@Service
public class BtnRepoServiceImpl implements BtnRepoService {

  private static final Logger LOGGER = LoggerFactory.getLogger(BtnRepoServiceImpl.class);

  @Autowired
  private BtnRepoDao btnServiceDao;

  @Transactional
  public NotationRefTier getTiersBySiren(String siren) throws Exception {
    LOGGER.info("=========== LANCEMENT GET TIERS BY SIREN = " + siren + " ===========");
    NotationRefTier tiers = btnServiceDao.getTiersBySiren(siren);
    LOGGER.info("+++ TIERS =  " + tiers + " +++");
    LOGGER.info("=========== FIN GET TIERS ===========================================");
    return tiers;
  }

  @Transactional
  public NotationRefTier updateTiers(NotationRefTier tiers) {
    LOGGER.info("=========== LANCEMENT UPDATE TIERS = " + tiers.getSiren() + " ===========");
    NotationRefTier tiersUpdated = btnServiceDao.updateTiers(tiers);
    LOGGER.info("+++ TIERS =  " + tiers + " +++");
    LOGGER.info("=========== FIN UPDATE TIERS ===========================================");
    return tiersUpdated;
  }
  
 
  @Transactional
  public Integer callFluxElliFunction(Long refAppel) {
    LOGGER.info("=========== LANCEMENT APPEL PROCDURE SQL = ");
    return btnServiceDao.callFluxElliFunction(refAppel);
  }

  @Transactional
  public Integer callCreateTiersFunction(String siren) {
    LOGGER.info("=========== LANCEMENT APPEL PROCDURE SQL CREATION TIERS = ");
    return btnServiceDao.callCreateTiersFunction(siren);
  }
}

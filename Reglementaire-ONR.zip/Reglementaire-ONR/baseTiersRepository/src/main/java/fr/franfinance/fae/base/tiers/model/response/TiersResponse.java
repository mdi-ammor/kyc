package fr.franfinance.fae.base.tiers.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import fr.franfinance.fae.base.tiers.model.json.TiersJson;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TiersResponse {
  private TiersJson tiers;
  private ResponseError error;
  private String status;


  public TiersJson getTiers() {
    return tiers;
  }

  public void setTiers(TiersJson tiers) {
    this.tiers = tiers;
  }

  public ResponseError getError() {
    return error;
  }

  public void setError(ResponseError error) {
    this.error = error;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  @Override
  public String toString() {
    return "TiersResponse [tiers=" + tiers + ", error=" + error + ", status=" + status + "]";
  }
}

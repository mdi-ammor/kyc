package fr.franfinance.fae.base.tiers.exceptions;

public class TechnicalException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private String code;
  private String message;

  public TechnicalException(String code, String message) {
    this.code = code;
    this.message = message;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

//  public FccrToken getTokenException() {
//    FccrToken response = new FccrToken();
//    Errors errors = new Errors();
//    errors.setCode(code);
//    errors.setMessage(message);
//    response.setErrors(errors);
//    return response;
//  }
//  
//  public CustomerResponse getTechnicalException() {
//    CustomerResponse response = new CustomerResponse();
//    Errors errors = new Errors();
//    errors.setCode(code);
//    errors.setMessage(message);
//    List<Errors> errorList = new ArrayList<>();
//    errorList.add(errors);
//    response.setErrors(errorList);
//    response.setStatus(Constants.FAILURE_STATUS);
//    return response;
//  }

  @Override
  public String toString() {
    return "InternalServerErrorException [code=" + code + ", message=" + message + "]";
  }
}

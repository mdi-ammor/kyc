package fr.franfinance.fae.base.tiers.model.database;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Where;

@Entity
@Table(name = "NOTATION_REF_TIERS")
@DynamicUpdate
public class NotationRefTier implements Serializable {

  private static final long serialVersionUID = 1L;

  private long idTiersBnot;
  private String codePostal;
  private String codeStatut;
  private Date dateCreation;
  private Date dateMaj;
  private Date dateNaissance;
  private String idRct;
  private BigDecimal idUniqueTiersBii;
  private String lieuNaissance;
  private String nom;
  private String nomMarital;
  private String nomNaissance;
  private String pays;
  private String paysNaissance;
  private String prenom;
  private String raisoc;
  private String siren;
  private String tvaIntercomm;

  private List<CaractTier> caractTiers;
  private List<TiersLie> tiersLies;
  private List<SuiviAppelEllisphere> suiviAppelsEllisphere;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BNOT_REF_TIERS_SQ")
  @SequenceGenerator(name = "BNOT_REF_TIERS_SQ", sequenceName = "BNOT_REF_TIERS_SQ",
      allocationSize = 1, initialValue = 1)
  @Column(name = "ID_TIERS_BNOT")
  public long getIdTiersBnot() {
    return this.idTiersBnot;
  }

  public void setIdTiersBnot(long idTiersBnot) {
    this.idTiersBnot = idTiersBnot;
  }

  @Column(name = "CODE_POSTAL")
  public String getCodePostal() {
    return this.codePostal;
  }

  public void setCodePostal(String codePostal) {
    this.codePostal = codePostal;
  }

  @Column(name = "CODE_STATUT")
  public String getCodeStatut() {
    return this.codeStatut;
  }

  public void setCodeStatut(String codeStatut) {
    this.codeStatut = codeStatut;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_CREATION")
  public Date getDateCreation() {
    return this.dateCreation;
  }

  public void setDateCreation(Date dateCreation) {
    this.dateCreation = dateCreation;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_MAJ")
  public Date getDateMaj() {
    return this.dateMaj;
  }

  public void setDateMaj(Date dateMaj) {
    this.dateMaj = dateMaj;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_NAISSANCE")
  public Date getDateNaissance() {
    return this.dateNaissance;
  }

  public void setDateNaissance(Date dateNaissance) {
    this.dateNaissance = dateNaissance;
  }

  @Column(name = "ID_RCT")
  public String getIdRct() {
    return this.idRct;
  }

  public void setIdRct(String idRct) {
    this.idRct = idRct;
  }

  @Column(name = "ID_UNIQUE_TIERS_BII")
  public BigDecimal getIdUniqueTiersBii() {
    return this.idUniqueTiersBii;
  }

  public void setIdUniqueTiersBii(BigDecimal idUniqueTiersBii) {
    this.idUniqueTiersBii = idUniqueTiersBii;
  }

  @Column(name = "LIEU_NAISSANCE")
  public String getLieuNaissance() {
    return this.lieuNaissance;
  }

  public void setLieuNaissance(String lieuNaissance) {
    this.lieuNaissance = lieuNaissance;
  }

  @Column(name = "NOM")
  public String getNom() {
    return this.nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }

  @Column(name = "NOM_MARITAL")
  public String getNomMarital() {
    return this.nomMarital;
  }

  public void setNomMarital(String nomMarital) {
    this.nomMarital = nomMarital;
  }

  @Column(name = "NOM_NAISSANCE")
  public String getNomNaissance() {
    return this.nomNaissance;
  }

  public void setNomNaissance(String nomNaissance) {
    this.nomNaissance = nomNaissance;
  }

  @Column(name = "PAYS")
  public String getPays() {
    return this.pays;
  }

  public void setPays(String pays) {
    this.pays = pays;
  }


  @Column(name = "PAYS_NAISSANCE")
  public String getPaysNaissance() {
    return this.paysNaissance;
  }

  public void setPaysNaissance(String paysNaissance) {
    this.paysNaissance = paysNaissance;
  }

  @Column(name = "PRENOM")
  public String getPrenom() {
    return this.prenom;
  }

  public void setPrenom(String prenom) {
    this.prenom = prenom;
  }

  @Column(name = "RAISOC")
  public String getRaisoc() {
    return this.raisoc;
  }

  public void setRaisoc(String raisoc) {
    this.raisoc = raisoc;
  }

  @Column(name = "SIREN")
  public String getSiren() {
    return this.siren;
  }

  public void setSiren(String siren) {
    this.siren = siren;
  }

  @Column(name = "TVA_INTERCOMM")
  public String getTvaIntercomm() {
    return this.tvaIntercomm;
  }

  public void setTvaIntercomm(String tvaIntercomm) {
    this.tvaIntercomm = tvaIntercomm;
  }

  @OneToMany(mappedBy = "notationRefTier", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @Where(clause = "CODE_STATUT = 'EXPL'")
  @Fetch(value = FetchMode.SUBSELECT)
  public List<TiersLie> getTiersLies() {
    return tiersLies;
  }

  public void setTiersLies(List<TiersLie> tiersLies) {
    this.tiersLies = tiersLies;
  }

  @OneToMany(mappedBy = "notationRefTier", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @Fetch(value = FetchMode.SUBSELECT)
  public List<CaractTier> getCaractTiers() {
    return this.caractTiers;
  }

  public void setCaractTiers(List<CaractTier> caractTiers) {
    this.caractTiers = caractTiers;
  }

  @OneToMany(mappedBy = "notationRefTier", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  public List<SuiviAppelEllisphere> getSuiviAppelsEllisphere() {
    return suiviAppelsEllisphere;
  }

  public void setSuiviAppelsEllisphere(List<SuiviAppelEllisphere> suiviAppelsEllisphere) {
    this.suiviAppelsEllisphere = suiviAppelsEllisphere;
  }

  @Override
  public String toString() {
    return "NotationRefTier [idTiersBnot=" + idTiersBnot + ", codePostal=" + codePostal
        + ", codeStatut=" + codeStatut + ", dateCreation=" + dateCreation + ", dateMaj=" + dateMaj
        + ", dateNaissance=" + dateNaissance + ", idRct=" + idRct + ", idUniqueTiersBii="
        + idUniqueTiersBii + ", lieuNaissance=" + lieuNaissance + ", nom=" + nom + ", nomMarital="
        + nomMarital + ", nomNaissance=" + nomNaissance + ", pays=" + pays + ", paysNaissance="
        + paysNaissance + ", prenom=" + prenom + ", raisoc=" + raisoc + ", siren=" + siren
        + ", tvaIntercomm=" + tvaIntercomm + ", tiersLies=" + tiersLies + ", suiviAppelsEllisphere=" + suiviAppelsEllisphere + "]";
  }

}

package fr.franfinance.fae.base.tiers.model.database;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.DynamicUpdate;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "CARACT_TIERS")
@DynamicUpdate
public class CaractTier implements Serializable {

  private static final long serialVersionUID = 1L;

  private long idCaractTiers;
  private long idTiersBnot;
  private String codeCaract;
  private String codeProvenance;
  private String commentaire;
  private String complProvenance;
  private Date dateDebutValidite;
  private Date dateDerniereRecept;
  private Date dateFct1;
  private Date dateFct2;
  private String idProvenance;
  private String idProvenanceDerniere;
  private String provenanceDerniereRecept;
  private String valeurCaract1;
  private String valeurCaract2;
  private String valeurCaract3;
  private String valeurCaract4;
  private NotationRefTier notationRefTier;
  private ParamCaractTier paramCaractTier;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CARACT_TIERS_SQ")
  @SequenceGenerator(name = "CARACT_TIERS_SQ", sequenceName = "CARACT_TIERS_SQ", allocationSize = 1,
      initialValue = 1)
  @Column(name = "ID_CARACT_TIERS")
  public long getIdCaractTiers() {
    return this.idCaractTiers;
  }

  public void setIdCaractTiers(long idCaractTiers) {
    this.idCaractTiers = idCaractTiers;
  }

  @Column(name = "ID_TIERS_BNOT")
  public long getIdTiersBnot() {
    return idTiersBnot;
  }

  public void setIdTiersBnot(long idTiersBnot) {
    this.idTiersBnot = idTiersBnot;
  }

  @Column(name = "CODE_CARACT")
  public String getCodeCaract() {
    return codeCaract;
  }

  public void setCodeCaract(String codeCaract) {
    this.codeCaract = codeCaract;
  }

  @Column(name = "CODE_PROVENANCE")
  public String getCodeProvenance() {
    return this.codeProvenance;
  }

  public void setCodeProvenance(String codeProvenance) {
    this.codeProvenance = codeProvenance;
  }

  @Column(name = "COMMENTAIRE")
  public String getCommentaire() {
    return this.commentaire;
  }

  public void setCommentaire(String commentaire) {
    this.commentaire = commentaire;
  }


  @Column(name = "COMPL_PROVENANCE")
  public String getComplProvenance() {
    return this.complProvenance;
  }

  public void setComplProvenance(String complProvenance) {
    this.complProvenance = complProvenance;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_DEBUT_VALIDITE")
  public Date getDateDebutValidite() {
    return this.dateDebutValidite;
  }

  public void setDateDebutValidite(Date dateDebutValidite) {
    this.dateDebutValidite = dateDebutValidite;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_DERNIERE_RECEPT")
  public Date getDateDerniereRecept() {
    return this.dateDerniereRecept;
  }

  public void setDateDerniereRecept(Date dateDerniereRecept) {
    this.dateDerniereRecept = dateDerniereRecept;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_FCT1")
  public Date getDateFct1() {
    return this.dateFct1;
  }

  public void setDateFct1(Date dateFct1) {
    this.dateFct1 = dateFct1;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_FCT2")
  public Date getDateFct2() {
    return this.dateFct2;
  }

  public void setDateFct2(Date dateFct2) {
    this.dateFct2 = dateFct2;
  }


  @Column(name = "ID_PROVENANCE")
  public String getIdProvenance() {
    return this.idProvenance;
  }

  public void setIdProvenance(String idProvenance) {
    this.idProvenance = idProvenance;
  }


  @Column(name = "ID_PROVENANCE_DERNIERE")
  public String getIdProvenanceDerniere() {
    return this.idProvenanceDerniere;
  }

  public void setIdProvenanceDerniere(String idProvenanceDerniere) {
    this.idProvenanceDerniere = idProvenanceDerniere;
  }


  @Column(name = "PROVENANCE_DERNIERE_RECEPT")
  public String getProvenanceDerniereRecept() {
    return this.provenanceDerniereRecept;
  }

  public void setProvenanceDerniereRecept(String provenanceDerniereRecept) {
    this.provenanceDerniereRecept = provenanceDerniereRecept;
  }


  @Column(name = "VALEUR_CARACT1")
  public String getValeurCaract1() {
    return this.valeurCaract1;
  }

  public void setValeurCaract1(String valeurCaract1) {
    this.valeurCaract1 = valeurCaract1;
  }


  @Column(name = "VALEUR_CARACT2")
  public String getValeurCaract2() {
    return this.valeurCaract2;
  }

  public void setValeurCaract2(String valeurCaract2) {
    this.valeurCaract2 = valeurCaract2;
  }


  @Column(name = "VALEUR_CARACT3")
  public String getValeurCaract3() {
    return this.valeurCaract3;
  }

  public void setValeurCaract3(String valeurCaract3) {
    this.valeurCaract3 = valeurCaract3;
  }


  @Column(name = "VALEUR_CARACT4")
  public String getValeurCaract4() {
    return this.valeurCaract4;
  }

  public void setValeurCaract4(String valeurCaract4) {
    this.valeurCaract4 = valeurCaract4;
  }

  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "ID_TIERS_BNOT", insertable = false, updatable = false)
  @JsonIgnore
  public NotationRefTier getNotationRefTier() {
    return this.notationRefTier;
  }

  public void setNotationRefTier(NotationRefTier notationRefTier) {
    this.notationRefTier = notationRefTier;
  }

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "CODE_CARACT", insertable = false, updatable = false)
  public ParamCaractTier getParamCaractTier() {
    return this.paramCaractTier;
  }

  public void setParamCaractTier(ParamCaractTier paramCaractTier) {
    this.paramCaractTier = paramCaractTier;
  }

  @Override
  public String toString() {
    return "CaractTier [idCaractTiers=" + idCaractTiers + ", idTiersBnot=" + idTiersBnot
        + ", codeCaract=" + codeCaract + ", codeProvenance=" + codeProvenance + ", commentaire="
        + commentaire + ", complProvenance=" + complProvenance + ", dateDebutValidite="
        + dateDebutValidite + ", dateDerniereRecept=" + dateDerniereRecept + ", dateFct1="
        + dateFct1 + ", dateFct2=" + dateFct2 + ", idProvenance=" + idProvenance
        + ", idProvenanceDerniere=" + idProvenanceDerniere + ", provenanceDerniereRecept="
        + provenanceDerniereRecept + ", valeurCaract1=" + valeurCaract1 + ", valeurCaract2="
        + valeurCaract2 + ", valeurCaract3=" + valeurCaract3 + ", valeurCaract4=" + valeurCaract4
        + ", notationRefTier=" + notationRefTier + ", paramCaractTier=" + paramCaractTier + "]";
  }

}

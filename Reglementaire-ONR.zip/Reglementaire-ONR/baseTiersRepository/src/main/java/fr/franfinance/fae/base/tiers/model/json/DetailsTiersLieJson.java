package fr.franfinance.fae.base.tiers.model.json;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import fr.franfinance.fae.base.tiers.utils.BtnRepoConstants;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DetailsTiersLieJson implements Serializable {

  private static final long serialVersionUID = 1L;

  private long idTiersBnot;
  private String codePostal;
  private String adresse;
  private String ville;
  private String codeStatut;
  private Date dateCreation;
  private Date dateMaj;
  private Date dateNaissance;
  private String idRct;
  private BigDecimal idUniqueTiersBii;
  private String lieuNaissance;
  private String civilite;
  private String nom;
  private String nomMarital;
  private String nomNaissance;
  private String pays;
  private String paysNaissance;
  private String prenom;
  private String raisoc;
  private String siren;
  private String tvaIntercomm;

  private List<CaractTiersJson> caractTiers;

  public long getIdTiersBnot() {
    return this.idTiersBnot;
  }

  public void setIdTiersBnot(long idTiersBnot) {
    this.idTiersBnot = idTiersBnot;
  }

  public String getAdresse() {
    return adresse;
  }

  public void setAdresse(String adresse) {
    this.adresse = adresse;
  }

  public String getCodePostal() {
    return this.codePostal;
  }

  public void setCodePostal(String codePostal) {
    this.codePostal = codePostal;
  }

  public String getVille() {
    return ville;
  }

  public void setVille(String ville) {
    this.ville = ville;
  }

  public String getCodeStatut() {
    return this.codeStatut;
  }

  public void setCodeStatut(String codeStatut) {
    this.codeStatut = codeStatut;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateCreation() {
    return this.dateCreation;
  }

  public void setDateCreation(Date dateCreation) {
    this.dateCreation = dateCreation;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateMaj() {
    return this.dateMaj;
  }

  public void setDateMaj(Date dateMaj) {
    this.dateMaj = dateMaj;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateNaissance() {
    return this.dateNaissance;
  }

  public void setDateNaissance(Date dateNaissance) {
    this.dateNaissance = dateNaissance;
  }

  public String getIdRct() {
    return this.idRct;
  }

  public void setIdRct(String idRct) {
    this.idRct = idRct;
  }

  public BigDecimal getIdUniqueTiersBii() {
    return this.idUniqueTiersBii;
  }

  public void setIdUniqueTiersBii(BigDecimal idUniqueTiersBii) {
    this.idUniqueTiersBii = idUniqueTiersBii;
  }

  public String getLieuNaissance() {
    return this.lieuNaissance;
  }

  public void setLieuNaissance(String lieuNaissance) {
    this.lieuNaissance = lieuNaissance;
  }

  public String getCivilite() {
    return civilite;
  }

  public void setCivilite(String civilite) {
    this.civilite = civilite;
  }

  public String getNom() {
    return this.nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }

  public String getNomMarital() {
    return this.nomMarital;
  }

  public void setNomMarital(String nomMarital) {
    this.nomMarital = nomMarital;
  }

  public String getNomNaissance() {
    return this.nomNaissance;
  }

  public void setNomNaissance(String nomNaissance) {
    this.nomNaissance = nomNaissance;
  }

  public String getPays() {
    return this.pays;
  }

  public void setPays(String pays) {
    this.pays = pays;
  }

  public String getPaysNaissance() {
    return this.paysNaissance;
  }

  public void setPaysNaissance(String paysNaissance) {
    this.paysNaissance = paysNaissance;
  }

  public String getPrenom() {
    return this.prenom;
  }

  public void setPrenom(String prenom) {
    this.prenom = prenom;
  }

  public String getRaisoc() {
    return this.raisoc;
  }

  public void setRaisoc(String raisoc) {
    this.raisoc = raisoc;
  }

  public String getSiren() {
    return this.siren;
  }

  public void setSiren(String siren) {
    this.siren = siren;
  }

  public String getTvaIntercomm() {
    return this.tvaIntercomm;
  }

  public void setTvaIntercomm(String tvaIntercomm) {
    this.tvaIntercomm = tvaIntercomm;
  }

  @JsonIgnore
  public List<CaractTiersJson> getCaractTiers() {
    return caractTiers;
  }

  public void setCaractTiers(List<CaractTiersJson> caractTiers) {
    this.caractTiers = caractTiers;
  }

  @Override
  public String toString() {
    return "NotationRefTier [idTiersBnot=" + idTiersBnot + ", codePostal=" + codePostal
        + ", codeStatut=" + codeStatut + ", dateCreation=" + dateCreation + ", dateMaj=" + dateMaj
        + ", dateNaissance=" + dateNaissance + ", idRct=" + idRct + ", idUniqueTiersBii="
        + idUniqueTiersBii + ", lieuNaissance=" + lieuNaissance + ", nom=" + nom + ", nomMarital="
        + nomMarital + ", nomNaissance=" + nomNaissance + ", pays=" + pays + ", paysNaissance="
        + paysNaissance + ", prenom=" + prenom + ", raisoc=" + raisoc + ", siren=" + siren
        + ", tvaIntercomm=" + tvaIntercomm + "]";
  }
}

package fr.franfinance.fae.base.tiers.dao.impl;

import java.sql.CallableStatement;
import java.sql.Types;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import fr.franfinance.fae.base.tiers.dao.BtnRepoDao;
import fr.franfinance.fae.base.tiers.exceptions.TechnicalException;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;
import fr.franfinance.fae.base.tiers.utils.BtnRepoConstants;

@Repository
public class BtnRepoDaoImpl implements BtnRepoDao {

  @Autowired
  private SessionFactory session;

  @Override
  public NotationRefTier getTiersBySiren(String siren) {
    CriteriaBuilder builder = session.getCurrentSession().getCriteriaBuilder();
    CriteriaQuery<NotationRefTier> criteria = builder.createQuery(NotationRefTier.class);
    Root<NotationRefTier> tier = criteria.from(NotationRefTier.class);
    Predicate[] predicates = new Predicate[2];
    predicates[0] = builder.equal(tier.get("siren"), siren);
    predicates[1] = builder.isNull(tier.get("codeStatut"));
    criteria.select(tier).where(predicates);
    Query<NotationRefTier> query = session.getCurrentSession().createQuery(criteria);
    List<NotationRefTier> notationRefTierList = query.getResultList();
    NotationRefTier notationRefTier = null;
    if (notationRefTierList.size() > 0) {
      notationRefTier = notationRefTierList.get(0);
    } else {
      throw new TechnicalException(BtnRepoConstants.DATA_ERROR_CODE,
          BtnRepoConstants.DATA_ERROR_MESSAGE);
    }
    return notationRefTier;
  }


  public Integer callFluxElliFunction(Long refAppel) {

    return session.getCurrentSession().doReturningWork(connection -> {
      try (CallableStatement function =
          connection.prepareCall("{ ? = call ONR.F_TRT_FLUX_ELLIS(?,?) }")) {
        function.registerOutParameter(1, Types.NUMERIC);
        function.setLong(2, refAppel);
        function.setString(3, "FALSE");
        function.execute();
        return function.getInt(1);
      }
    });

  }

  @Override
  public NotationRefTier updateTiers(NotationRefTier tiers) {
    session.getCurrentSession().update(tiers);
    return tiers;
  }

  public SessionFactory getSession() {
    return session;
  }

  public void setSession(SessionFactory session) {
    this.session = session;
  }


  @Override
  public Integer callCreateTiersFunction(String siren) {
    return session.getCurrentSession().doReturningWork(connection -> {
      try (CallableStatement function =
          connection.prepareCall("{ ? = call ONR.F_NEW_TIERS(?) }")) {
        function.registerOutParameter(1, Types.NUMERIC);
        function.setString(2, siren);
        function.execute();
        return function.getInt(1);
      }
    });
  }

}

package fr.franfinance.fae.base.tiers.model.database;

import java.io.Serializable;
import javax.persistence.*;
import org.hibernate.annotations.DynamicUpdate;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "NATURE_LIEN")
@DynamicUpdate
public class TiersLie implements Serializable {

  private static final long serialVersionUID = 1L;

  private String natureLien;
  private Long idNatureLien;
  private String codeProvenance;
  private String codeStatut;
  private Date dateFonction;
  private Date dateInsertLien;
  private Date dateMajLien;
  private String fonction;
  private String idProvenance;
  private BigDecimal pctDetention;
  private String typeTiersLie;

  private NotationRefTier notationRefTier;
  private NotationRefTierLie detailsTiersLie;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NATURE_LIEN_SQ")
  @SequenceGenerator(name = "NATURE_LIEN_SQ", sequenceName = "NATURE_LIEN_SQ", allocationSize = 1,
      initialValue = 1)
  @Column(name = "ID_NATURE_LIEN")
  public Long getIdNatureLien() {
    return this.idNatureLien;
  }

  public void setIdNatureLien(Long idNatureLien) {
    this.idNatureLien = idNatureLien;
  }

  @Column(name = "NATURE_LIEN")
  public String getNatureLien() {
    return this.natureLien;
  }

  public void setNatureLien(String natureLien) {
    this.natureLien = natureLien;
  }

  @Column(name = "CODE_PROVENANCE")
  public String getCodeProvenance() {
    return this.codeProvenance;
  }

  public void setCodeProvenance(String codeProvenance) {
    this.codeProvenance = codeProvenance;
  }


  @Column(name = "CODE_STATUT")
  public String getCodeStatut() {
    return this.codeStatut;
  }

  public void setCodeStatut(String codeStatut) {
    this.codeStatut = codeStatut;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_FONCTION")
  public Date getDateFonction() {
    return this.dateFonction;
  }

  public void setDateFonction(Date dateFonction) {
    this.dateFonction = dateFonction;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_INSERT_LIEN")
  public Date getDateInsertLien() {
    return this.dateInsertLien;
  }

  public void setDateInsertLien(Date dateInsertLien) {
    this.dateInsertLien = dateInsertLien;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_MAJ_LIEN")
  public Date getDateMajLien() {
    return this.dateMajLien;
  }

  public void setDateMajLien(Date dateMajLien) {
    this.dateMajLien = dateMajLien;
  }

  @Column(name = "FONCTION")
  public String getFonction() {
    return this.fonction;
  }

  public void setFonction(String fonction) {
    this.fonction = fonction;
  }


  @Column(name = "ID_PROVENANCE")
  public String getIdProvenance() {
    return this.idProvenance;
  }

  public void setIdProvenance(String idProvenance) {
    this.idProvenance = idProvenance;
  }

  @Column(name = "PCT_DETENTION")
  public BigDecimal getPctDetention() {
    return this.pctDetention;
  }

  public void setPctDetention(BigDecimal pctDetention) {
    this.pctDetention = pctDetention;
  }

  @Column(name = "TYPE_TIERS_LIE")
  public String getTypeTiersLie() {
    return this.typeTiersLie;
  }

  public void setTypeTiersLie(String typeTiersLie) {
    this.typeTiersLie = typeTiersLie;
  }

  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "ID_TIERS_BNOT", insertable = false, updatable = false)
  @JsonIgnore
  public NotationRefTier getNotationRefTier() {
    return notationRefTier;
  }

  public void setNotationRefTier(NotationRefTier notationRefTier) {
    this.notationRefTier = notationRefTier;
  }
  
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "ID_TIERS_BNOT_LIE", insertable = false, updatable = false)
  @JsonIgnore
  public NotationRefTierLie getDetailsTiersLie() {
    return detailsTiersLie;
  }

  public void setDetailsTiersLie(NotationRefTierLie detailsTiersLie) {
    this.detailsTiersLie = detailsTiersLie;
  }

  @Override
  public String toString() {
    return "NatureLien [natureLien=" + natureLien + ", idNatureLien=" + idNatureLien
        + ", codeProvenance=" + codeProvenance + ", codeStatut=" + codeStatut + ", dateFonction="
        + dateFonction + ", dateInsertLien=" + dateInsertLien + ", dateMajLien=" + dateMajLien
        + ", fonction=" + fonction + ", idProvenance=" + idProvenance + ", pctDetention="
        + pctDetention + ", typeTiersLie=" + typeTiersLie + "]";
  }
}

package fr.franfinance.fae.base.tiers.utils;

import java.util.Collections;
import org.dozer.DozerBeanMapper;
import fr.franfinance.fae.base.tiers.exceptions.TechnicalException;
import fr.franfinance.fae.base.tiers.model.database.CaractTier;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;
import fr.franfinance.fae.base.tiers.model.json.CaractTiersJson;
import fr.franfinance.fae.base.tiers.model.json.DetailsTiersLieJson;
import fr.franfinance.fae.base.tiers.model.json.TiersJson;
import fr.franfinance.fae.base.tiers.model.json.TiersLieJson;

public class BaseTiersWsUtil {

  /**
   * @RequestParam NotationRefTier
   * @return TiersJson
   **/
  public static TiersJson convertBtnTierToWsTier(NotationRefTier notationRefTier) {
    TiersJson tierJson = new TiersJson();
    try {
      tierJson = new DozerBeanMapper().map(notationRefTier, TiersJson.class);
      for (CaractTiersJson caractTiersJson : emptyIfNull(tierJson.getCaractTiers())) {
        // Set fields names for caractTiersJson
        CaractTier caractTier = notationRefTier.getCaractTiers().stream()
            .filter(c -> caractTiersJson.getCodeCaract().equals(c.getCodeCaract())).findAny()
            .orElse(null);
        caractTiersJson.setNomDateFct1(caractTier.getParamCaractTier().getNomDateFct1());
        caractTiersJson.setNomDateFct2(caractTier.getParamCaractTier().getNomDateFct2());
        caractTiersJson.setNomCaract1(caractTier.getParamCaractTier().getNomCaract1());
        caractTiersJson.setNomCaract2(caractTier.getParamCaractTier().getNomCaract2());
        caractTiersJson.setNomCaract3(caractTier.getParamCaractTier().getNomCaract3());
        caractTiersJson.setNomCaract4(caractTier.getParamCaractTier().getNomCaract4());
        caractTiersJson.setIdTiersBnot(notationRefTier.getIdTiersBnot());
        // Set adress for tiersJson
        if (BtnRepoConstants.CODE_CARACT_ADRESSE.equals(caractTier.getCodeCaract())) {
          tierJson.setAdresse(caractTier.getValeurCaract1());
          tierJson.setCodePostal(caractTier.getValeurCaract2());
          tierJson.setVille(caractTier.getValeurCaract3());
        }
      }
      // Set adress and civility for tiersLieJson
      for (TiersLieJson tiersLieJson : emptyIfNull(tierJson.getTiersLies())) {
        DetailsTiersLieJson detailsTiersLieJson = tiersLieJson.getDetailsTiersLie();
        for (CaractTiersJson caractTiersLie : emptyIfNull(detailsTiersLieJson.getCaractTiers())) {
          if (BtnRepoConstants.CODE_CARACT_ADRESSE.equals(caractTiersLie.getCodeCaract())) {
            detailsTiersLieJson.setAdresse(caractTiersLie.getValeurCaract1());
            detailsTiersLieJson.setCodePostal(caractTiersLie.getValeurCaract2());
            detailsTiersLieJson.setVille(caractTiersLie.getValeurCaract3());
          }
          if (BtnRepoConstants.CODE_CARACT_CIVILITE.equals(caractTiersLie.getCodeCaract())) {
            detailsTiersLieJson.setCivilite(caractTiersLie.getValeurCaract1());
          }
        }
      }
    } catch (Exception e) {
      throw new TechnicalException(BtnRepoConstants.TECHNICAL_ERROR_CODE,
          BtnRepoConstants.TECHNICAL_ERROR_MESSAGE);
    }
    return tierJson;
  }

  // Avoid null List in for loop
  public static <T> Iterable<T> emptyIfNull(Iterable<T> iterable) {
    return iterable == null ? Collections.<T>emptyList() : iterable;
  }
}

package fr.franfinance.fae.base.tiers.utils;

public class BtnRepoConstants {
  
  public static final String JDBC_DRIVER_NAME = "jdbc.driverClassName";
  public static final String JDBC_URL = "jdbc.databaseurl";
  public static final String JDBC_USERNAME = "jdbc.username";
  public static final String JDBC_PASSWORD = "jdbc.password";
  public static final String JNDI_URL = "jndi.url";
  
  public static final String HIBERNATE_SHOW_SQL = "hibernate.show_sql";
  public static final String HIBERNATE_HBM_DDL_AUTO = "hibernate.hbm2ddl.auto";
  public static final String HIBERNATE_SCHEMA = "hibernate.default_schema";
  
  public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
  public static final String DATE_LOCALE = "fr-FR";
  public static final String DATE_TIMEZONE = "Europe/Paris";
  public static final String CODE_CARACT_ADRESSE = "ADRESSE";
  public static final String CODE_CARACT_CIVILITE = "CIVILITE";
  public static final String STATUS_SUCCESS = "SUCCESS";
  public static final String STATUS_FAILURE = "FAILURE";
  
  public static final String TECHNICAL_ERROR_CODE = "303";
  public static final String TECHNICAL_ERROR_MESSAGE = "TECHNICAL_PROBLEM";
  
  public static final String DATA_ERROR_CODE = "205";
  public static final String DATA_ERROR_MESSAGE = "DATA_NOT_FOUND";
  public static final String DATA_UPDATE_ERROR_MESSAGE = "DATA_UPDATE_PROBLEM";
   
  public static final String UNAUTHORIZED_DATA_ACCESS_CODE = "207";
  public static final String UNAUTHORIZED_DATA_ACCESS_MESSAGE = "UNAUTHORIZED_DATA_ACCESS";
}

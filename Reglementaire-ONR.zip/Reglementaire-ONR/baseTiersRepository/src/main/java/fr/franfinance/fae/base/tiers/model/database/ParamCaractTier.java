package fr.franfinance.fae.base.tiers.model.database;

import java.io.Serializable;
import javax.persistence.*;
import org.hibernate.annotations.DynamicUpdate;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "PARAM_CARACT_TIERS")
@DynamicUpdate
public class ParamCaractTier implements Serializable {

  private static final long serialVersionUID = 1L;

  private String codeCaract;
  private String codeStatut;
  private String commentaire;
  private Date dateCreation;
  private Date dateDebutValidite;
  private Date dateFinValidite;
  private String descDateFct1;
  private String descDateFct2;
  private String descVal1;
  private String descVal2;
  private String descVal3;
  private String descVal4;
  private String formatVal1;
  private String formatVal2;
  private String formatVal3;
  private String formatVal4;
  private String indComparDateFct1;
  private String indComparDateFct2;
  private String indComparVal1;
  private String indComparVal2;
  private String indComparVal3;
  private String indComparVal4;
  private BigDecimal indicAppelFccr;
  private BigDecimal indicModifiable;
  private String libelleCaract;
  private BigDecimal nbOrigine;
  private String typeVal1;
  private String typeVal2;
  private String typeVal3;
  private String typeVal4;
  private String nomDateFct1;
  private String nomDateFct2;
  private String nomCaract1;
  private String nomCaract2;
  private String nomCaract3;
  private String nomCaract4;
  private CaractTier caractTiers;

  @Id
  @Column(name = "CODE_CARACT")
  public String getCodeCaract() {
    return this.codeCaract;
  }

  public void setCodeCaract(String codeCaract) {
    this.codeCaract = codeCaract;
  }


  @Column(name = "CODE_STATUT")
  public String getCodeStatut() {
    return this.codeStatut;
  }

  public void setCodeStatut(String codeStatut) {
    this.codeStatut = codeStatut;
  }

  @Column(name = "COMMENTAIRE")
  public String getCommentaire() {
    return this.commentaire;
  }

  public void setCommentaire(String commentaire) {
    this.commentaire = commentaire;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_CREATION")
  public Date getDateCreation() {
    return this.dateCreation;
  }

  public void setDateCreation(Date dateCreation) {
    this.dateCreation = dateCreation;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_DEBUT_VALIDITE")
  public Date getDateDebutValidite() {
    return this.dateDebutValidite;
  }

  public void setDateDebutValidite(Date dateDebutValidite) {
    this.dateDebutValidite = dateDebutValidite;
  }


  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_FIN_VALIDITE")
  public Date getDateFinValidite() {
    return this.dateFinValidite;
  }

  public void setDateFinValidite(Date dateFinValidite) {
    this.dateFinValidite = dateFinValidite;
  }


  @Column(name = "DESC_DATE_FCT1")
  public String getDescDateFct1() {
    return this.descDateFct1;
  }

  public void setDescDateFct1(String descDateFct1) {
    this.descDateFct1 = descDateFct1;
  }


  @Column(name = "DESC_DATE_FCT2")
  public String getDescDateFct2() {
    return this.descDateFct2;
  }

  public void setDescDateFct2(String descDateFct2) {
    this.descDateFct2 = descDateFct2;
  }


  @Column(name = "DESC_VAL1")
  public String getDescVal1() {
    return this.descVal1;
  }

  public void setDescVal1(String descVal1) {
    this.descVal1 = descVal1;
  }


  @Column(name = "DESC_VAL2")
  public String getDescVal2() {
    return this.descVal2;
  }

  public void setDescVal2(String descVal2) {
    this.descVal2 = descVal2;
  }


  @Column(name = "DESC_VAL3")
  public String getDescVal3() {
    return this.descVal3;
  }

  public void setDescVal3(String descVal3) {
    this.descVal3 = descVal3;
  }


  @Column(name = "DESC_VAL4")
  public String getDescVal4() {
    return this.descVal4;
  }

  public void setDescVal4(String descVal4) {
    this.descVal4 = descVal4;
  }


  @Column(name = "FORMAT_VAL1")
  public String getFormatVal1() {
    return this.formatVal1;
  }

  public void setFormatVal1(String formatVal1) {
    this.formatVal1 = formatVal1;
  }


  @Column(name = "FORMAT_VAL2")
  public String getFormatVal2() {
    return this.formatVal2;
  }

  public void setFormatVal2(String formatVal2) {
    this.formatVal2 = formatVal2;
  }


  @Column(name = "FORMAT_VAL3")
  public String getFormatVal3() {
    return this.formatVal3;
  }

  public void setFormatVal3(String formatVal3) {
    this.formatVal3 = formatVal3;
  }


  @Column(name = "FORMAT_VAL4")
  public String getFormatVal4() {
    return this.formatVal4;
  }

  public void setFormatVal4(String formatVal4) {
    this.formatVal4 = formatVal4;
  }


  @Column(name = "IND_COMPAR_DATE_FCT1")
  public String getIndComparDateFct1() {
    return this.indComparDateFct1;
  }

  public void setIndComparDateFct1(String indComparDateFct1) {
    this.indComparDateFct1 = indComparDateFct1;
  }


  @Column(name = "IND_COMPAR_DATE_FCT2")
  public String getIndComparDateFct2() {
    return this.indComparDateFct2;
  }

  public void setIndComparDateFct2(String indComparDateFct2) {
    this.indComparDateFct2 = indComparDateFct2;
  }


  @Column(name = "IND_COMPAR_VAL1")
  public String getIndComparVal1() {
    return this.indComparVal1;
  }

  public void setIndComparVal1(String indComparVal1) {
    this.indComparVal1 = indComparVal1;
  }


  @Column(name = "IND_COMPAR_VAL2")
  public String getIndComparVal2() {
    return this.indComparVal2;
  }

  public void setIndComparVal2(String indComparVal2) {
    this.indComparVal2 = indComparVal2;
  }


  @Column(name = "IND_COMPAR_VAL3")
  public String getIndComparVal3() {
    return this.indComparVal3;
  }

  public void setIndComparVal3(String indComparVal3) {
    this.indComparVal3 = indComparVal3;
  }


  @Column(name = "IND_COMPAR_VAL4")
  public String getIndComparVal4() {
    return this.indComparVal4;
  }

  public void setIndComparVal4(String indComparVal4) {
    this.indComparVal4 = indComparVal4;
  }


  @Column(name = "INDIC_APPEL_FCCR")
  public BigDecimal getIndicAppelFccr() {
    return this.indicAppelFccr;
  }

  public void setIndicAppelFccr(BigDecimal indicAppelFccr) {
    this.indicAppelFccr = indicAppelFccr;
  }


  @Column(name = "INDIC_MODIFIABLE")
  public BigDecimal getIndicModifiable() {
    return this.indicModifiable;
  }

  public void setIndicModifiable(BigDecimal indicModifiable) {
    this.indicModifiable = indicModifiable;
  }


  @Column(name = "LIBELLE_CARACT")
  public String getLibelleCaract() {
    return this.libelleCaract;
  }

  public void setLibelleCaract(String libelleCaract) {
    this.libelleCaract = libelleCaract;
  }


  @Column(name = "NB_ORIGINE")
  public BigDecimal getNbOrigine() {
    return this.nbOrigine;
  }

  public void setNbOrigine(BigDecimal nbOrigine) {
    this.nbOrigine = nbOrigine;
  }


  @Column(name = "TYPE_VAL1")
  public String getTypeVal1() {
    return this.typeVal1;
  }

  public void setTypeVal1(String typeVal1) {
    this.typeVal1 = typeVal1;
  }


  @Column(name = "TYPE_VAL2")
  public String getTypeVal2() {
    return this.typeVal2;
  }

  public void setTypeVal2(String typeVal2) {
    this.typeVal2 = typeVal2;
  }


  @Column(name = "TYPE_VAL3")
  public String getTypeVal3() {
    return this.typeVal3;
  }

  public void setTypeVal3(String typeVal3) {
    this.typeVal3 = typeVal3;
  }


  @Column(name = "TYPE_VAL4")
  public String getTypeVal4() {
    return this.typeVal4;
  }

  public void setTypeVal4(String typeVal4) {
    this.typeVal4 = typeVal4;
  }

  @OneToOne(mappedBy = "paramCaractTier", cascade = CascadeType.ALL)
  @JsonIgnore
  public CaractTier getCaractTiers() {
    return caractTiers;
  }

  public void setCaractTiers(CaractTier caractTiers) {
    this.caractTiers = caractTiers;
  }

  @Column(name = "NOM_DATE_FCT1")
  public String getNomDateFct1() {
    return nomDateFct1;
  }

  public void setNomDateFct1(String nomDateFct1) {
    this.nomDateFct1 = nomDateFct1;
  }

  @Column(name = "NOM_DATE_FCT2")
  public String getNomDateFct2() {
    return nomDateFct2;
  }

  public void setNomDateFct2(String nomDateFct2) {
    this.nomDateFct2 = nomDateFct2;
  }

  @Column(name = "NOM_CARACT1")
  
  public String getNomCaract1() {
    return nomCaract1;
  }

  public void setNomCaract1(String nomCaract1) {
    this.nomCaract1 = nomCaract1;
  }

  @Column(name = "NOM_CARACT2")
  public String getNomCaract2() {
    return nomCaract2;
  }

  public void setNomCaract2(String nomCaract2) {
    this.nomCaract2 = nomCaract2;
  }

  @Column(name = "NOM_CARACT3")
  public String getNomCaract3() {
    return nomCaract3;
  }

  public void setNomCaract3(String nomCaract3) {
    this.nomCaract3 = nomCaract3;
  }

  @Column(name = "NOM_CARACT4")
  public String getNomCaract4() {
    return nomCaract4;
  }

  public void setNomCaract4(String nomCaract4) {
    this.nomCaract4 = nomCaract4;
  }

  @Override
  public String toString() {
    return "ParamCaractTier [codeCaract=" + codeCaract + ", codeStatut=" + codeStatut
        + ", commentaire=" + commentaire + ", dateCreation=" + dateCreation + ", dateDebutValidite="
        + dateDebutValidite + ", dateFinValidite=" + dateFinValidite + ", descDateFct1="
        + descDateFct1 + ", descDateFct2=" + descDateFct2 + ", descVal1=" + descVal1 + ", descVal2="
        + descVal2 + ", descVal3=" + descVal3 + ", descVal4=" + descVal4 + ", formatVal1="
        + formatVal1 + ", formatVal2=" + formatVal2 + ", formatVal3=" + formatVal3 + ", formatVal4="
        + formatVal4 + ", indComparDateFct1=" + indComparDateFct1 + ", indComparDateFct2="
        + indComparDateFct2 + ", indComparVal1=" + indComparVal1 + ", indComparVal2="
        + indComparVal2 + ", indComparVal3=" + indComparVal3 + ", indComparVal4=" + indComparVal4
        + ", indicAppelFccr=" + indicAppelFccr + ", indicModifiable=" + indicModifiable
        + ", libelleCaract=" + libelleCaract + ", nbOrigine=" + nbOrigine + ", typeVal1=" + typeVal1
        + ", typeVal2=" + typeVal2 + ", typeVal3=" + typeVal3 + ", typeVal4=" + typeVal4 + "]";
  }
}

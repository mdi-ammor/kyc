package fr.franfinance.fae.base.tiers.dao;

import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;

public interface BtnRepoDao {
  
	public NotationRefTier getTiersBySiren(String siren);
	public NotationRefTier updateTiers(NotationRefTier tiers);
	public Integer callFluxElliFunction (Long refAppel);
	public Integer callCreateTiersFunction (String siren);
}

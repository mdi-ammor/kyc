package fr.franfinance.fae.base.tiers.model.database;

import java.io.Serializable;
import javax.persistence.*;
import org.hibernate.annotations.DynamicUpdate;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import fr.franfinance.fae.base.tiers.utils.BtnRepoConstants;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "SUIVI_APPEL_ELLISPHERE")
@DynamicUpdate
public class SuiviAppelEllisphere implements Serializable {

  private static final long serialVersionUID = 1L;
  private Long refAppelEllisphere;
  private Long refAppelFichierBeXml;
  private String codeReponseBe;
  private String codeRetAppelWsEllis;
  private String codeRetInsertFichierBeXml;
  private String commentInsertFichierBeXml;
  private String commentReponseBe;
  private Date dateAppelWsEllis;
  private Date dateInsertFichierBeXml;
  private Date dateReceptFichierBeXml;
  private Date dateRetAppelWsEllis;
  private String detailMesErr;
  private String majorCodeRet;
  private String majorMesErr;
  private String minorCodeRet;
  private String minorMesErr;
  private BigDecimal nbActionnaire;
  private BigDecimal nbBe;
  private BigDecimal nbFichierCarto;
  private BigDecimal nbFichierPreuve;
  private BigDecimal noOde;
  private String noTicket;
  private String nomFichierBeXml;
  private String nomFichierZip;
  private BigDecimal seuilMinActionnariat;
  private BigDecimal seuilParticipation;
  private String siren;
  private String statutReponseBe;
  private String statutTicket;
  private String statutAppelWsEllis;
  private Boolean flagDernierAppelEllisphere;
  private BigDecimal idTiersBnot;
  private BigDecimal tauxDetentionTotalBe;

  private NotationRefTier notationRefTier;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SUIVI_APPEL_ELLISPHERE_SQ")
  @SequenceGenerator(name = "SUIVI_APPEL_ELLISPHERE_SQ", sequenceName = "SUIVI_APPEL_ELLISPHERE_SQ",
      allocationSize = 1, initialValue = 1)
  @Column(name = "REF_APPEL_ELLISPHERE")
  public Long getRefAppelEllisphere() {
    return refAppelEllisphere;
  }

  public void setRefAppelEllisphere(Long refAppelEllisphere) {
    this.refAppelEllisphere = refAppelEllisphere;
  }

  @Column(name = "REF_APPEL_FICHIER_BE_XML")
  public Long getRefAppelFichierBeXml() {
    return refAppelFichierBeXml;
  }

  public void setRefAppelFichierBeXml(Long refAppelFichierBeXml) {
    this.refAppelFichierBeXml = refAppelFichierBeXml;
  }

  @Column(name = "CODE_REPONSE_BE")
  public String getCodeReponseBe() {
    return this.codeReponseBe;
  }

  public void setCodeReponseBe(String codeReponseBe) {
    this.codeReponseBe = codeReponseBe;
  }

  @Column(name = "CODE_RET_APPEL_WS_ELLIS")
  public String getCodeRetAppelWsEllis() {
    return codeRetAppelWsEllis;
  }

  public void setCodeRetAppelWsEllis(String codeRetAppelWsEllis) {
    this.codeRetAppelWsEllis = codeRetAppelWsEllis;
  }

  @Column(name = "CODE_RET_INSERT_FICHIER_BE_XML")
  public String getCodeRetInsertFichierBeXml() {
    return codeRetInsertFichierBeXml;
  }

  public void setCodeRetInsertFichierBeXml(String codeRetInsertFichierBeXml) {
    this.codeRetInsertFichierBeXml = codeRetInsertFichierBeXml;
  }

  @Column(name = "COMMENT_INSERT_FICHIER_BE_XML")
  public String getCommentInsertFichierBeXml() {
    return commentInsertFichierBeXml;
  }

  public void setCommentInsertFichierBeXml(String commentInsertFichierBeXml) {
    this.commentInsertFichierBeXml = commentInsertFichierBeXml;
  }

  @Column(name = "COMMENT_REPONSE_BE")
  public String getCommentReponseBe() {
    return this.commentReponseBe;
  }

  public void setCommentReponseBe(String commentReponseBe) {
    this.commentReponseBe = commentReponseBe;
  }

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  @Column(name = "DATE_APPEL_WS_ELLIS")
  public Date getDateAppelWsEllis() {
    return this.dateAppelWsEllis;
  }

  public void setDateAppelWsEllis(Date dateAppelWsEllis) {
    this.dateAppelWsEllis = dateAppelWsEllis;
  }

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  @Column(name = "DATE_INSERT_FICHIER_BE_XML")
  public Date getDateInsertFichierBeXml() {
    return this.dateInsertFichierBeXml;
  }

  public void setDateInsertFichierBeXml(Date dateInsertFichierBeXml) {
    this.dateInsertFichierBeXml = dateInsertFichierBeXml;
  }

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  @Column(name = "DATE_RECEPT_FICHIER_BE_XML")
  public Date getDateReceptFichierBeXml() {
    return this.dateReceptFichierBeXml;
  }

  public void setDateReceptFichierBeXml(Date dateReceptFichierBeXml) {
    this.dateReceptFichierBeXml = dateReceptFichierBeXml;
  }

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  @Column(name = "DATE_RET_APPEL_WS_ELLIS")
  public Date getDateRetAppelWsEllis() {
    return this.dateRetAppelWsEllis;
  }

  public void setDateRetAppelWsEllis(Date dateRetAppelWsEllis) {
    this.dateRetAppelWsEllis = dateRetAppelWsEllis;
  }

  @Column(name = "DETAIL_MES_ERR")
  public String getDetailMesErr() {
    return this.detailMesErr;
  }

  public void setDetailMesErr(String detailMesErr) {
    this.detailMesErr = detailMesErr;
  }

  @Column(name = "MAJOR_CODE_RET")
  public String getMajorCodeRet() {
    return this.majorCodeRet;
  }

  public void setMajorCodeRet(String majorCodeRet) {
    this.majorCodeRet = majorCodeRet;
  }

  @Column(name = "MAJOR_MES_ERR")
  public String getMajorMesErr() {
    return this.majorMesErr;
  }

  public void setMajorMesErr(String majorMesErr) {
    this.majorMesErr = majorMesErr;
  }

  @Column(name = "MINOR_CODE_RET")
  public String getMinorCodeRet() {
    return minorCodeRet;
  }

  public void setMinorCodeRet(String minorCodeRet) {
    this.minorCodeRet = minorCodeRet;
  }

  @Column(name = "MINOR_MES_ERR")
  public String getMinorMesErr() {
    return this.minorMesErr;
  }



  public void setMinorMesErr(String minorMesErr) {
    this.minorMesErr = minorMesErr;
  }

  @Column(name = "NB_ACTIONNAIRE")
  public BigDecimal getNbActionnaire() {
    return this.nbActionnaire;
  }

  public void setNbActionnaire(BigDecimal nbActionnaire) {
    this.nbActionnaire = nbActionnaire;
  }

  @Column(name = "NB_BE")
  public BigDecimal getNbBe() {
    return this.nbBe;
  }

  public void setNbBe(BigDecimal nbBe) {
    this.nbBe = nbBe;
  }

  @Column(name = "NB_FICHIER_CARTO")
  public BigDecimal getNbFichierCarto() {
    return this.nbFichierCarto;
  }

  public void setNbFichierCarto(BigDecimal nbFichierCarto) {
    this.nbFichierCarto = nbFichierCarto;
  }

  @Column(name = "NB_FICHIER_PREUVE")
  public BigDecimal getNbFichierPreuve() {
    return this.nbFichierPreuve;
  }

  public void setNbFichierPreuve(BigDecimal nbFichierPreuve) {
    this.nbFichierPreuve = nbFichierPreuve;
  }

  @Column(name = "NO_ODE")
  public BigDecimal getNoOde() {
    return noOde;
  }

  public void setNoOde(BigDecimal noOde) {
    this.noOde = noOde;
  }

  @Column(name = "NO_TICKET")
  public String getNoTicket() {
    return this.noTicket;
  }

  public void setNoTicket(String noTicket) {
    this.noTicket = noTicket;
  }

  @Column(name = "NOM_FICHIER_BE_XML")
  public String getNomFichierBeXml() {
    return this.nomFichierBeXml;
  }

  public void setNomFichierBeXml(String nomFichierBeXml) {
    this.nomFichierBeXml = nomFichierBeXml;
  }

  @Column(name = "NOM_FICHIER_ZIP")
  public String getNomFichierZip() {
    return this.nomFichierZip;
  }

  public void setNomFichierZip(String nomFichierZip) {
    this.nomFichierZip = nomFichierZip;
  }

  @Column(name = "SEUIL_MIN_ACTIONNARIAT")
  public BigDecimal getSeuilMinActionnariat() {
    return this.seuilMinActionnariat;
  }

  public void setSeuilMinActionnariat(BigDecimal seuilMinActionnariat) {
    this.seuilMinActionnariat = seuilMinActionnariat;
  }

  @Column(name = "SEUIL_PARTICIPATION")
  public BigDecimal getSeuilParticipation() {
    return seuilParticipation;
  }

  public void setSeuilParticipation(BigDecimal seuilParticipation) {
    this.seuilParticipation = seuilParticipation;
  }

  @Column(name = "SIREN")
  public String getSiren() {
    return this.siren;
  }

  public void setSiren(String siren) {
    this.siren = siren;
  }

  @Column(name = "STATUT_REPONSE_BE")
  public String getStatutReponseBe() {
    return this.statutReponseBe;
  }

  public void setStatutReponseBe(String statutReponseBe) {
    this.statutReponseBe = statutReponseBe;
  }

  @Column(name = "STATUT_TICKET")
  public String getStatutTicket() {
    return this.statutTicket;
  }

  public void setStatutTicket(String statutTicket) {
    this.statutTicket = statutTicket;
  }

  @Column(name = "STATUT_APPEL_WS_ELLIS")
  public String getStatutAppelWsEllis() {
    return this.statutAppelWsEllis;
  }

  public void setStatutAppelWsEllis(String statutAppelWsEllis) {
    this.statutAppelWsEllis = statutAppelWsEllis;
  }

  @Column(name = "FLAG_DERNIER_APPEL")
  public Boolean getFlagDernierAppelEllisphere() {
    return flagDernierAppelEllisphere;
  }

  public void setFlagDernierAppelEllisphere(Boolean flagDernierAppelEllisphere) {
    this.flagDernierAppelEllisphere = flagDernierAppelEllisphere;
  }

  @Column(name = "ID_TIERS_BNOT")
  public BigDecimal getIdTiersBnot() {
    return idTiersBnot;
  }

  public void setIdTiersBnot(BigDecimal idTiersBnot) {
    this.idTiersBnot = idTiersBnot;
  }

  @Column(name = "TAUX_DETENTION_TOTAL_BE")
  public BigDecimal getTauxDetentionTotalBe() {
    return tauxDetentionTotalBe;
  }

  public void setTauxDetentionTotalBe(BigDecimal tauxDetentionTotalBe) {
    this.tauxDetentionTotalBe = tauxDetentionTotalBe;
  }

  @ManyToOne
  @JoinColumn(name = "ID_TIERS_BNOT", insertable = false, updatable = false)
  @JsonIgnore
  public NotationRefTier getNotationRefTier() {
    return this.notationRefTier;
  }

  public void setNotationRefTier(NotationRefTier notationRefTier) {
    this.notationRefTier = notationRefTier;
  }

  @Override
  public String toString() {
    return "SuiviAppelEllisphere [refAppelEllisphere=" + refAppelEllisphere
        + ", refAppelFichierBeXml=" + refAppelFichierBeXml + ", codeReponseBe=" + codeReponseBe
        + ", codeRetAppelWsEllis=" + codeRetAppelWsEllis + ", codeRetInsertFichierBeXml="
        + codeRetInsertFichierBeXml + ", commentInsertFichierBeXml=" + commentInsertFichierBeXml
        + ", commentReponseBe=" + commentReponseBe + ", dateAppelWsEllis=" + dateAppelWsEllis
        + ", dateInsertFichierBeXml=" + dateInsertFichierBeXml + ", dateReceptFichierBeXml="
        + dateReceptFichierBeXml + ", dateRetAppelWsEllis=" + dateRetAppelWsEllis
        + ", detailMesErr=" + detailMesErr + ", majorCodeRet=" + majorCodeRet + ", majorMesErr="
        + majorMesErr + ", minorCodeRet=" + minorCodeRet + ", minorMesErr=" + minorMesErr
        + ", nbActionnaire=" + nbActionnaire + ", nbBe=" + nbBe + ", nbFichierCarto="
        + nbFichierCarto + ", nbFichierPreuve=" + nbFichierPreuve + ", noOde=" + noOde
        + ", noTicket=" + noTicket + ", nomFichierBeXml=" + nomFichierBeXml + ", nomFichierZip="
        + nomFichierZip + ", seuilMinActionnariat=" + seuilMinActionnariat + ", seuilParticipation="
        + seuilParticipation + ", siren=" + siren + ", statutReponseBe=" + statutReponseBe
        + ", statutTicket=" + statutTicket + ", statutAppelWsEllis=" + statutAppelWsEllis
        + ", flagDernierAppelEllisphere=" + flagDernierAppelEllisphere + ", idTiersBnot="
        + idTiersBnot + ", tauxDetentionTotalBe=" + tauxDetentionTotalBe + "]";
  }
}

package fr.franfinance.fae.base.tiers.model.json;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import fr.franfinance.fae.base.tiers.utils.BtnRepoConstants;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CaractTiersJson implements Serializable {

  private static final long serialVersionUID = 1L;

  private long idCaractTiers;
  private long idTiersBnot;
  private String codeCaract;
  private String codeProvenance;
  private String commentaire;
  private String complProvenance;
  private Date dateDebutValidite;
  private Date dateDerniereRecept;
  private String nomDateFct1;
  private Date dateFct1;
  private String nomDateFct2;
  private Date dateFct2;
  private String idProvenance;
  private String idProvenanceDerniere;
  private String provenanceDerniereRecept;
  private String nomCaract1;
  private String valeurCaract1;
  private String nomCaract2;
  private String valeurCaract2;
  private String nomCaract3;
  private String valeurCaract3;
  private String nomCaract4;
  private String valeurCaract4;

  public long getIdTiersBnot() {
    return idTiersBnot;
  }

  public void setIdTiersBnot(long idTiersBnot) {
    this.idTiersBnot = idTiersBnot;
  }

  public String getCodeCaract() {
    return codeCaract;
  }

  public void setCodeCaract(String codeCaract) {
    this.codeCaract = codeCaract;
  }

  public String getCodeProvenance() {
    return this.codeProvenance;
  }

  public void setCodeProvenance(String codeProvenance) {
    this.codeProvenance = codeProvenance;
  }

  public String getCommentaire() {
    return this.commentaire;
  }

  public void setCommentaire(String commentaire) {
    this.commentaire = commentaire;
  }

  public String getComplProvenance() {
    return this.complProvenance;
  }

  public void setComplProvenance(String complProvenance) {
    this.complProvenance = complProvenance;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateDebutValidite() {
    return this.dateDebutValidite;
  }

  public void setDateDebutValidite(Date dateDebutValidite) {
    this.dateDebutValidite = dateDebutValidite;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateDerniereRecept() {
    return this.dateDerniereRecept;
  }

  public void setDateDerniereRecept(Date dateDerniereRecept) {
    this.dateDerniereRecept = dateDerniereRecept;
  }

  public long getIdCaractTiers() {
    return this.idCaractTiers;
  }

  public String getNomDateFct1() {
    return nomDateFct1;
  }

  public void setNomDateFct1(String nomDateFct1) {
    this.nomDateFct1 = nomDateFct1;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateFct1() {
    return this.dateFct1;
  }

  public void setDateFct1(Date dateFct1) {
    this.dateFct1 = dateFct1;
  }

  public String getNomDateFct2() {
    return nomDateFct2;
  }

  public void setNomDateFct2(String nomDateFct2) {
    this.nomDateFct2 = nomDateFct2;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateFct2() {
    return this.dateFct2;
  }

  public void setDateFct2(Date dateFct2) {
    this.dateFct2 = dateFct2;
  }

  public String getIdProvenance() {
    return this.idProvenance;
  }

  public void setIdProvenance(String idProvenance) {
    this.idProvenance = idProvenance;
  }

  public String getIdProvenanceDerniere() {
    return this.idProvenanceDerniere;
  }

  public void setIdProvenanceDerniere(String idProvenanceDerniere) {
    this.idProvenanceDerniere = idProvenanceDerniere;
  }

  public String getProvenanceDerniereRecept() {
    return this.provenanceDerniereRecept;
  }

  public void setProvenanceDerniereRecept(String provenanceDerniereRecept) {
    this.provenanceDerniereRecept = provenanceDerniereRecept;
  }

  public String getNomCaract1() {
    return nomCaract1;
  }

  public void setNomCaract1(String nomCaract1) {
    this.nomCaract1 = nomCaract1;
  }

  public String getValeurCaract1() {
    return this.valeurCaract1;
  }

  public void setValeurCaract1(String valeurCaract1) {
    this.valeurCaract1 = valeurCaract1;
  }

  public String getNomCaract2() {
    return nomCaract2;
  }

  public void setNomCaract2(String nomCaract2) {
    this.nomCaract2 = nomCaract2;
  }

  public String getValeurCaract2() {
    return this.valeurCaract2;
  }

  public void setValeurCaract2(String valeurCaract2) {
    this.valeurCaract2 = valeurCaract2;
  }

  public String getNomCaract3() {
    return nomCaract3;
  }

  public void setNomCaract3(String nomCaract3) {
    this.nomCaract3 = nomCaract3;
  }

  public String getValeurCaract3() {
    return this.valeurCaract3;
  }

  public void setValeurCaract3(String valeurCaract3) {
    this.valeurCaract3 = valeurCaract3;
  }

  public String getNomCaract4() {
    return nomCaract4;
  }

  public void setNomCaract4(String nomCaract4) {
    this.nomCaract4 = nomCaract4;
  }

  public void setIdCaractTiers(long idCaractTiers) {
    this.idCaractTiers = idCaractTiers;
  }

  public String getValeurCaract4() {
    return this.valeurCaract4;
  }

  public void setValeurCaract4(String valeurCaract4) {
    this.valeurCaract4 = valeurCaract4;
  }

  @Override
  public String toString() {
    return "CaractTier [idCaractTiers=" + idCaractTiers + ", idTiersBnot=" + idTiersBnot
        + ", codeCaract=" + codeCaract + ", codeProvenance=" + codeProvenance + ", commentaire="
        + commentaire + ", complProvenance=" + complProvenance + ", dateDebutValidite="
        + dateDebutValidite + ", dateDerniereRecept=" + dateDerniereRecept + ", dateFct1="
        + dateFct1 + ", dateFct2=" + dateFct2 + ", idProvenance=" + idProvenance
        + ", idProvenanceDerniere=" + idProvenanceDerniere + ", provenanceDerniereRecept="
        + provenanceDerniereRecept + ", valeurCaract1=" + valeurCaract1 + ", valeurCaract2="
        + valeurCaract2 + ", valeurCaract3=" + valeurCaract3 + ", valeurCaract4=" + valeurCaract4
        + "]";
  }

}

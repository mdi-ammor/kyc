package fr.franfinance.fae.base.tiers.application;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.franfinance.fae.base.tiers.config.BtnRepoSpringConfig;
import fr.franfinance.fae.base.tiers.model.json.TiersJson;
import fr.franfinance.fae.base.tiers.service.BtnRepoService;
import fr.franfinance.fae.base.tiers.utils.BaseTiersWsUtil;


public class BtnRepoApplication {

  public static ApplicationContext context;

  public static void main(String[] args) throws Exception {
    // Initialize spring context and get Service bean
    context = new AnnotationConfigApplicationContext(BtnRepoSpringConfig.class);
    BtnRepoService btnService = context.getBean(BtnRepoService.class);
    // Get Tier by Siren
    TiersJson tiers =
        BaseTiersWsUtil.convertBtnTierToWsTier(btnService.getTiersBySiren("325763415"));
    // Serialization
    ObjectMapper mapper = new ObjectMapper();
    // Object to JSON in String
    String tierJson = mapper.writeValueAsString(tiers);
    System.out.println(tierJson);
    
  }
}

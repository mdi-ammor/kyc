package fr.franfinance.fae.base.tiers.model.json;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import fr.franfinance.fae.base.tiers.utils.BtnRepoConstants;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class TiersLieJson implements Serializable {

  private static final long serialVersionUID = 1L;

  private String natureLien;
  private Long idNatureLien;
  private String codeProvenance;
  private String codeStatut;
  private Date dateFonction;
  private Date dateInsertLien;
  private Date dateMajLien;
  private String fonction;
  private String idProvenance;
  private BigDecimal pctDetention;
  private String typeTiersLie;

  private DetailsTiersLieJson detailsTiersLie;

  public Long getIdNatureLien() {
    return this.idNatureLien;
  }

  public void setIdNatureLien(Long idNatureLien) {
    this.idNatureLien = idNatureLien;
  }

  public String getNatureLien() {
    return this.natureLien;
  }

  public void setNatureLien(String natureLien) {
    this.natureLien = natureLien;
  }

  public String getCodeProvenance() {
    return this.codeProvenance;
  }

  public void setCodeProvenance(String codeProvenance) {
    this.codeProvenance = codeProvenance;
  }

  public String getCodeStatut() {
    return this.codeStatut;
  }

  public void setCodeStatut(String codeStatut) {
    this.codeStatut = codeStatut;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateFonction() {
    return this.dateFonction;
  }

  public void setDateFonction(Date dateFonction) {
    this.dateFonction = dateFonction;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateInsertLien() {
    return this.dateInsertLien;
  }

  public void setDateInsertLien(Date dateInsertLien) {
    this.dateInsertLien = dateInsertLien;
  }

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = BtnRepoConstants.DATE_FORMAT,
      locale = BtnRepoConstants.DATE_LOCALE, timezone = BtnRepoConstants.DATE_TIMEZONE)
  public Date getDateMajLien() {
    return this.dateMajLien;
  }

  public void setDateMajLien(Date dateMajLien) {
    this.dateMajLien = dateMajLien;
  }

  public String getFonction() {
    return this.fonction;
  }

  public void setFonction(String fonction) {
    this.fonction = fonction;
  }

  public String getIdProvenance() {
    return this.idProvenance;
  }

  public void setIdProvenance(String idProvenance) {
    this.idProvenance = idProvenance;
  }

  public BigDecimal getPctDetention() {
    return this.pctDetention;
  }

  public void setPctDetention(BigDecimal pctDetention) {
    this.pctDetention = pctDetention;
  }

  public String getTypeTiersLie() {
    return this.typeTiersLie;
  }

  public void setTypeTiersLie(String typeTiersLie) {
    this.typeTiersLie = typeTiersLie;
  }

  public DetailsTiersLieJson getDetailsTiersLie() {
    return detailsTiersLie;
  }

  public void setDetailsTiersLie(DetailsTiersLieJson detailsTiersLie) {
    this.detailsTiersLie = detailsTiersLie;
  }

  @Override
  public String toString() {
    return "NatureLien [natureLien=" + natureLien + ", idNatureLien=" + idNatureLien
        + ", codeProvenance=" + codeProvenance + ", codeStatut=" + codeStatut + ", dateFonction="
        + dateFonction + ", dateInsertLien=" + dateInsertLien + ", dateMajLien=" + dateMajLien
        + ", fonction=" + fonction + ", idProvenance=" + idProvenance + ", pctDetention="
        + pctDetention + ", typeTiersLie=" + typeTiersLie + "]";
  }
}

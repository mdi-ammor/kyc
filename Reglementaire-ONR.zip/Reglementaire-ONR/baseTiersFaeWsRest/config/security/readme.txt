Ces magasins de cl�s et de certificats sont utilis�s par le projet et l'instance de son serveur d'application.

La gestion des certificats ce fait via l'outil keytool de java

####################################################################################
################################ Frf.trustore ######################################
####################################################################################
Le Frf.truststore est utilis� pour stocker toutes les autorit�es de certifications et certificats de confiances

set JAVA_HOME=%PATH_TO_ATELIER%/AtelierJEE7/jdks/jdk1.8.0_77

Importation d'un certificat dans le truststore
	%JAVA_HOME%\bin\keytool -import -noprompt -v -trustcacerts -alias ALIAS -file %PATH_TO_CERT%/somecert.cer -keystore %PATH_TO_TRUSTSTORE%/Frf.truststore -storetype jks -storepass changeit

suppression d'un certificat dans le truststore 
	%JAVA_HOME%\bin\keytool -delete -noprompt -alias ${ALIAS_TO_DELETE} -keystore %PATH_TO_TRUSTSTORE%/Frf.truststore -storepass changeit
	
####################################################################################
################################ Frf.keystore ######################################
####################################################################################
Le Frf.keystore est utilis� pour stocker toutes les cl�s (exemple: AES, ...) et autres certificats applicatives (exemple: certificats auto-sign�, ...)
set JAVA_HOME=%PATH_TO_ATELIER%/AtelierJEE7/jdks/jdk1.8.0_77

Importation d'un certificat ou cl� dans le keystore
	%JAVA_HOME%\bin\keytool -import -noprompt -v -trustcacerts -alias ALIAS -file %PATH_TO_CERT%/somecert.cer -keystore %PATH_TO_KEYSTORE%/Frf.keystore -storetype jks -storepass changeit

suppression d'un certificat dans le keystore
	%JAVA_HOME%\bin\keytool -delete -noprompt -alias ${ALIAS_TO_DELETE} -keystore %PATH_TO_KEYSTORE%/Frf.keystore -storepass changeit

####################################################################################
######## Lister les certificats dans les magasins de cl�s et de certificats ########
####################################################################################

keytool -list -v -keystore ${keystore.file} -storepass ${keystore.pass} > outputfile.txt
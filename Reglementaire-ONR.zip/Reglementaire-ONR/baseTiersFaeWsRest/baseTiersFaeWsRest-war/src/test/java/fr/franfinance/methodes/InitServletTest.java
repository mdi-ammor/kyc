package fr.franfinance.methodes;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test for simple App.
 */


public class InitServletTest {


	/**
	 * Rigourous Test :-)
	 */
	@Test
	public void testApp() {
		Assert.assertTrue(true);
	}
}

package fr.franfinance.fae.base.tiers.ws.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import fr.franfinance.fae.base.tiers.exceptions.TechnicalException;
import fr.franfinance.fae.base.tiers.model.database.NotationRefTier;
import fr.franfinance.fae.base.tiers.model.json.TiersJson;
import fr.franfinance.fae.base.tiers.model.response.ResponseError;
import fr.franfinance.fae.base.tiers.model.response.TiersResponse;
import fr.franfinance.fae.base.tiers.service.BtnRepoService;
import fr.franfinance.fae.base.tiers.utils.BaseTiersWsUtil;
import fr.franfinance.fae.base.tiers.utils.BtnRepoConstants;

@RestController
@RequestMapping("/")
public class BaseTiersWsController {

  @Autowired
  private BtnRepoService btnRepoService;
  private static final Logger LOGGER = LoggerFactory.getLogger(BaseTiersWsController.class);

  /**
   * @RequestParam String
   * @return Tier
   * @throws Exception
   **/
  @RequestMapping(value = "/getTiers/{siren}", method = RequestMethod.GET,
      produces = "application/json")
  public TiersResponse getTierBySiren(@PathVariable("siren") String siren) throws Exception {
    TiersResponse tiersResponse = new TiersResponse();
    try {
      LOGGER.info(
          "=========== LANCEMENT DU WEB SERVICE GET TIERS BY SIREN = " + siren + " ===========");
      TiersJson tiers =
          BaseTiersWsUtil.convertBtnTierToWsTier(btnRepoService.getTiersBySiren(siren));
      tiersResponse.setTiers(tiers);
      tiersResponse.setStatus(BtnRepoConstants.STATUS_SUCCESS);
    } catch (TechnicalException e) {
      LOGGER.error("=== TIERS INTROUVABLE ===: ", e);
      tiersResponse.setStatus(BtnRepoConstants.STATUS_SUCCESS);
      tiersResponse.setError(new ResponseError(e.getCode(), e.getMessage()));
    } catch (Exception e) {
      LOGGER.error("=== ERREUR CHARGEMENT TIERS ===: ", e);
      tiersResponse.setStatus(BtnRepoConstants.STATUS_FAILURE);
      tiersResponse.setError(new ResponseError(BtnRepoConstants.DATA_ERROR_CODE, e.getMessage()));
    }
    LOGGER.info(
        "=========== FIN DU WEB SERVICE GET TIERS ===========================================");
    return tiersResponse;
  }

  /**
   * @RequestParam String
   * @return Tier
   * @throws Exception
   **/
  @RequestMapping(value = "/updateTiers", method = RequestMethod.POST,
      consumes = "application/json", produces = "application/json")
  public NotationRefTier updateTier(@RequestBody NotationRefTier notationRefTier) throws Exception {
    TiersResponse tiersResponse = new TiersResponse();
    try {
      LOGGER.info("=========== LANCEMENT DU WEB SERVICE UPDATE TIERS = "
          + notationRefTier.getSiren() + " ===========");
      notationRefTier = btnRepoService.updateTiers(notationRefTier);
    } catch (TechnicalException e) {
      LOGGER.error("=== TIERS INTROUVABLE ===: ", e);
      tiersResponse.setStatus(BtnRepoConstants.STATUS_FAILURE);
      tiersResponse.setError(new ResponseError(e.getCode(), e.getMessage()));
    } catch (Exception e) {
      LOGGER.error("=== ERREUR CHARGEMENT TIERS ===: ", e);
      tiersResponse.setStatus(BtnRepoConstants.STATUS_FAILURE);
      tiersResponse.setError(new ResponseError(BtnRepoConstants.DATA_ERROR_CODE, e.getMessage()));
    }
    LOGGER.info(
        "=========== FIN DU WEB SERVICE UPDATE TIERS ===========================================");
    return notationRefTier;
  }


  /**
   * @RequestParam Integer
   * @return Integer
   * @throws Exception
   **/
  @RequestMapping(value = "/callFunction/{refAppel}", method = RequestMethod.GET,
      produces = "application/json")
  public Integer callFluxElliFunction(@PathVariable("refAppel") Long refAppel) throws Exception {
    Integer fuctionResult = 0;
    try {
      LOGGER.info("===== LANCEMENT DU WEB SERVICE CALL FUNCTION for REF = " + refAppel + " ======");
      fuctionResult = btnRepoService.callFluxElliFunction(refAppel);
    } catch (Exception e) {
      LOGGER.error("=== ERREUR CALL FUNCTION ===: ", e);
      fuctionResult = -1;
    }
    LOGGER.info(
        "=========== FIN DU WEB SERVICE CALL FUNCTION ===========================================");
    return fuctionResult;
  }
  
  /**
   * @RequestParam Integer
   * @return Integer
   * @throws Exception
   **/
  @RequestMapping(value = "/callCreationTiersFunction/{siren}", method = RequestMethod.GET,
      produces = "application/json")
  public Integer callCreationTiersFunction(@PathVariable("siren") String siren) throws Exception {
    Integer fuctionResult = 0;
    try {
      LOGGER.info("===== LANCEMENT DU WEB SERVICE CALL FUNCTION CREATION TIER for SIREN = " + siren + " ======");
      fuctionResult = btnRepoService.callCreateTiersFunction(siren);
    } catch (Exception e) {
      LOGGER.error("=== ERREUR CALL FUNCTION CREATION TIER ===: ", e);
      fuctionResult = -1;
    }
    LOGGER.info(
        "=========== FIN DU WEB SERVICE CALL FUNCTION CREATION TIER ===========================================");
    return fuctionResult;
  }
}

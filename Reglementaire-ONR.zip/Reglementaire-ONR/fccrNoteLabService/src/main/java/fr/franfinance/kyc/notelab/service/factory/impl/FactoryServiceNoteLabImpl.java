package fr.franfinance.kyc.notelab.service.factory.impl;

import fr.franfinance.kyc.notelab.service.NoteLabService;
import fr.franfinance.kyc.notelab.service.factory.FactoryNoteLabService;
import fr.franfinance.kyc.notelab.service.impl.NoteLabServiceImpl;
import fr.franfinance.kyc.notelab.utils.TraiterException;

public class FactoryServiceNoteLabImpl extends FactoryNoteLabService {

	
	public NoteLabService creerServiceNoteLab() throws TraiterException {
		NoteLabService serviceNoteLab=new NoteLabServiceImpl();
		return serviceNoteLab;
	}
	
//	public ServiceAnnuaireGestion creerServiceAnnuaireGestion() throws TraiterException {
//		ServiceAnnuaireGestion serviceAnnuaireGestion=new ServiceAnnuaireGestionImpl();
//		return serviceAnnuaireGestion;
//	}

}

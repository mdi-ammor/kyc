package fr.franfinance.kyc.notelab.utils;

import fr.franfinance.fae.FAEException;

/**
 * @author adeq710
 * 
 */
public class TraiterException extends FAEException {
	public TraiterException(String messageName) {
        super(messageName);
    }

    public TraiterException(String aMessageName, Object[] aValues) {
        super(aMessageName, aValues);
    }

}

package fr.franfinance.kyc.notelab.model;

import java.io.Serializable;
import java.util.Date;


//@Entity
//@Table(name="CARACT_TIERS")
public class CaractTier implements Serializable {
	

	private static final long serialVersionUID = 5719015548567729916L;

	private Integer idCaractTiers;
	private String codeCaract;
	private String codeProvenance;
	private Date dateDebutValidite;
	private Date dateEffetNoteLab;
	private String idProvenance;
	private String notelab;
	private String modeCalcul;
	private String motifForcage;
	private String flagVerrou;
	//private NotationRefTier notationRefTier;
	

//	@ManyToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "ID_TIERS_BNOT")
//	public NotationRefTier getNotationRefTier() {
//		return notationRefTier;
//	}
//
//	public void setNotationRefTier(NotationRefTier notationRefTier) {
//		this.notationRefTier = notationRefTier;
//	}

	public CaractTier() {
	}

//	@Id
//	@Column(name="ID_CARACT_TIERS")
	public Integer getIdCaractTiers() {
		return idCaractTiers;
	}

	public void setIdCaractTiers(Integer idCaractTiers) {
		this.idCaractTiers = idCaractTiers;
	}

//	@Column(name="CODE_CARACT")
	public String getCodeCaract() {
		return codeCaract;
	}

	public void setCodeCaract(String codeCaract) {
		this.codeCaract = codeCaract;
	}

//	@Column(name = "CODE_PROVENANCE")
	public String getCodeProvenance() {
		return codeProvenance;
	}

	public void setCodeProvenance(String codeProvenance) {
		this.codeProvenance = codeProvenance;
	}

//	@Temporal(TemporalType.DATE)
//	@Column(name = "DATE_DEBUT_VALIDITE")
	public Date getDateDebutValidite() {
		return dateDebutValidite;
	}

	public void setDateDebutValidite(Date dateDebutValidite) {
		this.dateDebutValidite = dateDebutValidite;
	}

//	@Temporal(TemporalType.DATE)
//	@Column(name = "DATE_FCT1")
	public Date getDateEffetNoteLab() {
		return dateEffetNoteLab;
	}

	public void setDateEffetNoteLab(Date dateEffetNoteLab) {
		this.dateEffetNoteLab = dateEffetNoteLab;
	}

//	@Column(name = "ID_PROVENANCE")
	public String getIdProvenance() {
		return idProvenance;
	}

	public void setIdProvenance(String idProvenance) {
		this.idProvenance = idProvenance;
	}

//	@Column(name = "VALEUR_CARACT1")
	public String getNotelab() {
		return notelab;
	}

	public void setNotelab(String notelab) {
		this.notelab = notelab;
	}

//	@Column(name = "VALEUR_CARACT2")
	public String getModeCalcul() {
		return modeCalcul;
	}

	public void setModeCalcul(String modeCalcul) {
		this.modeCalcul = modeCalcul;
	}

//	@Column(name = "VALEUR_CARACT3")
	public String getMotifForcage() {
		return motifForcage;
	}

	public void setMotifForcage(String motifForcage) {
		this.motifForcage = motifForcage;
	}

//	@Column(name = "VALEUR_CARACT4")
	public String getFlagVerrou() {
		return flagVerrou;
	}

	public void setFlagVerrou(String flagVerrou) {
		this.flagVerrou = flagVerrou;
	}

}
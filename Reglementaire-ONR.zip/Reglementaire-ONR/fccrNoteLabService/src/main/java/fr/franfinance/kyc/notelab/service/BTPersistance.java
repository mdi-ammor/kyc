package fr.franfinance.kyc.notelab.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import fr.franfinance.fae.persistance.PersistanceException;
import fr.franfinance.framework.persistence.ObjectNotFoundException;
import fr.franfinance.framework.persistence.PersistenceHelper;
import fr.franfinance.kyc.notelab.model.NotationRefTier;

public class BTPersistance{
	
	
  private static final Log log = LogFactory.getLog(BTPersistance.class);
  public final static String DB_APPLICATION = "notationtiers";
  private final static String NOTELAB_OQLSERVICES = "notelab-oqlqueries";

  
	/**
	 * R�cup�re la liste des SIREN fictifs
	 * @return une liste de fr.franfinance.fae.bo.tiers.SirenFictif
	 * @throws PersistanceException
	 */
	
	public static NotationRefTier getNoteLabBySiren(String siren) throws PersistanceException {

		NotationRefTier noteLab = null;

		try {
			noteLab =
				(NotationRefTier) PersistenceHelper.findSingleton(
						BTPersistance.DB_APPLICATION,
					"queryNotationBySiren",
					new Object[] { siren },
					PersistenceHelper.ReadOnly,
					BTPersistance.NOTELAB_OQLSERVICES);
		} catch (ObjectNotFoundException oe) {
			StringBuffer strBuf = new StringBuffer(53);
			strBuf.append("Aucune note Lab trouv�e pour ce siren");
			strBuf.append(noteLab);
			log.debug(strBuf.toString());
		} catch (Exception e) {
			log.debug(e, e);
			throw new PersistanceException("persistance", new Object[] { e });
		}
		log.debug("[" + noteLab + "]");
		return noteLab;
	}
	

}

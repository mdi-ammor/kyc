package fr.franfinance.kyc.notelab.service;

import fr.franfinance.fae.bo.tiers.donneesfinancieres.NoteLab;

public interface NoteLabService {
	
	//public Integer getNoteLabById(Long tierId) throws Exception;
	public NoteLab getNoteLabBySiren(String siren) throws Exception;
}

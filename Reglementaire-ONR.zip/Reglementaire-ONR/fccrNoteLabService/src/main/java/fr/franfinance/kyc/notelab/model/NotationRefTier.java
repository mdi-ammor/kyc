package fr.franfinance.kyc.notelab.model;

import java.io.Serializable;
import java.util.ArrayList;


/**
 * The persistent class for the NOTATION_REF_TIERS database table.
 * 
 */
//@Entity
//@Table(name="NOTATION_REF_TIERS")
public class NotationRefTier implements Serializable {

	private static final long serialVersionUID = -5886092920048619731L;
	
	private Integer idTiersBnot;
	private String codeStatut;
	private String idRct;
	private Integer idUniqueTiersBii;
	private String siren;
	private ArrayList<CaractTier> caractTierList;
	
	
//	@OneToMany(mappedBy = "notationRefTier", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
//	public Set<CaractTier> getCaractTierList() {
//		return caractTierList;
//	}
//
//	public void setCaractTierList(Set<CaractTier> caractTierList) {
//		this.caractTierList = caractTierList;
//	}

	public ArrayList<CaractTier> getCaractTierList() {
		return caractTierList;
	}

	public void setCaractTierList(ArrayList<CaractTier> caractTierList) {
		this.caractTierList = caractTierList;
	}

	public NotationRefTier() {
	}

//	@Id
//	@Column(name="ID_TIERS_BNOT")
	public Integer getIdTiersBnot() {
		return this.idTiersBnot;
	}

	public void setIdTiersBnot(Integer idTiersBnot) {
		this.idTiersBnot = idTiersBnot;
	}

//	@Column(name="CODE_STATUT")
	public String getCodeStatut() {
		return this.codeStatut;
	}

	public void setCodeStatut(String codeStatut) {
		this.codeStatut = codeStatut;
	}

//	@Column(name="ID_RCT")
	public String getIdRct() {
		return this.idRct;
	}

	public void setIdRct(String idRct) {
		this.idRct = idRct;
	}

//	@Column(name="ID_UNIQUE_TIERS_BII")
	public Integer getIdUniqueTiersBii() {
		return this.idUniqueTiersBii;
	}

	public void setIdUniqueTiersBii(Integer idUniqueTiersBii) {
		this.idUniqueTiersBii = idUniqueTiersBii;
	}

	public String getSiren() {
		return this.siren;
	}

	public void setSiren(String siren) {
		this.siren = siren;
	}


	@Override
	public String toString() {
		return "NotationRefTier [idTiersBnot=" + idTiersBnot + ", codeStatut="
				+ codeStatut + ", idRct=" + idRct + ", idUniqueTiersBii="
				+ idUniqueTiersBii + ", siren=" + siren + ", caractTierList="
				+ caractTierList + "]";
	}
	
}

package fr.franfinance.kyc.notelab.service.factory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import fr.franfinance.kyc.notelab.service.NoteLabService;
import fr.franfinance.kyc.notelab.utils.TraiterException;

/**
 * @author adex099
 *
 * Pour changer le mod�le de ce commentaire de type g�n�r�, allez � :
 * Fen�tre&gt;Pr�f�rences&gt;Java&gt;G�n�ration de code&gt;Code et commentaires
 */
public abstract class FactoryNoteLabService {
	
	protected final static Log log =LogFactory.getLog(FactoryNoteLabService.class);

//	private final static String IMPLEMENTATION_FACTORY =
//			"notelab.service.factory";
		private final static String IMPLEMENTATION_FACTORY_DEFAULT =
			"fr.franfinance.kyc.notelab.service.factory.impl.FactoryServiceNoteLabImpl";
		//private static Properties propertiesAnnuaire;

//		static {
//			ResourceBundle resourceBundle;
//			try {
//				resourceBundle = ResourceBundle.getBundle("annuaire");
//				propertiesAnnuaire =
//					UtilProperties.createProperties(resourceBundle);
//			}
//			catch (Exception e) {
//				
//				if (log.isDebugEnabled()){
//					log.debug("RessourceBundle annuaire (fichier 'annuaire.properties' introuvable) implementation par defaut");
//				}
//			}
//		}

		public static FactoryNoteLabService newInstance()
			throws TraiterException {
			FactoryNoteLabService factory = null;
			String nomImpl = null;
//			if (propertiesAnnuaire != null) {
//				nomImpl =	FactoryNoteLabService.IMPLEMENTATION_FACTORY;
//			}
//			if (nomImpl == null) {
//				if (log.isDebugEnabled()){
//					log.debug("IMPLEMENTATION_FACTORY not found in properties file ");
//				}
				nomImpl = FactoryNoteLabService.IMPLEMENTATION_FACTORY_DEFAULT;
			//}
			try {
				factory =
					(FactoryNoteLabService) Class.forName(nomImpl).newInstance();
			}
			catch (Exception e) {
				throw new TraiterException("default", new Object[] { e });
			}
			return factory;
		}

	public abstract NoteLabService creerServiceNoteLab()
			throws TraiterException;
			
//	public abstract ServiceNoteLabGestion creerServiceNoteLabGestion()
//		throws TraiterException;

}

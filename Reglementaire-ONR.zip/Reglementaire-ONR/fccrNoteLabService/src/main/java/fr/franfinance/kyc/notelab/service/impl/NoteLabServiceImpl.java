package 	fr.franfinance.kyc.notelab.service.impl;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import fr.franfinance.fae.bo.tiers.donneesfinancieres.NoteLab;
import fr.franfinance.kyc.notelab.model.CaractTier;
import fr.franfinance.kyc.notelab.model.NotationRefTier;
import fr.franfinance.kyc.notelab.service.BTPersistance;
import fr.franfinance.kyc.notelab.service.NoteLabService;
import fr.franfinance.kyc.notelab.utils.TraiterException;

public class NoteLabServiceImpl implements NoteLabService {
	private static Log log = LogFactory.getLog(NoteLabServiceImpl.class);
//	@Autowired
//	private NoteLabDao noteLabDao;
//	private NoteLabDaoImpl noteLabPersistance = null;

//	@Transactional
//	public Integer getNoteLabById(Long tierId) throws Exception {
//		return getNoteLab(noteLabDao.getNoteLabById(tierId));
//	}

//	@Transactional
	public NoteLab getNoteLabBySiren(String siren) throws Exception {
		NotationRefTier notationTiers = BTPersistance.getNoteLabBySiren(siren);
		if (log.isDebugEnabled()){
			log.debug("notationTiers : "+notationTiers);
		}
		return getNoteLab(notationTiers);
	}

	private NoteLab getNoteLab (NotationRefTier notationRefTier) throws Exception {
		NoteLab note = null;
		Integer noteLab = 0;
		Date dateNotation ;
		Date dateInterroFccr;
		if (notationRefTier != null) {
			if (notationRefTier.getCodeStatut() == null) {
				note = new NoteLab();
				for (CaractTier caracTier : notationRefTier.getCaractTierList()) {
					if ("COTLAB".equals(caracTier.getCodeCaract())) {
						noteLab = convertNoteLab(caracTier.getNotelab());
						dateNotation = caracTier.getDateEffetNoteLab();
						dateInterroFccr = caracTier.getDateDebutValidite();
						note.setValeur(noteLab.toString());
						note.setDateNotation(dateNotation);
						note.setDateValidite(dateInterroFccr);
						break;
					}
				}
			}
		} 
		return note;
	}

	private Integer convertNoteLab (String noteLabString) {
		Map<String, Integer> mapNoteLab = new LinkedHashMap<String, Integer>();
		mapNoteLab.put("LOW", 1);
		mapNoteLab.put("MEDIUM_LOW", 2);
		mapNoteLab.put("MEDIUM_HIGH", 3);
		mapNoteLab.put("HIGH", 4);
		return mapNoteLab.get(noteLabString);	
	}
//	
//	public NoteLabDao getNoteLabDao() {
//		return noteLabDao;
//	}
//
//	public void setNoteLabDao(NoteLabDao noteLabDao) {
//		this.noteLabDao = noteLabDao;
//	}

}

package fr.franfinance.kyc.notelab.service.test;


public class NoteLabServiceMocks {

	//NoteLabService mock = mock(NoteLabService.class);
	
	
//	@Test
//	public void testGetNoteLabById_NoteLabHigh() throws Exception {	
//        when(mock.getNoteLabById(new Long(532))).thenReturn(4);
//        assertEquals(mock.getNoteLabById(new Long(532)), Integer.valueOf(4));
//	}
//	
//	@Test
//	public void testGetNoteLabById_NoteLabLow() throws Exception {
//        when(mock.getNoteLabById(new Long(159462))).thenReturn(Integer.valueOf(1));
//        assertEquals(mock.getNoteLabById(new Long(159462)), Integer.valueOf(1));
//	}
//	
//	@Test(expected=TraiterException.class)
//	public void testGetNoteLabById_TierNonExistant() throws Exception {
//		when(mock.getNoteLabById(new Long(123456789))).thenThrow(new TraiterException("ier non existant"));
//		when(mock.getNoteLabById(new Long(123456789))).thenReturn(null);
//        assertEquals(mock.getNoteLabById(new Long(123456789)), null);
//	}

//	@Test(expected=TraiterException.class)
//	public void testGetNoteLabById_RecordNullNonExistant() throws Exception {
//		when(mock.getNoteLabBySiren("010101")).thenThrow(new TraiterException("Record null non existant"));
//		when(mock.getNoteLabBySiren("010101")).thenReturn(null);
//        assertEquals(mock.getNoteLabBySiren("010101"), null);
//	}
//	@Test
//	public void testGetNoteLabById_CotlabNonExistant() throws Exception {
//		when(mock.getNoteLabById(new Long(148095))).thenReturn(null);
//        assertEquals(mock.getNoteLabById(new Long(148095)), null);
//	}
//
//	@Test
//	public void testGetNoteLabById_NoteLabNull() throws Exception {
//		when(mock.getNoteLabById(new Long(148097))).thenReturn(null);
//        assertEquals(mock.getNoteLabById(new Long(148097)), null);
//	}	
	
	
//	@Test
//	public void testGetNoteLabBySiren_NoteLabHigh() throws Exception {	
//        when(mock.getNoteLabBySiren("388650970")).thenReturn(Integer.valueOf(4));
//        assertEquals(mock.getNoteLabBySiren("388650970"), Integer.valueOf(4));
//	}
//	
//	@Test
//	public void testGetNoteLabBySiren_NoteLabLow() throws Exception {
//        when(mock.getNoteLabBySiren("323114074")).thenReturn(Integer.valueOf(1));
//        assertEquals(mock.getNoteLabBySiren("323114074"), Integer.valueOf(1));
//	}
//	
//	@Test(expected=TraiterException.class)
//	public void testGetNoteLabBySiren_TierNonExistant() throws Exception {
//		when(mock.getNoteLabBySiren("987654321")).thenThrow(new TraiterException("Tier non existant"));
//		when(mock.getNoteLabBySiren("987654321")).thenReturn(null);		
//        assertEquals(mock.getNoteLabBySiren("987654321"), null);
//	}
//
//	@Test(expected=TraiterException.class)
//	public void testGetNoteLabBySiren_RecordNullNonExistant() throws Exception {
//		when(mock.getNoteLabBySiren("020202")).thenThrow(new TraiterException("Record null non existant"));
//		when(mock.getNoteLabBySiren("020202")).thenReturn(null);
//        assertEquals(mock.getNoteLabBySiren("020202"), null);
//	}
//	
//	
//	@Test
//	public void testGetNoteLabBySiren_CotlabNonExistant() throws Exception {
//		when(mock.getNoteLabBySiren("401391909")).thenReturn(null);
//        assertEquals(mock.getNoteLabBySiren("401391909"), null);
//	}
//
//	@Test
//	public void testGetNoteLabBySiren_NoteLabNull() throws Exception {
//		when(mock.getNoteLabBySiren("407574953")).thenReturn(null);
//        assertEquals(mock.getNoteLabBySiren("407574953"), null);
//	}

}

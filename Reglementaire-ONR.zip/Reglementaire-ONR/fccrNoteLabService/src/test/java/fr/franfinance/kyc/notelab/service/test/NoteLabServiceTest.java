package fr.franfinance.kyc.notelab.service.test;

import fr.franfinance.kyc.notelab.service.NoteLabService;

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = "/config/applicationContextTest.xml")
public class NoteLabServiceTest {
	//@Autowired
	private NoteLabService noteLabService;

	/************ Test service getNoteLabById ***************/
//	@Test
//	public void testGetNoteLabById_NoteLabHight() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabById(new Long(532));
//		assertEquals(Integer.valueOf(4), noteLab);
//	}
//	
//	@Test
//	public void testGetNoteLabById_NoteLabLow() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabById(new Long(30513));
//		assertEquals(Integer.valueOf(1), noteLab);
//	}
//	
//	@Test(expected=TraiterException.class)
//	public void testGetNoteLabById_TierNonExistant() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabById(new Long(123456789));
//		assertEquals(null, noteLab);
//	}
//	
//	@Test
//	public void testGetNoteLabById_CotlabNonExistant() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabById(new Long(148095));
//		assertEquals(Integer.valueOf(0), noteLab);
//	}
//	
//	@Test
//	public void testGetNoteLabById_NoteLabNull() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabById(new Long(148097));
//		assertEquals(Integer.valueOf(0), noteLab);
//	}
//	
	
//	@Test
//	public void testGetNoteLabBySiren_NoteLabHight() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabBySiren("348033473");
//		assertEquals(Integer.valueOf(4), noteLab);
//	}
//	
//	@Test
//	public void testGetNoteLabBySiren_NoteLabLow() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabBySiren("424531028");
//		assertEquals(Integer.valueOf(1), noteLab);
//	}
//	
//	@Test(expected=TraiterException.class)
//	public void testGetNoteLabBySiren_TierNonExistant() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabBySiren("987654321");
//		assertEquals(Integer.valueOf(0), noteLab);
//	}
//	
//	@Test
//	public void testGetNoteLabBySiren_CotlabNonExistant() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabBySiren("401391909");
//		assertEquals(Integer.valueOf(0), noteLab);
//	}
//	
//	@Test
//	public void testGetNoteLabBySiren_NoteLabNull() throws Exception {
//		Integer noteLab = noteLabService.getNoteLabBySiren("407574953");
//		assertEquals(Integer.valueOf(0), noteLab);
//	}
}

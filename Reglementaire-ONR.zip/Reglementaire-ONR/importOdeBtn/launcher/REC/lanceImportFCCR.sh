#! /bin/ksh
echo $(date +"%H:%M:%S") "- Debut Lancement Import FCCR"
$REL_HOME/ImportOdeBtn/lanceImportFCCR.sh /usr/java8_64/jre/bin REC $REC_HOME/ImportOdeBtn/lib
echo $(date +"%H:%M:%S") "- Fin Lancement Export FCCR"
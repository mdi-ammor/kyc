#! /bin/ksh
JAVA_HOME=$1
ENV_TARGET=$2
JAR_HOME=$3

echo $(date +"%d/%m/%Y %H:%M:%S") "Lancement de IMPORT ODFE BTN" >> /temp/faedist/ode/$ENV_TARGET/Log/ImportOdeBtn/import-ode.log

$JAVA_HOME/java -DenvTarget=$ENV_TARGET -jar $JAR_HOME/importOdeBtn.jar

if [ $? != 0 ] ; then
       echo $(date +"%d/%m/%Y %H:%M:%S") "Erreur de IMPORT ODFE BTN" >> /temp/faedist/ode/$ENV_TARGET/Log/ImportOdeBtn/import-ode.log
       exit 1;
fi 
  
echo $(date +"%d/%m/%Y %H:%M:%S") "Fin de IMPORT ODFE BTN" >> /temp/faedist/ode/$ENV_TARGET/Log/ImportOdeBtn/import-ode.log
exit 0;
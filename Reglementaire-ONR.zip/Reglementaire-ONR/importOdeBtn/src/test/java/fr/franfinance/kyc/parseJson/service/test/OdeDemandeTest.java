package fr.franfinance.kyc.parseJson.service.test;

import java.util.Date;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import fr.franfinance.fae.kyc.fccr.parseJson.config.ParseJsonConfig;
import fr.franfinance.fae.kyc.fccr.parseJson.config.bean.UriBeanParseJson;
import fr.franfinance.fae.kyc.parseJson.database.model.OdeDemande;
import fr.franfinance.fae.kyc.parseJson.service.DatabaseService;
import fr.franfinance.fae.kyc.parseJson.service.JsonService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/config/applicationContext.xml")

public class OdeDemandeTest {

  public static UriBeanParseJson filePathBean = ParseJsonConfig.getUriBean();
  
  @Autowired
  private JsonService jsonService;
  @Autowired
  private DatabaseService databaseService;

  @Test
  public void testOdeDemande() throws Exception {
    // Flux demandes
    try {
      List<OdeDemande> odeDemandeList = jsonService.parseAllOdeDemande(filePathBean.getSourcesJsonPath());
      for (OdeDemande odeDemande : odeDemandeList) {
        // Set Date Insertion
        odeDemande.setDateInsertion(new Date());
        System.out.println(odeDemande);
        databaseService.save(odeDemande);
      }
    } catch (Exception e) {
      System.out.println(e.getStackTrace());
    }
  }
}

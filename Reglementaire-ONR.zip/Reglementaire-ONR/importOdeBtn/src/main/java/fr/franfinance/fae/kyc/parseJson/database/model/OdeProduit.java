package fr.franfinance.fae.kyc.parseJson.database.model;

import java.io.Serializable;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.franfinance.fae.kyc.parseJson.utils.ParserJsonConstants;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "ODE_TIERS")
@JsonIgnoreProperties(ignoreUnknown = true)
public class OdeProduit implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "ID_ODE_TIERS")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ODE_TIERS_SQ")
  @SequenceGenerator(name = "ODE_TIERS_SQ", sequenceName = "ODE_TIERS_SQ", allocationSize = 1,
      initialValue = 1)
  private long idOdeTiers;

  @Column(name = "NOT_SIREN_NUM_SIREN")
  private String numeroSiren;

  @Column(name = "NOT_RAIS_SOC")
  private String raisonSociale;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DT_CREATION")
  private Date dateCreation;

  @Column(name = "NOT_TYPE_TIERS")
  private String typeTiersLie;

  @Column(name = "NOT_CP_TIERS")
  private String codePostal;

  @Column(name = "NOT_PAYS_TIERS")
  private String codePays;

  @Column(name = "NOT_ID_RCT")
  private String refSG;

  @Temporal(TemporalType.DATE)
  @Column(name = "NOT_DATE_EXPORT")
  private Date dateExport;

  @Column(name = "NOT_VERSION_FLUX")
  private String versionFlux;

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_INSERT")
  private Date dateInsertion;

  @ManyToMany(cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
  @JoinTable(name = "ODE_PRODUIT_TIERS", joinColumns = {@JoinColumn(name = "ID_ODE_TIERS")},
      inverseJoinColumns = {@JoinColumn(name = "ID_PRODUIT")})
  private List<Produit> odeProduits;


  public long getIdOdeTiers() {
    return idOdeTiers;
  }

  public void setIdOdeTiers(long idOdeTiers) {
    this.idOdeTiers = idOdeTiers;
  }

  public String getNumeroSiren() {
    return numeroSiren;
  }

  public void setNumeroSiren(String numeroSiren) {
    this.numeroSiren = numeroSiren;
  }

  public String getRaisonSociale() {
    return raisonSociale;
  }

  public void setRaisonSociale(String raisonSociale) {
    this.raisonSociale = raisonSociale;
  }

  public Date getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(Date dateCreation) {
    this.dateCreation = dateCreation;
  }

  public String getTypeTiersLie() {
    return typeTiersLie;
  }

  public void setTypeTiersLie(String typeTiersLie) {
    this.typeTiersLie = typeTiersLie;
  }

  public String getCodePostal() {
    return codePostal;
  }

  public void setCodePostal(String codePostal) {
    this.codePostal = codePostal;
  }

  public String getCodePays() {
    return codePays;
  }

  public void setCodePays(String codePays) {
    this.codePays = codePays;
  }

  public String getRefSG() {
    return refSG;
  }

  public void setRefSG(String refSG) {
    this.refSG = refSG;
  }

  public Date getDateInsertion() {
    return dateInsertion;
  }

  public void setDateInsertion(Date dateInsertion) {
    this.dateInsertion = dateInsertion;
  }

  public Date getDateExport() {
    return dateExport;
  }

  public void setDateExport(Date dateExport) {
    this.dateExport = dateExport;
  }


  public String getVersionFlux() {
    return versionFlux;
  }

  public void setVersionFlux(String versionFlux) {
    this.versionFlux = versionFlux;
  }


  public List<Produit> getOdeProduits() {
    return odeProduits;
  }

  public void setOdeProduits(List<Produit> odeProduits) {
    this.odeProduits = odeProduits;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public String toString() {
    return "OdeProduit [idOdeTiers=" + idOdeTiers + ", numeroSiren=" + numeroSiren
        + ", raisonSociale=" + raisonSociale + ", dateCreation=" + dateCreation + ", typeTiersLie="
        + typeTiersLie + ", codePostal=" + codePostal + ", codePays=" + codePays + ", refSG="
        + refSG + ", dateExport=" + dateExport + ", versionFlux=" + versionFlux + ", dateInsertion="
        + dateInsertion + ", odeProduits=" + odeProduits + "]";
  }
}

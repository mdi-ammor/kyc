package fr.franfinance.fae.kyc.parseJson.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import fr.franfinance.fae.kyc.parseJson.dao.DatabaseDao;
import fr.franfinance.fae.kyc.parseJson.database.model.Produit;
import fr.franfinance.fae.kyc.parseJson.service.DatabaseService;

@Service
public class DatabaseServiceImpl implements DatabaseService {

  @Autowired
  private DatabaseDao databaseDao;

  @Transactional
  public void save(Object object) {
    databaseDao.save(object);
  }

  @Transactional
  public void truncate(String table) {
    databaseDao.truncate(table);
  }

  @Transactional
  public List<Produit> getAllProduit() {
    return databaseDao.getAllProduit();
  }

  public DatabaseDao getDatabaseDao() {
    return databaseDao;
  }

  public void setDatabaseDao(DatabaseDao databaseDao) {
    this.databaseDao = databaseDao;
  }
}

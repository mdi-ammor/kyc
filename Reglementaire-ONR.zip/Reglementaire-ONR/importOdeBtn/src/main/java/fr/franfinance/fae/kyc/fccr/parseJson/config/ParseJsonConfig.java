package fr.franfinance.fae.kyc.fccr.parseJson.config;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import fr.franfinance.fae.kyc.fccr.parseJson.config.bean.UriBeanParseJson;

public final class ParseJsonConfig {

  private static AnnotationConfigApplicationContext context;

  public static UriBeanParseJson getUriBean() {
    context = new AnnotationConfigApplicationContext(ParseJsonSpringConfig.class);
    return context.getBean(UriBeanParseJson.class);
  }  
}

package fr.franfinance.fae.kyc.parseJson.database.model;

import java.io.Serializable;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import fr.franfinance.fae.kyc.parseJson.utils.ParserJsonConstants;
import java.util.Date;


@Entity
@Table(name = "ODE_DEMANDE")
public class OdeDemande implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "ID_ODE_DEMANDE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ODE_DEMANDE_SQ")
  @SequenceGenerator(name = "ODE_DEMANDE_SQ", sequenceName = "ODE_DEMANDE_SQ", allocationSize = 1,
      initialValue = 1)
  private long idOdeDemande;

  @Column(name = "NOT_SIREN_NUM_SIREN")
  private String numeroSiren;

  @Column(name = "NOT_NUM_DOS")
  private String numDossier;

  @Column(name = "NOT_DECISION")
  private String decision;

  @Column(name = "NOT_TYPE_DDE")
  private String typeDemande;

  @Column(name = "NOT_CODE_PROD")
  private String codeProduit;

  @Column(name = "NOT_MARCHE")
  private String libelleGroupeMarche;

  @Column(name = "NOT_SOUS_MARCHE")
  private String codeMarche;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DATE_DOS")
  private Date dateCreation;

  @Temporal(TemporalType.DATE)
  @Column(name = "NOT_DATE_EXPORT")
  private Date dateExport;

  @Column(name = "NOT_VERSION_FLUX")
  private String versionFlux;

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_INSERT")
  private Date dateInsertion;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DATE_DECISION")
  private Date dateMajDecision;


  public long getIdOdeDemande() {
    return idOdeDemande;
  }

  public void setIdOdeDemande(long idOdeDemande) {
    this.idOdeDemande = idOdeDemande;
  }

  public String getNumeroSiren() {
    return numeroSiren;
  }

  public void setNumeroSiren(String numeroSiren) {
    this.numeroSiren = numeroSiren;
  }

  public String getNumDossier() {
    return numDossier;
  }

  public void setNumDossier(String numDossier) {
    this.numDossier = numDossier;
  }

  public String getDecision() {
    return decision;
  }

  public void setDecision(String decision) {
    this.decision = decision;
  }

  public String getTypeDemande() {
    return typeDemande;
  }

  public void setTypeDemande(String typeDemande) {
    this.typeDemande = typeDemande;
  }

  public String getCodeProduit() {
    return codeProduit;
  }

  public void setCodeProduit(String codeProduit) {
    this.codeProduit = codeProduit;
  }

  public String getLibelleGroupeMarche() {
    return libelleGroupeMarche;
  }

  public void setLibelleGroupeMarche(String libelleGroupeMarche) {
    this.libelleGroupeMarche = libelleGroupeMarche;
  }

  public String getCodeMarche() {
    return codeMarche;
  }

  public void setCodeMarche(String codeMarche) {
    this.codeMarche = codeMarche;
  }

  public Date getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(Date dateCreation) {
    this.dateCreation = dateCreation;
  }

  public Date getDateExport() {
    return dateExport;
  }

  public void setDateExport(Date dateExport) {
    this.dateExport = dateExport;
  }

  public String getVersionFlux() {
    return versionFlux;
  }

  public void setVersionFlux(String versionFlux) {
    this.versionFlux = versionFlux;
  }

  public Date getDateInsertion() {
    return dateInsertion;
  }

  public void setDateInsertion(Date dateInsertion) {
    this.dateInsertion = dateInsertion;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  public Date getDateMajDecision() {
    return dateMajDecision;
  }

  public void setDateMajDecision(Date dateMajDecision) {
    this.dateMajDecision = dateMajDecision;
  }

  @Override
  public String toString() {
    return "OdeDemande [idOdeDemande=" + idOdeDemande + ", numeroSiren=" + numeroSiren
        + ", numDossier=" + numDossier + ", decision=" + decision + ", typeDemande=" + typeDemande
        + ", codeProduit=" + codeProduit + ", libelleGroupeMarche=" + libelleGroupeMarche
        + ", codeMarche=" + codeMarche + ", dateCreation=" + dateCreation + ", dateExport="
        + dateExport + ", versionFlux=" + versionFlux + ", dateInsertion=" + dateInsertion
        + ", dateMajDecision=" + dateMajDecision + "]";
  }

}

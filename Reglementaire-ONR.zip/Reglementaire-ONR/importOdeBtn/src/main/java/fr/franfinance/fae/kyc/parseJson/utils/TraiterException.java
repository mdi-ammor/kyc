package fr.franfinance.fae.kyc.parseJson.utils;

/**
 * @author adeq710
 * 
 */
public class TraiterException extends Exception {
  private static final long serialVersionUID = 1L;
  String messageException = "";

  public TraiterException(String messageException) {
    super();
    this.messageException = messageException;
  }

  public String getMessageException() {
    return messageException;
  }

  public void setMessageException(String messageException) {
    this.messageException = messageException;
  }

}

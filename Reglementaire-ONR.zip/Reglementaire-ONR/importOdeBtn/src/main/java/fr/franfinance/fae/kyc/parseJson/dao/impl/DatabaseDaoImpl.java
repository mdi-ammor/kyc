package fr.franfinance.fae.kyc.parseJson.dao.impl;


import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import fr.franfinance.fae.kyc.parseJson.dao.DatabaseDao;
import fr.franfinance.fae.kyc.parseJson.database.model.Produit;

@Repository
public class DatabaseDaoImpl implements DatabaseDao {

  @Autowired
  private SessionFactory session;

  @Override
  public void save(Object object) {
    session.getCurrentSession().saveOrUpdate(object);
  }

  @Override
  public void truncate(String table) {
    session.getCurrentSession().createQuery("DELETE FROM " + table).executeUpdate();
  }

  @Override
  @SuppressWarnings("unchecked")
  public List<Produit> getAllProduit() {
    return session.getCurrentSession().createQuery("from Produit").list();
  }


  public SessionFactory getSession() {
    return session;
  }

  public void setSession(SessionFactory session) {
    this.session = session;
  }
}

package fr.franfinance.fae.kyc.parseJson.dao.impl;

import java.io.File;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.franfinance.fae.kyc.parseJson.dao.DatabaseDao;
import fr.franfinance.fae.kyc.parseJson.dao.JsonDao;
import fr.franfinance.fae.kyc.parseJson.database.model.*;

@Repository
public class JsonDaoImpl implements JsonDao {
  private ObjectMapper mapper = new ObjectMapper();

  @Autowired
  private SessionFactory session;

  @Autowired
  private DatabaseDao databaseDao;

  @Override
  public List<OdeTier> getOdeTier(String jsonFile) throws Exception {
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    return mapper.readValue(new File(jsonFile), new TypeReference<List<OdeTier>>() {});
  }
  
  @Override
  public List<OdeDemande> getOdeDemande(String jsonFile) throws Exception {
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    mapper.readValue(new File(jsonFile), new TypeReference<List<OdeDemande>>() {});
    return mapper.readValue(new File(jsonFile), new TypeReference<List<OdeDemande>>() {});
  }

  @Override
  public List<OdeProduit> getOdeProduit(String jsonFile) throws Exception {
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    return mapper.readValue(new File(jsonFile), new TypeReference<List<OdeProduit>>() {});
  }
  
  public SessionFactory getSession() {
    return session;
  }

  public void setSession(SessionFactory session) {
    this.session = session;
  }

  public DatabaseDao getDatabaseDao() {
    return databaseDao;
  }

  public void setDatabaseDao(DatabaseDao databaseDao) {
    this.databaseDao = databaseDao;
  }

}

package fr.franfinance.fae.kyc.fccr.parseJson.config;

import java.util.Properties;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import fr.franfinance.fae.kyc.parseJson.database.model.*;
import fr.franfinance.fae.kyc.parseJson.utils.ParserJsonConstants;
import fr.franfinance.fae.kyc.fccr.parseJson.config.bean.UriBeanParseJson;

@Configuration
@PropertySources({
  @PropertySource(value = "file:${springConfigPath}/jdbc-${envTarget:DEV}.properties",
      ignoreResourceNotFound = true),
  @PropertySource(value = "file:${springConfigPath}/application-${envTarget:DEV}.properties",
      ignoreResourceNotFound = true),
  @PropertySource(value = "classpath:../config/jdbc-${envTarget:DEV}.properties",
      ignoreResourceNotFound = true),
  @PropertySource(value = "classpath:../config/application-${envTarget:DEV}.properties",
      ignoreResourceNotFound = true),
  @PropertySource(value = "classpath:/config/jdbc-${envTarget:DEV}.properties",
      ignoreResourceNotFound = true),
  @PropertySource(value = "classpath:/config/application-${envTarget:DEV}.properties",
      ignoreResourceNotFound = true)})


@EnableTransactionManagement
@ComponentScans(value = {@ComponentScan("fr.franfinance.fae.kyc.parseJson.dao"),
    @ComponentScan("fr.franfinance.fae.kyc.parseJson.service")})
public class ParseJsonSpringConfig {

  @Autowired
  private Environment env;

  @Value("${JSON_FILE_PATH}")
  private String sourcesJsonPath;

  @Bean
  public DataSource getDataSource() {
    BasicDataSource dataSource = new BasicDataSource();
    dataSource.setDriverClassName(env.getProperty(ParserJsonConstants.JDBC_DRIVER_NAME));
    dataSource.setUrl(env.getProperty(ParserJsonConstants.JDBC_URL));
    dataSource.setUsername(env.getProperty(ParserJsonConstants.JDBC_USERNAME));
    dataSource.setPassword(env.getProperty(ParserJsonConstants.JDBC_PASSWORD));
    return dataSource;
  }

  @Bean
  public LocalSessionFactoryBean getSessionFactory() {
    LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
    sessionFactory.setDataSource(getDataSource());
    sessionFactory.setHibernateProperties(additionalProperties());

    sessionFactory.setAnnotatedClasses(OdeDemande.class, OdeDirigeantActionnaire.class,
        OdeProduit.class, OdeTier.class, Produit.class);

    return sessionFactory;
  }

  @Bean
  public HibernateTransactionManager getTransactionManager() {
    HibernateTransactionManager transactionManager = new HibernateTransactionManager();
    transactionManager.setSessionFactory(getSessionFactory().getObject());
    return transactionManager;
  }

  Properties additionalProperties() {
    Properties props = new Properties();
    props.put(ParserJsonConstants.HIBERNATE_SHOW_SQL,
        env.getProperty(ParserJsonConstants.HIBERNATE_SHOW_SQL));
    props.put(ParserJsonConstants.HIBERNATE_HBM_DDL_AUTO,
        env.getProperty(ParserJsonConstants.HIBERNATE_HBM_DDL_AUTO));
    props.put(ParserJsonConstants.HIBERNATE_SCHEMA,
        env.getProperty(ParserJsonConstants.HIBERNATE_SCHEMA));
    return props;
  }

  @Bean
  public UriBeanParseJson getUriBean() {
    UriBeanParseJson uri = new UriBeanParseJson();
    uri.setSourcesJsonPath(sourcesJsonPath);
    return uri;
  }

}

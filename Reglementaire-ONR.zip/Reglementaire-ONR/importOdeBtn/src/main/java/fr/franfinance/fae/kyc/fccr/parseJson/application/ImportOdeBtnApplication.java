package fr.franfinance.fae.kyc.fccr.parseJson.application;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.dao.DataIntegrityViolationException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.franfinance.fae.kyc.fccr.parseJson.config.ParseJsonConfig;
import fr.franfinance.fae.kyc.fccr.parseJson.config.ParseJsonSpringConfig;
import fr.franfinance.fae.kyc.fccr.parseJson.config.bean.UriBeanParseJson;
import fr.franfinance.fae.kyc.parseJson.database.model.OdeDemande;
import fr.franfinance.fae.kyc.parseJson.database.model.OdeDirigeantActionnaire;
import fr.franfinance.fae.kyc.parseJson.database.model.OdeProduit;
import fr.franfinance.fae.kyc.parseJson.database.model.OdeTier;
import fr.franfinance.fae.kyc.parseJson.database.model.Produit;
import fr.franfinance.fae.kyc.parseJson.service.DatabaseService;
import fr.franfinance.fae.kyc.parseJson.service.JsonService;

/**
 * @author adeq685
 *
 */
public class ImportOdeBtnApplication {

  public static ApplicationContext context;
  public static UriBeanParseJson filePathBean;
  ObjectMapper mapper = new ObjectMapper();
  private static final Logger LOGGER = LoggerFactory.getLogger(ImportOdeBtnApplication.class);



  public static void main(String[] args) throws Exception {

    LOGGER.info(
        "=========== LANCEMENT BATCH IMPORT JSON ODE-BTN ===================================================");
    context = new AnnotationConfigApplicationContext(ParseJsonSpringConfig.class);
    filePathBean = ParseJsonConfig.getUriBean();

    LOGGER.info(
        "===========  IMPORT FLUX TIERS  ===================================================");
    importFluxOdeTier(filePathBean.getSourcesJsonPath());

    LOGGER.info(
        "===========  IMPORT FLUX DEMANDES  ===================================================");
    importFluxOdeDemande(filePathBean.getSourcesJsonPath());

    LOGGER.info(
        "===========  IMPORT FLUX PRODUITS  ===================================================");
    importFluxOdeProduit(filePathBean.getSourcesJsonPath());

    LOGGER.info(
        "============= FIN BATCH IMPORT JSON ODE-BTN ==================================================================");

    System.exit(0);
  }

  public static void importFluxOdeTier(String jsonSourceFolder) throws Exception {
    // Get List OdeTier from JSON
    List<OdeTier> odeTierList =
        context.getBean(JsonService.class).parseAllOdeTier(jsonSourceFolder);
    // Insert List OdeTier in BTN
    Integer cptErrors = 0;
    for (OdeTier odeTier : odeTierList) {
      try {
        // Set Date Insertion
        odeTier.setDateInsertion(new Date());
        if (odeTier.getOdeDirigeantsActionnaires() != null) {
          for (OdeDirigeantActionnaire odeDirigeantActionnaire : odeTier
              .getOdeDirigeantsActionnaires()) {
            odeDirigeantActionnaire.setNotSirenNumSiren(odeTier.getNumeroSiren());
            odeDirigeantActionnaire.setDateInsertion(new Date());
            odeDirigeantActionnaire.setNotDateInterroTiers(new Date());
            odeDirigeantActionnaire.setOdeTierJour(odeTier);
          }
          context.getBean(DatabaseService.class).save(odeTier);
        }
      } catch (DataIntegrityViolationException e) {
        LOGGER
            .error("--- ODE TIER JOUR : " + odeTier.getNumeroSiren() + " avec date d'interrogation "
                + odeTier.getHorodateEnrichissementDecision() + " existe deja  ---");
        cptErrors++;
      } catch (Exception e) {
        LOGGER.error("--- Probl�me lors de l'import de l'ODE TIER JOUR " + odeTier.getNumeroSiren()
            + " --- : ", e);
        cptErrors++;
      }
    }
    LOGGER.info("+++ NOMBRE ODE TIER JOUR a charger: " + odeTierList.size() + " +++");
    LOGGER.info("+++ NOMBRE ODE TIER JOUR en erreur: " + cptErrors + " +++");
  }

  public static void importFluxOdeDemande(String jsonSourceFolder) throws Exception {
    // Get List OdeDemande from JSON
    List<OdeDemande> odeDemandeList =
        context.getBean(JsonService.class).parseAllOdeDemande(jsonSourceFolder);
    // Insert List OdeDemande in BTN
    Integer cptErrors = 0;
    for (OdeDemande odeDemande : odeDemandeList) {
      try {
        // Set Date Insertion
        odeDemande.setDateInsertion(new Date());
        context.getBean(DatabaseService.class).save(odeDemande);
      } catch (DataIntegrityViolationException e) {
        LOGGER.error("---- ODE DEMANDE : " + odeDemande.getNumeroSiren() + " existe deja ----");
        cptErrors++;
      } catch (Exception e) {
        LOGGER.error("---- Exception lors de l'import de l'ODE DEMANDE  : "
            + odeDemande.getNumeroSiren() + " ----", e);
        cptErrors++;
      }
    }
    LOGGER.info("+++ NOMBRE ODE DEMANDES a charger: " + odeDemandeList.size() + " +++");
    LOGGER.info("+++ NOMBRE ODE DEMANDES en erreur: " + cptErrors + " +++");
  }

  public static void importFluxOdeProduit(String jsonSourceFolder) throws Exception {
    // Delete Product Stock
    LOGGER.info("+-+ SUPPRESSION ANCIEN STOCK ODE PRODUITS +-+");
    context.getBean(DatabaseService.class).truncate(OdeProduit.class.getName());
    // Get List OdeProduit from JSON
    Map<String, Produit> produitMap = getAllProduit();
    List<OdeProduit> odeProduitList =
        context.getBean(JsonService.class).parseAllOdeProduit(jsonSourceFolder);
    // Insert List OdeProduit in BTN
    Integer cptErrors = 0;
    for (OdeProduit odeProduit : odeProduitList) {
      try {
        // Set Date Insertion
        odeProduit.setDateInsertion(new Date());
        // Set Produit
        for (Produit produit : odeProduit.getOdeProduits()) {
          produit.setIdProduit(produitMap.get(produit.getCodeProduit()).getIdProduit());
          produit.setCodeStatut(produitMap.get(produit.getCodeProduit()).getCodeStatut());
          produit.setDateInsert(new Date());
        }
        context.getBean(DatabaseService.class).save(odeProduit);
      } catch (DataIntegrityViolationException e) {
        LOGGER.error("---- ODE PRODUIT : " + odeProduit.getNumeroSiren() + " existe deja ----");
        cptErrors++;
      } catch (Exception e) {
        LOGGER.error("---- Exception lors de l'import de l'ODE PRODUIT  : "
            + odeProduit.getNumeroSiren() + " ----", e);
        cptErrors++;
      }
    }
    LOGGER.info("+++ NOMBRE ODE PRODUITS a charger: " + odeProduitList.size() + " +++");
    LOGGER.info("+++ NOMBRE ODE PRODUITS en erreur: " + cptErrors + " +++");
  }

  public static Map<String, Produit> getAllProduit() {
    Map<String, Produit> produitMap = new HashMap<>();
    try {
      List<Produit> produitList = context.getBean(DatabaseService.class).getAllProduit();
      for (Produit produit : produitList) {
        produitMap.put(produit.getCodeProduit(), produit);
      }
    } catch (Exception e) {
      LOGGER.error("---- Exception lors Lecture des codes produits ----", e);
    }
    return produitMap;
  }
}

package fr.franfinance.fae.kyc.parseJson.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import fr.franfinance.fae.kyc.fccr.parseJson.application.ImportOdeBtnApplication;
import fr.franfinance.fae.kyc.parseJson.dao.JsonDao;
import fr.franfinance.fae.kyc.parseJson.database.model.OdeDemande;
import fr.franfinance.fae.kyc.parseJson.database.model.OdeProduit;
import fr.franfinance.fae.kyc.parseJson.database.model.OdeTier;
import fr.franfinance.fae.kyc.parseJson.service.JsonService;
import fr.franfinance.fae.kyc.parseJson.utils.ParseJsonUtil;
import fr.franfinance.fae.kyc.parseJson.utils.ParserJsonConstants;

@Service
public class JsonServiceImpl implements JsonService {

  @Autowired
  private JsonDao jsonDao;
  private static final Logger LOGGER = LoggerFactory.getLogger(ImportOdeBtnApplication.class);

  @Override
  public List<OdeTier> getOdeTier(String jsonFile) throws Exception {
    return jsonDao.getOdeTier(jsonFile);
  }

  @Override
  public List<OdeDemande> getOdeDemande(String jsonFile) throws Exception {
    return jsonDao.getOdeDemande(jsonFile);
  }

  @Override
  public List<OdeProduit> getOdeProduit(String jsonFile) throws Exception {
    return jsonDao.getOdeProduit(jsonFile);
  }

  @Override
  public List<OdeTier> parseAllOdeTier(String jsonSourceFolder) throws Exception {
    List<OdeTier> odeTierList = new ArrayList<OdeTier>();
    try {
      // control pattern of files to import
      File[] files = ParseJsonUtil.getFilesMatchingPattern(new File(jsonSourceFolder),
          ParserJsonConstants.REGEX_TIERS);
      // control Date of files (compare with today date)
      List<File> todayFiles = ParseJsonUtil.getFilesMatchingToday(files);
      if (todayFiles != null && !todayFiles.isEmpty()) {
        for (File file : todayFiles) {
          String filePath = ParseJsonUtil.getFilePath(jsonSourceFolder, file.getName());
          String[] fileNameInfo = ParseJsonUtil.getFileNameInfo(file.getName());
          odeTierList = getOdeTier(filePath);
          // Set Version Flux
          odeTierList.forEach(o -> o.setVersionFlux(fileNameInfo[1]));
          // Set Date Export
          Date dateExport = ParseJsonUtil.convertStringToDate(fileNameInfo[2]);
          odeTierList.forEach(o -> o.setDateExport(dateExport));
        }
      } else {
        LOGGER.error("---- Aucun fichier correspondant au regex " + ParserJsonConstants.REGEX_TIERS
            + " dans l'emplacement : " + jsonSourceFolder + " ----");
      }
    } catch (Exception e) {
      LOGGER.error("====== ERROR PARSING JSON FILE TIERS ===== : ", e);
    }
    return odeTierList;
  }

  @Override
  public List<OdeDemande> parseAllOdeDemande(String jsonSourceFolder) throws Exception {
    List<OdeDemande> odeDemandeList = new ArrayList<OdeDemande>();
    try {
      // control pattern of files to import
      File[] files = ParseJsonUtil.getFilesMatchingPattern(new File(jsonSourceFolder),
          ParserJsonConstants.REGEX_DDF);
      // control Date of files (compare with today date)
      List<File> todayFiles = ParseJsonUtil.getFilesMatchingToday(files);
      if (todayFiles != null && !todayFiles.isEmpty()) {
        for (File file : todayFiles) {
          String filePath = ParseJsonUtil.getFilePath(jsonSourceFolder, file.getName());
          String[] fileNameInfo = ParseJsonUtil.getFileNameInfo(file.getName());
          odeDemandeList = getOdeDemande(filePath);
          // Set Version Flux
          odeDemandeList.forEach(o -> o.setVersionFlux(fileNameInfo[1]));
          // Set Date Export
          Date dateExport = ParseJsonUtil.convertStringToDate(fileNameInfo[2]);
          odeDemandeList.forEach(o -> o.setDateExport(dateExport));
        }
      } else {
        LOGGER.error("---- Aucun fichier correspondant au regex " + ParserJsonConstants.REGEX_DDF
            + " dans l'emplacement : " + jsonSourceFolder + " ----");
      }
    } catch (Exception e) {
      LOGGER.error("====== ERROR PARSING JSON FILE DDF ===== : ", e);
    }
    return odeDemandeList;
  }

  @Override
  public List<OdeProduit> parseAllOdeProduit(String jsonSourceFolder) throws Exception {
    List<OdeProduit> odeProduitList = new ArrayList<OdeProduit>();
    try {
      // control pattern of files to import
      File[] files = ParseJsonUtil.getFilesMatchingPattern(new File(jsonSourceFolder),
          ParserJsonConstants.REGEX_PRODUITS);
      // control Date of files (compare with today date)
      List<File> todayFiles = ParseJsonUtil.getFilesMatchingToday(files);
      if (todayFiles != null && !todayFiles.isEmpty()) {
        for (File file : todayFiles) {
          String filePath = ParseJsonUtil.getFilePath(jsonSourceFolder, file.getName());
          String[] fileNameInfo = ParseJsonUtil.getFileNameInfo(file.getName());
          odeProduitList = getOdeProduit(filePath);
          // Set Version Flux
          odeProduitList.forEach(o -> o.setVersionFlux(fileNameInfo[1]));
          // Set Date Export
          Date dateExport = ParseJsonUtil.convertStringToDate(fileNameInfo[2]);
          odeProduitList.forEach(o -> o.setDateExport(dateExport));
        }
      } else {
        LOGGER
            .error("---- Aucun fichier correspondant au regex " + ParserJsonConstants.REGEX_PRODUITS
                + " dans l'emplacement : " + jsonSourceFolder + " ----");
      }
    } catch (Exception e) {
      LOGGER.error("====== ERROR PARSING JSON FILE PRODUIT ===== : ", e);
    }
    return odeProduitList;
  }

  public JsonDao getJsonDao() {
    return jsonDao;
  }

  public void setJsonDao(JsonDao jsonDao) {
    this.jsonDao = jsonDao;
  }

}

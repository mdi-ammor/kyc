package fr.franfinance.fae.kyc.parseJson.database.model;

import java.io.Serializable;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "PRODUIT")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Produit implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ODE_PRODUIT_TIERS_SQ")
  @SequenceGenerator(name = "ODE_PRODUIT_TIERS_SQ", sequenceName = "ODE_PRODUIT_TIERS_SQ",
      allocationSize = 1, initialValue = 1)
  @Column(name = "ID_PRODUIT")
  private long idProduit;

  @Column(name = "CODE_PROD")
  private String codeProduit;

  @Column(name = "CODE_STATUT")
  private String codeStatut;

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_INSERT")
  private Date dateInsert;

  @ManyToMany(mappedBy = "odeProduits", cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
  private List<OdeProduit> odeTiers;

  public Produit() {}

  public long getIdProduit() {
    return this.idProduit;
  }

  public void setIdProduit(long idProduit) {
    this.idProduit = idProduit;
  }

  public String getCodeProduit() {
    return codeProduit;
  }

  public void setCodeProduit(String codeProduit) {
    this.codeProduit = codeProduit;
  }

  public List<OdeProduit> getOdeTiers() {
    return odeTiers;
  }

  public void setOdeTiers(List<OdeProduit> odeTiers) {
    this.odeTiers = odeTiers;
  }

  public String getCodeStatut() {
    return this.codeStatut;
  }

  public void setCodeStatut(String codeStatut) {
    this.codeStatut = codeStatut;
  }

  public Date getDateInsert() {
    return this.dateInsert;
  }

  public void setDateInsert(Date dateInsert) {
    this.dateInsert = dateInsert;
  }

  public static long getSerialversionuid() {
    return serialVersionUID;
  }

  @Override
  public String toString() {
    return "Produit [idProduit=" + idProduit + ", codeProduit=" + codeProduit + ", codeStatut="
        + codeStatut + ", dateInsert=" + dateInsert + "]";
  }
}

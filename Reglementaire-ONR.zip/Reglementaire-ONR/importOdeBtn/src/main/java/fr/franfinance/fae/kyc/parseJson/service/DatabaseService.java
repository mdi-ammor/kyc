package fr.franfinance.fae.kyc.parseJson.service;

import java.util.List;
import fr.franfinance.fae.kyc.parseJson.database.model.Produit;

public interface DatabaseService {

  public void save(Object object);

  public void truncate(String table);
  
  public List<Produit> getAllProduit();

}

package fr.franfinance.fae.kyc.parseJson.service;

import java.util.List;
import fr.franfinance.fae.kyc.parseJson.database.model.*;

public interface JsonService {
  
  public List<OdeTier> getOdeTier(String jsonFile) throws Exception;

  public List<OdeDemande> getOdeDemande(String jsonFile) throws Exception;

  public List<OdeProduit> getOdeProduit(String jsonFile) throws Exception;

  public List<OdeDemande> parseAllOdeDemande(String jsonSourceFolder) throws Exception;

  public List<OdeProduit> parseAllOdeProduit(String jsonSourceFolder) throws Exception;

  public List<OdeTier> parseAllOdeTier(String  jsonSourceFolder) throws Exception;

}

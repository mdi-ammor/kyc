package fr.franfinance.fae.kyc.parseJson.utils;

public final class ParserJsonConstants {
  
  public static final String DATE_FORMAT = "dd-MM-yyyy";
  public static final String DATE_PATTERN = "dd/MM/yyyy";
  public static final String TIMESTAMP_FORMAT = "dd'/'MM'/'yyyy HH:mm:ss";
  public static final String DATE_LOCALE = "fr-FR";
  public static final String DATE_TIMEZONE = "Europe/Paris";
  public static final String SEPARATEUR_UNDERSCORE = "_";
  public static final String SEPARATEUR_POINT = ".";
  public static final String SEPARATEUR_SLASH = "/";
  
  public static final String IS_FOLDER = " est un dossier";
  
  public static final String JDBC_DRIVER_NAME = "jdbc.driverClassName";
  public static final String JDBC_URL = "jdbc.databaseurl";
  public static final String JDBC_USERNAME = "jdbc.username";
  public static final String JDBC_PASSWORD = "jdbc.password";
  
  public static final String HIBERNATE_SHOW_SQL = "hibernate.show_sql";
  public static final String HIBERNATE_HBM_DDL_AUTO = "hibernate.hbm2ddl.auto";
  public static final String HIBERNATE_SCHEMA = "hibernate.default_schema";
  
  public static final String REGEX_TIERS = "Tiers_V.*_\\d{2}-\\d{2}-\\d{4}.json";
  public static final String REGEX_DDF = "DDF_V.*_\\d{2}-\\d{2}-\\d{4}.json";
  public static final String REGEX_PRODUITS = "Produits_V.*_\\d{2}-\\d{2}-\\d{4}.json";
  
}

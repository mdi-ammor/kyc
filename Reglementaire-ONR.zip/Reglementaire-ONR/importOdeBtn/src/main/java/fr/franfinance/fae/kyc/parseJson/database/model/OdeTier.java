package fr.franfinance.fae.kyc.parseJson.database.model;

import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.franfinance.fae.kyc.parseJson.utils.ParserJsonConstants;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "ODE_TIERS_JOUR")
@JsonIgnoreProperties(ignoreUnknown = true)
public class OdeTier implements Serializable {

  private static final long serialVersionUID = 1L;


  @Id
  @Column(name = "ID_ODE_TIERS_JOUR")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ODE_TIERS_JOUR_SQ")
  @SequenceGenerator(name = "ODE_TIERS_JOUR_SQ", sequenceName = "ODE_TIERS_JOUR_SQ",
      allocationSize = 1, initialValue = 1)
  private long idOdeTiersJour;


  @Column(name = "NOT_SIREN_NUM_SIREN")
  private String numeroSiren;

  @Column(name = "NOT_RAIS_SOC")
  private String raisonSociale;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DT_CREATION")
  private Date dateCreation;

  @Column(name = "NOT_TYPE_TIERS")
  private String codeTypeTiersClient;

  @Column(name = "NOT_ADR_TIERS")
  private String adresse;

  @Column(name = "NOT_CP_TIERS")
  private String codePostal;

  @Column(name = "NOT_PAYS_TIERS")
  private String pays;

  @Column(name = "NOT_ID_RCT")
  private String refSG;

  @Column(name = "NOT_CTR_RCT")
  private String codeTiersReglementaire;

  @Column(name = "NOT_CODE_SECTEUR_CLIENT")
  private String secteurSuivi;

  @Column(name = "NOT_LIB_SSC")
  private String libelleSecteurSuivi;

  @Column(name = "NOT_SOURCE_SSC")
  private String sourceSecteurSuivi;

  @Column(name = "NOT_CD_NAF")
  private String codeNaf;

  @Column(name = "NOT_SOURCE_NAF")
  private String sourceCodeNaf;

  @Column(name = "NOT_COD_AGENT_ECO")
  private String codeAgentEconomique;

  @Column(name = "NOT_CAT_JUR")
  private String categorieJuridique;

  @Column(name = "NOT_QUAL_AFF_PRTFEUILLE_TRANS")
  private String codePortefeuilleCompta;

  @Column(name = "NOT_SOURCE_CAT_JUR")
  private String sourceCategorieJuridique;

  @Column(name = "NOT_TYPE_SEGMENTATION")
  private String typeSegmentation;

  @Column(name = "NOT_CODE_CAT_TIERS_REG")
  private String categorieTiersReglementaire;

  @Column(name = "NOT_EFFECTIF")
  private String effectif;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DATE_REF_EFF")
  private Date dateReferenceEffectif;

  @Column(name = "NOT_SOURCE_EFF")
  private String sourceReferenceEffectif;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DATE_REF_CA")
  private Date dateCA;

  @Column(name = "NOT_MONTANT_CA_MNT")
  private BigDecimal montantCA;

  @Column(name = "NOT_DEVISE_CA")
  private String devise;

  @Column(name = "NOT_SOURCE_CA")
  private String sourceReferenceCA;

  @Column(name = "NOT_COTE_ACTIVITE")
  private String coteActivite;

  @Column(name = "NOT_COTE_CREDIT")
  private String coteCredit;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_CBDF_ENT_DT_COT")
  private Date dateRevision;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_COTE_BDF_DATE")
  private Date dateCotation;

  @Column(name = "NOT_SOURCE_COTE_BDF")
  private String sourceCotation;

  @Column(name = "NOT_SOURCE_NOTE")
  private String origineNote;

  @Column(name = "NOT_NOTE_SG")
  private String noteSG;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DT_NOTATION")
  private Date dateNotation;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DT_VALIDITE")
  private Date dateValidite;

  @Column(name = "NOT_TYPE_MOD_PD")
  private String typeProcessusNotation;

  @Column(name = "NOT_VERSION_MOTEUR")
  private String versionMoteur;

  @Column(name = "NOT_COTE_ELLIPRO")
  private String scoreELLIPRO;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DT_COTE_ELLIPRO")
  private Date dateScoreELLIPRO;

  @Column(name = "NOT_SOURCE_COTE_ELLIPRO")
  private String sourceScoreELLIPRO;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DATE_MISE_REL")
  private Date datePremiereMel;

  @Column(name = "STATUT_TIERS")
  private String statutTiers;

  @Column(name = "TVA_INTERCOMM")
  private String idTVAIntercommunautaire;

  @Column(name = "PAYS_OUV_CPT")
  private String paysOuvertureCompte;

  @Column(name = "PAYS_IMMA")
  private String paysImmatriculationTiers;

  @Column(name = "PAYS_GOUV")
  private String paysGouvernementTiers;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DATE_EXPORT")
  private Date dateExport;

  @Column(name = "NOT_VERSION_FLUX")
  private String versionFlux;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "DATE_INSERT")
  private Date dateInsertion;
  
  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.TIMESTAMP_FORMAT,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DATE_INTERRO_TIERS")
  private Date horodateEnrichissementDecision;

  @Column(name = "NOT_VILLE_TIERS")
  private String ville;

  @Column(name = "NOT_CODE_SEG_BDF")
  private String codeSegment;

  @OneToMany(mappedBy = "odeTierJour", cascade = CascadeType.ALL)
  private List<OdeDirigeantActionnaire> odeDirigeantsActionnaires;

  public long getIdOdeTiersJour() {
    return idOdeTiersJour;
  }

  public void setIdOdeTiersJour(long idOdeTiersJour) {
    this.idOdeTiersJour = idOdeTiersJour;
  }

  public String getNumeroSiren() {
    return numeroSiren;
  }

  public void setNumeroSiren(String numeroSiren) {
    this.numeroSiren = numeroSiren;
  }

  public String getRaisonSociale() {
    return raisonSociale;
  }

  public void setRaisonSociale(String raisonSociale) {
    this.raisonSociale = raisonSociale;
  }

  public Date getDateCreation() {
    return dateCreation;
  }

  public void setDateCreation(Date dateCreation) {
    this.dateCreation = dateCreation;
  }

  public String getCodeTypeTiersClient() {
    return codeTypeTiersClient;
  }

  public void setCodeTypeTiersClient(String codeTypeTiersClient) {
    this.codeTypeTiersClient = codeTypeTiersClient;
  }

  public String getAdresse() {
    return adresse;
  }

  public void setAdresse(String adresse) {
    this.adresse = adresse;
  }

  public String getCodePostal() {
    return codePostal;
  }

  public void setCodePostal(String codePostal) {
    this.codePostal = codePostal;
  }

  public String getPays() {
    return pays;
  }

  public void setPays(String pays) {
    this.pays = pays;
  }

  public String getRefSG() {
    return refSG;
  }

  public void setRefSG(String refSG) {
    this.refSG = refSG;
  }

  public String getCodeTiersReglementaire() {
    return codeTiersReglementaire;
  }

  public void setCodeTiersReglementaire(String codeTiersReglementaire) {
    this.codeTiersReglementaire = codeTiersReglementaire;
  }

  public String getSecteurSuivi() {
    return secteurSuivi;
  }

  public void setSecteurSuivi(String secteurSuivi) {
    this.secteurSuivi = secteurSuivi;
  }

  public String getLibelleSecteurSuivi() {
    return libelleSecteurSuivi;
  }

  public void setLibelleSecteurSuivi(String libelleSecteurSuivi) {
    this.libelleSecteurSuivi = libelleSecteurSuivi;
  }

  public String getSourceSecteurSuivi() {
    return sourceSecteurSuivi;
  }

  public void setSourceSecteurSuivi(String sourceSecteurSuivi) {
    this.sourceSecteurSuivi = sourceSecteurSuivi;
  }

  public String getCodeNaf() {
    return codeNaf;
  }

  public void setCodeNaf(String codeNaf) {
    this.codeNaf = codeNaf;
  }

  public String getSourceCodeNaf() {
    return sourceCodeNaf;
  }

  public void setSourceCodeNaf(String sourceCodeNaf) {
    this.sourceCodeNaf = sourceCodeNaf;
  }

  public String getCodeAgentEconomique() {
    return codeAgentEconomique;
  }

  public void setCodeAgentEconomique(String codeAgentEconomique) {
    this.codeAgentEconomique = codeAgentEconomique;
  }

  public String getCategorieJuridique() {
    return categorieJuridique;
  }

  public void setCategorieJuridique(String categorieJuridique) {
    this.categorieJuridique = categorieJuridique;
  }

  public String getCodePortefeuilleCompta() {
    return codePortefeuilleCompta;
  }

  public void setCodePortefeuilleCompta(String codePortefeuilleCompta) {
    this.codePortefeuilleCompta = codePortefeuilleCompta;
  }

  public String getSourceCategorieJuridique() {
    return sourceCategorieJuridique;
  }

  public void setSourceCategorieJuridique(String sourceCategorieJuridique) {
    this.sourceCategorieJuridique = sourceCategorieJuridique;
  }

  public String getTypeSegmentation() {
    return typeSegmentation;
  }

  public void setTypeSegmentation(String typeSegmentation) {
    this.typeSegmentation = typeSegmentation;
  }

  public String getCategorieTiersReglementaire() {
    return categorieTiersReglementaire;
  }

  public void setCategorieTiersReglementaire(String categorieTiersReglementaire) {
    this.categorieTiersReglementaire = categorieTiersReglementaire;
  }

  public String getEffectif() {
    return effectif;
  }

  public void setEffectif(String effectif) {
    this.effectif = effectif;
  }

  public Date getDateReferenceEffectif() {
    return dateReferenceEffectif;
  }

  public void setDateReferenceEffectif(Date dateReferenceEffectif) {
    this.dateReferenceEffectif = dateReferenceEffectif;
  }

  public String getSourceReferenceEffectif() {
    return sourceReferenceEffectif;
  }

  public void setSourceReferenceEffectif(String sourceReferenceEffectif) {
    this.sourceReferenceEffectif = sourceReferenceEffectif;
  }

  public Date getDateCA() {
    return dateCA;
  }

  public void setDateCA(Date dateCA) {
    this.dateCA = dateCA;
  }

  public BigDecimal getMontantCA() {
    return montantCA;
  }

  public void setMontantCA(BigDecimal montantCA) {
    this.montantCA = montantCA;
  }

  public String getDevise() {
    return devise;
  }

  public void setDevise(String devise) {
    this.devise = devise;
  }

  public String getSourceReferenceCA() {
    return sourceReferenceCA;
  }

  public void setSourceReferenceCA(String sourceReferenceCA) {
    this.sourceReferenceCA = sourceReferenceCA;
  }

  public String getCoteActivite() {
    return coteActivite;
  }

  public void setCoteActivite(String coteActivite) {
    this.coteActivite = coteActivite;
  }

  public String getCoteCredit() {
    return coteCredit;
  }

  public void setCoteCredit(String coteCredit) {
    this.coteCredit = coteCredit;
  }

  public Date getDateRevision() {
    return dateRevision;
  }

  public void setDateRevision(Date dateRevision) {
    this.dateRevision = dateRevision;
  }

  public Date getDateCotation() {
    return dateCotation;
  }

  public void setDateCotation(Date dateCotation) {
    this.dateCotation = dateCotation;
  }

  public String getSourceCotation() {
    return sourceCotation;
  }

  public void setSourceCotation(String sourceCotation) {
    this.sourceCotation = sourceCotation;
  }

  public String getOrigineNote() {
    return origineNote;
  }

  public void setOrigineNote(String origineNote) {
    this.origineNote = origineNote;
  }

  public String getNoteSG() {
    return noteSG;
  }

  public void setNoteSG(String noteSG) {
    this.noteSG = noteSG;
  }

  public Date getDateNotation() {
    return dateNotation;
  }

  public void setDateNotation(Date dateNotation) {
    this.dateNotation = dateNotation;
  }

  public Date getDateValidite() {
    return dateValidite;
  }

  public void setDateValidite(Date dateValidite) {
    this.dateValidite = dateValidite;
  }

  public String getTypeProcessusNotation() {
    return typeProcessusNotation;
  }

  public void setTypeProcessusNotation(String typeProcessusNotation) {
    this.typeProcessusNotation = typeProcessusNotation;
  }

  public String getVersionMoteur() {
    return versionMoteur;
  }

  public void setVersionMoteur(String versionMoteur) {
    this.versionMoteur = versionMoteur;
  }


  public String getScoreELLIPRO() {
    return scoreELLIPRO;
  }

  public void setScoreELLIPRO(String scoreELLIPRO) {
    this.scoreELLIPRO = scoreELLIPRO;
  }

  public Date getDateScoreELLIPRO() {
    return dateScoreELLIPRO;
  }

  public void setDateScoreELLIPRO(Date dateScoreELLIPRO) {
    this.dateScoreELLIPRO = dateScoreELLIPRO;
  }

  public String getSourceScoreELLIPRO() {
    return sourceScoreELLIPRO;
  }

  public void setSourceScoreELLIPRO(String sourceScoreELLIPRO) {
    this.sourceScoreELLIPRO = sourceScoreELLIPRO;
  }

  public Date getDatePremiereMel() {
    return datePremiereMel;
  }

  public void setDatePremiereMel(Date datePremiereMel) {
    this.datePremiereMel = datePremiereMel;
  }

  public String getStatutTiers() {
    return statutTiers;
  }

  public void setStatutTiers(String statutTiers) {
    this.statutTiers = statutTiers;
  }

  public String getIdTVAIntercommunautaire() {
    return idTVAIntercommunautaire;
  }

  public void setIdTVAIntercommunautaire(String idTVAIntercommunautaire) {
    this.idTVAIntercommunautaire = idTVAIntercommunautaire;
  }

  public String getPaysOuvertureCompte() {
    return paysOuvertureCompte;
  }

  public void setPaysOuvertureCompte(String paysOuvertureCompte) {
    this.paysOuvertureCompte = paysOuvertureCompte;
  }

  public String getPaysImmatriculationTiers() {
    return paysImmatriculationTiers;
  }

  public void setPaysImmatriculationTiers(String paysImmatriculationTiers) {
    this.paysImmatriculationTiers = paysImmatriculationTiers;
  }

  public String getPaysGouvernementTiers() {
    return paysGouvernementTiers;
  }

  public void setPaysGouvernementTiers(String paysGouvernementTiers) {
    this.paysGouvernementTiers = paysGouvernementTiers;
  }

  public Date getDateExport() {
    return dateExport;
  }

  public void setDateExport(Date dateExport) {
    this.dateExport = dateExport;
  }

  public String getVersionFlux() {
    return versionFlux;
  }

  public void setVersionFlux(String versionFlux) {
    this.versionFlux = versionFlux;
  }

  public Date getDateInsertion() {
    return dateInsertion;
  }

  public void setDateInsertion(Date dateInsertion) {
    this.dateInsertion = dateInsertion;
  }

  public String getVille() {
    return ville;
  }

  public void setVille(String ville) {
    this.ville = ville;
  }

  public String getCodeSegment() {
    return codeSegment;
  }

  public void setCodeSegment(String codeSegment) {
    this.codeSegment = codeSegment;
  }

  public Date getHorodateEnrichissementDecision() {
    return horodateEnrichissementDecision;
  }

  public void setHorodateEnrichissementDecision(Date horodateEnrichissementDecision) {
    this.horodateEnrichissementDecision = horodateEnrichissementDecision;
  }

  public List<OdeDirigeantActionnaire> getOdeDirigeantsActionnaires() {
    return odeDirigeantsActionnaires;
  }

  public void setOdeDirigeantsActionnaires(
      List<OdeDirigeantActionnaire> odeDirigeantsActionnaires) {
    this.odeDirigeantsActionnaires = odeDirigeantsActionnaires;
  }

  @Override
  public String toString() {
    return "OdeTier [idOdeTiersJour=" + idOdeTiersJour + ", numeroSiren=" + numeroSiren
        + ", raisonSociale=" + raisonSociale + ", dateCreation=" + dateCreation
        + ", codeTypeTiersClient=" + codeTypeTiersClient + ", adresse=" + adresse + ", codePostal="
        + codePostal + ", pays=" + pays + ", refSG=" + refSG + ", codeTiersReglementaire="
        + codeTiersReglementaire + ", secteurSuivi=" + secteurSuivi + ", libelleSecteurSuivi="
        + libelleSecteurSuivi + ", sourceSecteurSuivi=" + sourceSecteurSuivi + ", codeNaf="
        + codeNaf + ", sourceCodeNaf=" + sourceCodeNaf + ", codeAgentEconomique="
        + codeAgentEconomique + ", categorieJuridique=" + categorieJuridique
        + ", codePortefeuilleCompta=" + codePortefeuilleCompta + ", sourceCategorieJuridique="
        + sourceCategorieJuridique + ", typeSegmentation=" + typeSegmentation
        + ", categorieTiersReglementaire=" + categorieTiersReglementaire + ", effectif=" + effectif
        + ", dateReferenceEffectif=" + dateReferenceEffectif + ", sourceReferenceEffectif="
        + sourceReferenceEffectif + ", dateCA=" + dateCA + ", montantCA=" + montantCA
        + ", sourceReferenceCA=" + sourceReferenceCA + ", coteActivite=" + coteActivite
        + ", coteCredit=" + coteCredit + ", dateRevision=" + dateRevision + ", dateCotation="
        + dateCotation + ", sourceCotation=" + sourceCotation + ", origineNote=" + origineNote
        + ", noteSG=" + noteSG + ", dateNotation=" + dateNotation + ", dateValidite=" + dateValidite
        + ", typeProcessusNotation=" + typeProcessusNotation + ", versionMoteur=" + versionMoteur
        + ", scoreELLIPRO=" + scoreELLIPRO + ", dateScoreELLIPRO=" + dateScoreELLIPRO
        + ", sourceScoreELLIPRO=" + sourceScoreELLIPRO + ", datePremiereMel=" + datePremiereMel
        + ", statutTiers=" + statutTiers + ", idTVAIntercommunautaire=" + idTVAIntercommunautaire
        + ", paysOuvertureCompte=" + paysOuvertureCompte + ", paysImmatriculationTiers="
        + paysImmatriculationTiers + ", paysGouvernementTiers=" + paysGouvernementTiers
        + ", dateExport=" + dateExport + ", versionFlux=" + versionFlux + ", dateInsertion="
        + dateInsertion + ", horodateEnrichissementDecision=" + horodateEnrichissementDecision
        + ", odeDirigeantsActionnaires=" + odeDirigeantsActionnaires + "]";
  }
}

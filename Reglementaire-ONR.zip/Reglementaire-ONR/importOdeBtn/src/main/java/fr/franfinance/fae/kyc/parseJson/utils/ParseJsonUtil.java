package fr.franfinance.fae.kyc.parseJson.utils;

import java.io.File;
import java.io.FileFilter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class ParseJsonUtil {

  /**
   * Parsing Date
   * 
   * @param String
   * @return Date
   */
  public static Date convertStringToDate(String dateInString) {
    SimpleDateFormat formatter =
        new SimpleDateFormat(ParserJsonConstants.DATE_FORMAT, Locale.FRANCE);
    Date date = null;
    try {
      date = formatter.parse(dateInString);
    } catch (ParseException e) {
      e.printStackTrace();
    }
    return date;
  }

  /**
   * Split String to tab
   * 
   * @param String
   * @return String[]
   */
  public static String[] getFileNameInfo(String fileName) {
    return (fileName.lastIndexOf(ParserJsonConstants.SEPARATEUR_POINT) > 0
        ? fileName.substring(0, fileName.lastIndexOf(ParserJsonConstants.SEPARATEUR_POINT))
        : fileName).split(ParserJsonConstants.SEPARATEUR_UNDERSCORE);
  }

  /**
   * Get file path
   * 
   * @param String
   * @return String
   */
  public static String getFilePath(String jsonSourceFolder, String fileName) {
    return jsonSourceFolder + ParserJsonConstants.SEPARATEUR_SLASH + fileName;
  }

  /**
   * Get list files by pattern
   * 
   * @param String
   * @return String
   */
  public static File[] getFilesMatchingPattern(File rootDirectory, String regex) {
    if (!rootDirectory.isDirectory()) {
      throw new IllegalArgumentException(rootDirectory + " is no directory.");
    }
    final Pattern p = Pattern.compile(regex);
    return rootDirectory.listFiles(new FileFilter() {
      @Override
      public boolean accept(File file) {
        return p.matcher(file.getName()).matches();
      }
    });
  }

  /**
   * Get list files by date (today)
   * 
   * @param File[]
   * @return File[]
   */
  public static List<File> getFilesMatchingToday(File[] files) {
    List<File> todayFiles = new ArrayList<>();
    if (files != null && files.length > 0) {
      for (File file : files) {
        LocalDate fileDate =
            convertDateToLocalDate(convertStringToDate(getFileNameInfo(file.getName())[2]));
        if (LocalDate.now().compareTo(fileDate) == 0) {
          todayFiles.add(file);
        }
      }
    }
    return todayFiles;
  }

  /**
   * Convert Date to LocalDate
   * 
   * @param Date
   * @return LocalDate
   */
  public static LocalDate convertDateToLocalDate(Date dateToConvert) {
    return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
  }
}

package fr.franfinance.fae.kyc.parseJson.dao;

import java.util.List;
import fr.franfinance.fae.kyc.parseJson.database.model.*;

public interface JsonDao {
  
  public List<OdeTier> getOdeTier(String jsonFile) throws Exception;

  public List<OdeDemande> getOdeDemande(String jsonFile) throws Exception;

  public List<OdeProduit> getOdeProduit(String jsonFile) throws Exception;

}

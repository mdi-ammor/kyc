package fr.franfinance.fae.kyc.parseJson.database.model;

import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.franfinance.fae.kyc.parseJson.utils.ParserJsonConstants;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "ODE_DIRIGEANT_ACTIONNAIRE")
@JsonIgnoreProperties(ignoreUnknown = true)
public class OdeDirigeantActionnaire implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "ID_ODE_TIERS_LIE")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ODE_TIERS_LIE_SQ")
  @SequenceGenerator(name = "ODE_TIERS_LIE_SQ", sequenceName = "ODE_TIERS_LIE_SQ",
      allocationSize = 1, initialValue = 1)
  private long idOdeTiersLie;

  @Column(name = "NOT_SIREN_NUM_SIREN")
  private String notSirenNumSiren;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "NOT_DATE_INTERRO_TIERS")
  private Date notDateInterroTiers;

  @Column(name = "NATURE_LIEN")
  private String natureLienTiersEtTiersLie;

  @Column(name = "TYPE_TIERS_LIE")
  private String typeTiersLie;

  @Column(name = "NO_ORD")
  private BigDecimal rangTiersLie;

  @Column(name = "CIVILITE")
  private String civilite;

  @Column(name = "NOM_MARITAL")
  private String nomUsage;

  @Column(name = "NOM_NAIS")
  private String nomJF;

  @Column(name = "NOM")
  private String nom;

  @Column(name = "PRENOM")
  private String prenom;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "DATE_NAIS")
  private Date dateNaissance;

  @Column(name = "LIEU_NAIS")
  private String villeNaissance;

  @Column(name = "PAYS_NAIS")
  private String paysNaissance;

  @Column(name = "FONCTION")
  private String fonction;

  @Temporal(TemporalType.DATE)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = ParserJsonConstants.DATE_PATTERN,
      locale = ParserJsonConstants.DATE_LOCALE, timezone = ParserJsonConstants.DATE_TIMEZONE)
  @Column(name = "DATE_FONCTION")
  private Date dateFonction;

  @Column(name = "PCT_DETENTION")
  private BigDecimal pourcentageDetention;

  @Column(name = "RAISON_SOC_ACT")
  private String raisonSociale;

  @Column(name = "NUM_SIREN_ACT")
  private String numeroSiren;

  @Column(name = "TVA_INTERCOMM")
  private String idTVAIntercommunautaire;

  @Column(name = "ADRESSE")
  private String adresse;

  @Column(name = "CODE_POSTAL")
  private String codePostal;

  @Column(name = "PAYS")
  private String pays;

  @Column(name = "VILLE")
  private String ville;

  @Column(name = "SOURCE_TIERS_LIE")
  private String sourceTiersLie;

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_INSERT")
  private Date dateInsertion;

  @ManyToOne
  @JoinColumn(name = "ID_ODE_TIERS_JOUR")
  private OdeTier odeTierJour;

  public long getIdOdeTiersLie() {
    return idOdeTiersLie;
  }

  public void setIdOdeTiersLie(long idOdeTiersLie) {
    this.idOdeTiersLie = idOdeTiersLie;
  }

  public String getNotSirenNumSiren() {
    return notSirenNumSiren;
  }

  public void setNotSirenNumSiren(String notSirenNumSiren) {
    this.notSirenNumSiren = notSirenNumSiren;
  }

  public Date getNotDateInterroTiers() {
    return notDateInterroTiers;
  }

  public void setNotDateInterroTiers(Date notDateInterroTiers) {
    this.notDateInterroTiers = notDateInterroTiers;
  }

  public String getNatureLienTiersEtTiersLie() {
    return natureLienTiersEtTiersLie;
  }

  public void setNatureLienTiersEtTiersLie(String natureLienTiersEtTiersLie) {
    this.natureLienTiersEtTiersLie = natureLienTiersEtTiersLie;
  }

  public String getTypeTiersLie() {
    return typeTiersLie;
  }

  public void setTypeTiersLie(String typeTiersLie) {
    this.typeTiersLie = typeTiersLie;
  }


  public BigDecimal getRangTiersLie() {
    return rangTiersLie;
  }

  public void setRangTiersLie(BigDecimal rangTiersLie) {
    this.rangTiersLie = rangTiersLie;
  }

  public String getCivilite() {
    return civilite;
  }

  public void setCivilite(String civilite) {
    this.civilite = civilite;
  }

  public String getNomUsage() {
    return nomUsage;
  }

  public void setNomUsage(String nomUsage) {
    this.nomUsage = nomUsage;
  }

  public String getNomJF() {
    return nomJF;
  }

  public void setNomJF(String nomJF) {
    this.nomJF = nomJF;
  }

  public String getNom() {
    return nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }

  public String getPrenom() {
    return prenom;
  }

  public void setPrenom(String prenom) {
    this.prenom = prenom;
  }

  public Date getDateNaissance() {
    return dateNaissance;
  }

  public void setDateNaissance(Date dateNaissance) {
    this.dateNaissance = dateNaissance;
  }

  public String getVilleNaissance() {
    return villeNaissance;
  }

  public void setVilleNaissance(String villeNaissance) {
    this.villeNaissance = villeNaissance;
  }

  public String getPaysNaissance() {
    return paysNaissance;
  }

  public void setPaysNaissance(String paysNaissance) {
    this.paysNaissance = paysNaissance;
  }

  public String getFonction() {
    return fonction;
  }

  public void setFonction(String fonction) {
    this.fonction = fonction;
  }

  public Date getDateFonction() {
    return dateFonction;
  }

  public void setDateFonction(Date dateFonction) {
    this.dateFonction = dateFonction;
  }

  public BigDecimal getPourcentageDetention() {
    return pourcentageDetention;
  }

  public void setPourcentageDetention(BigDecimal pourcentageDetention) {
    this.pourcentageDetention = pourcentageDetention;
  }

  public String getRaisonSociale() {
    return raisonSociale;
  }

  public void setRaisonSociale(String raisonSociale) {
    this.raisonSociale = raisonSociale;
  }

  public String getNumeroSiren() {
    return numeroSiren;
  }

  public void setNumeroSiren(String numeroSiren) {
    this.numeroSiren = numeroSiren;
  }

  public String getIdTVAIntercommunautaire() {
    return idTVAIntercommunautaire;
  }

  public void setIdTVAIntercommunautaire(String idTVAIntercommunautaire) {
    this.idTVAIntercommunautaire = idTVAIntercommunautaire;
  }

  public String getAdresse() {
    return adresse;
  }

  public void setAdresse(String adresse) {
    this.adresse = adresse;
  }

  public String getCodePostal() {
    return codePostal;
  }

  public void setCodePostal(String codePostal) {
    this.codePostal = codePostal;
  }

  public String getPays() {
    return pays;
  }

  public void setPays(String pays) {
    this.pays = pays;
  }


  public String getVille() {
    return ville;
  }

  public void setVille(String ville) {
    this.ville = ville;
  }

  public String getSourceTiersLie() {
    return sourceTiersLie;
  }

  public void setSourceTiersLie(String sourceTiersLie) {
    this.sourceTiersLie = sourceTiersLie;
  }

  public Date getDateInsertion() {
    return dateInsertion;
  }

  public void setDateInsertion(Date dateInsertion) {
    this.dateInsertion = dateInsertion;
  }

  public OdeTier getOdeTierJour() {
    return odeTierJour;
  }

  public void setOdeTierJour(OdeTier odeTierJour) {
    this.odeTierJour = odeTierJour;
  }

  @Override
  public String toString() {
    return "OdeDirigeantActionnaire [idOdeTiersLie=" + idOdeTiersLie + ", notSirenNumSiren="
        + notSirenNumSiren + ", notDateInterroTiers=" + notDateInterroTiers
        + ", natureLienTiersEtTiersLie=" + natureLienTiersEtTiersLie + ", typeTiersLie="
        + typeTiersLie + ", rangTiersLie=" + rangTiersLie + ", civilite=" + civilite + ", nomUsage="
        + nomUsage + ", nomJF=" + nomJF + ", nom=" + nom + ", prenom=" + prenom + ", dateNaissance="
        + dateNaissance + ", villeNaissance=" + villeNaissance + ", paysNaissance=" + paysNaissance
        + ", fonction=" + fonction + ", dateFonction=" + dateFonction + ", pourcentageDetention="
        + pourcentageDetention + ", raisonSociale=" + raisonSociale + ", numeroSiren=" + numeroSiren
        + ", idTVAIntercommunautaire=" + idTVAIntercommunautaire + ", adresse=" + adresse
        + ", codePostal=" + codePostal + ", pays=" + pays + ", sourceTiersLie=" + sourceTiersLie
        + ", dateInsertion=" + dateInsertion + "]";
  }
}

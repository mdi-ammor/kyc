package fr.franfinance.fae.kyc.fccr.parseJson.config.bean;

public class UriBeanParseJson {

  private String sourcesJsonPath;

  public String getSourcesJsonPath() {
    return sourcesJsonPath;
  }

  public void setSourcesJsonPath(String sourcesJsonPath) {
    this.sourcesJsonPath = sourcesJsonPath;
  }
}

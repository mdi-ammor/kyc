package fr.franfinance.fae.kyc.fccr.batch.test;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import fr.franfinance.fae.kyc.fccr.batch.config.BatchSpringConfigTest;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataCommun;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataProduit;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;
import fr.franfinance.fae.kyc.fccr.batch.service.SuiviAppelFccrService;
import fr.franfinance.fae.kyc.fccr.batch.util.FccrFaeBatchConstants;
import fr.franfinance.fae.kyc.fccr.batch.util.FccrFaeBatchUtil;
import fr.franfinance.fae.kyc.fccr.batch.ws.rest.client.BatchWsClient;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;


public class SuiviAppelFccrTest {

  private AnnotationConfigApplicationContext context;

  @Autowired
  private SuiviAppelFccrService suiviAppelFccrService;
  
  private BatchWsClient fccrRestfulClientService;

  @Before
  public void initContext() {
    context = new AnnotationConfigApplicationContext(BatchSpringConfigTest.class);
    this.suiviAppelFccrService = context.getBean(SuiviAppelFccrService.class);
    this.fccrRestfulClientService = new BatchWsClient();
  }
  
  @Test
  public void testGetListThirdToProcess() {

    List<SuiviAppelFccr> listResult = suiviAppelFccrService.getAllSuiviAppelList();

    if (listResult != null) {
      assertNotNull(listResult);
    }
  }
  
  @Test
  public void testMappingEntryBtnWs() {
    SuiviAppelFccr suiviAppelFccr = new SuiviAppelFccr();
    suiviAppelFccr.setIdTiersBnot(12345);
    
    FccrDataCommun fccrDataCommun = new FccrDataCommun();
    fccrDataCommun.setIdRct("test id rct");
    suiviAppelFccr.setFccrDataCommun(fccrDataCommun);
    
    List<FccrDataProduit> fccrDataProduitList = new ArrayList<FccrDataProduit>();
    FccrDataProduit fccrDataProduit = new FccrDataProduit();
    fccrDataProduit.setCodeProd("code 1");
    fccrDataProduit.setCodeSousProd("sous code 1");
    fccrDataProduitList.add(fccrDataProduit);
    
    fccrDataProduit = new FccrDataProduit();
    fccrDataProduit.setCodeProd("code 2");
    fccrDataProduit.setCodeSousProd("sous code 2");
    fccrDataProduitList.add(fccrDataProduit);
    
    suiviAppelFccr.setFccrDataProduitList(fccrDataProduitList);
    
    
    ComputeRequest customerRequestExpected = fccrRestfulClientService.convertBtnToComputeRequest(suiviAppelFccr);
    
    assertEquals(customerRequestExpected.getCustomer().getCustomerIdentifier().getRctId(), "test id rct");
    assertEquals(customerRequestExpected.getCustomer().getCustomerIdentifier().getLocalId(), "12345");
    assertEquals(customerRequestExpected.getCustomer().getRating().getRawData().getStockExchanges().get(0), "cotbourse");
    assertEquals(customerRequestExpected.getCustomer().getRating().getRawData().getPrimaryRegulatoryBodies().get(0), "IndAutoregul");
    
    boolean value = customerRequestExpected.getCustomer().getRating().getRawData().getProducts().contains("code 1");
    assertEquals(value, true);
    
    value = customerRequestExpected.getCustomer().getRating().getRawData().getProducts().contains("code 2");
    assertEquals(value, true);
    
    value = customerRequestExpected.getCustomer().getRating().getRawData().getSubFamilies().contains("sous code 1");
    assertEquals(value, true);
    
    value = customerRequestExpected.getCustomer().getRating().getRawData().getSubFamilies().contains("sous code 2");
    assertEquals(value, true);
    
  }

  @Test
  public void testGetToken() {
     
    FccrToken token = fccrRestfulClientService.getToken();
    assertNotNull(token);
  }

  @Test
  public void testComputeBulkRatingsCustomer() {
    try {
      List<SuiviAppelFccr> suiviAppelFccrList = suiviAppelFccrService.getAllSuiviAppelList();
      
      List<SuiviAppelFccr> computeBulkFccrList = FccrFaeBatchUtil.getFiltredList(suiviAppelFccrList, FccrFaeBatchConstants.TYPE_APPEL_WS_COMPUTE);
      assertNotNull(computeBulkFccrList);
//      List<ComputeRequest> listCustomerRequest = new ArrayList<ComputeRequest>();
//      ComputeRequest customerRequest = fccrRestfulClientService.mapEntry(suiviAppelFccr);
//      listCustomerRequest.add(customerRequest);
//      List<CustomerResponse> listComputeResponse = new ArrayList<>();
      //listComputeResponse = fccrRestfulClientService.computeBulkRatingsCustomer(listCustomerRequest, token, uri.getBatchComputeBulkRatingsUri());
    } catch (Exception e) {
      e.printStackTrace();
    }

  }

  
}

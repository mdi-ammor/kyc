/**
 * 
 */
package fr.franfinance.fae.kyc.fccr.batch.config;

import java.util.Properties;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import fr.franfinance.fae.kyc.fccr.batch.config.bean.UriBeanBatch;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataBe;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataCommun;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataProduit;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;

/**
 * @author adeq685
 *
 */

@Configuration
@PropertySources(value = {@PropertySource("classpath:/config/dev/jdbc_test.properties"),
    @PropertySource("classpath:/config/dev/application-${envTarget:dev}.properties")})
@EnableTransactionManagement
@ComponentScans(value = {@ComponentScan("fr.franfinance.fae.kyc.fccr.batch.dao"),
    @ComponentScan("fr.franfinance.fae.kyc.fccr.batch.service"),
    @ComponentScan("fr.franfinance.fae.kyc.fccr.batch.ws.rest.client")})
public class BatchSpringConfigTest {

  @Autowired
  private Environment env;

  @Value("${BATCH_TOKEN_URI}")
  private String batchTokenUri;

  @Value("${BATCH_COMPUTE_BULK_RATINGS_URI}")
  private String batchComputeBulkRatingsUri;

  @Value("${BATCH_Amend_URI}")
  private String batchAmendRatingsUri;

  @Bean
  public DataSource dataSource() {
    BasicDataSource dataSource = new BasicDataSource();
    dataSource.setDriverClassName(env.getProperty("jdbc.driverClassName"));
    dataSource.setUrl(env.getProperty("jdbc.databaseurl"));
    dataSource.setUsername(env.getProperty("jdbc.username"));
    dataSource.setPassword(env.getProperty("jdbc.password"));
    return dataSource;
  }

  @Bean
  public LocalSessionFactoryBean sessionFactory() {
    LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
    sessionFactory.setDataSource(dataSource());
    sessionFactory.setHibernateProperties(additionalProperties());

    sessionFactory.setAnnotatedClasses(SuiviAppelFccr.class, FccrDataBe.class, FccrDataCommun.class,
        FccrDataProduit.class);

    return sessionFactory;
  }

  @Bean
  public HibernateTransactionManager transactionManager() {
    HibernateTransactionManager transactionManager = new HibernateTransactionManager();
    transactionManager.setSessionFactory(sessionFactory().getObject());
    return transactionManager;
  }

  Properties additionalProperties() {
    Properties props = new Properties();
    props.put("hibernate.show_sql", env.getProperty("hibernate.show_sql"));
    // props.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
    return props;
  }

  @Bean
  public UriBeanBatch getUriBean() {
    UriBeanBatch uri = new UriBeanBatch();
    uri.setBatchTokenUri(batchTokenUri);
    uri.setBatchAmendRatingsUri(batchAmendRatingsUri);
    uri.setBatchComputeBulkRatingsUri(batchComputeBulkRatingsUri);

    return uri;
  }

}

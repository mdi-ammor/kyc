package fr.franfinance.fae.kyc.fccr.batch.config;

import java.util.Arrays;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import fr.franfinance.fae.kyc.fccr.batch.config.bean.UriBeanBatch;
import fr.franfinance.fae.kyc.fccr.batch.util.FccrFaeBatchConstants;
import fr.franfinance.fae.kyc.fccr.wsclient.configuration.FccrRestClientConfig;

public final class BatchConfig extends FccrRestClientConfig {

  private static AnnotationConfigApplicationContext context;
  /**
   * 
   * @return a Header with user and basic access authentication informations
   */
  
  public static HttpHeaders createHttpHeaders(String token) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
    headers.add(FccrFaeBatchConstants.HEADER_TOKEN_LIBELLE, token);
    return headers;
  }
  
  public static UriBeanBatch getUriBeanBatch() {
    context = new AnnotationConfigApplicationContext(BatchSpringConfig.class);
    return context.getBean(UriBeanBatch.class);
  }

  
}

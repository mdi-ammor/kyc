package fr.franfinance.fae.kyc.fccr.batch.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "FCCR_DATA_COMMUN")
public class FccrDataCommun implements Serializable {

  private static final long serialVersionUID = -6782442933965958695L;

  private long idFccrDataCommun;
  private String refAppelFccr;
  private long idTiersBnot;
  private String idRct;
  private String raisoc;
  private String siren;
  private String segment;
  private String subsegment;
  private String paysGouv;
  private String paysSouscript;
  private String paysImmat;
  private Date dateDebRel;
  private Date dateCreationEnt;
  private String indAptgouv;
  private String indPpe;
  private String typeEntite;
  private String typeEntiteComment;
  private Long ca;
  private Date dateNoteLab;
  private String noteLab;
  private String modeCalcul;
  private String raisonForcage;
  private String userOriOpe;
  private String oriOpe;
  private String codeNaf;
  private Boolean correspondentBanking;
  private Boolean nestedAccount;

  private SuiviAppelFccr suiviAppelFccr;

  @Id
  @Column(name = "ID_FCCR_DATA_COMMUN")
  public long getIdFccrDataCommun() {
    return idFccrDataCommun;
  }

  public void setIdFccrDataCommun(long idFccrDataCommun) {
    this.idFccrDataCommun = idFccrDataCommun;
  }

  @Column(name = "REF_APPEL_FCCR")
  public String getRefAppelFccr() {
    return refAppelFccr;
  }

  public void setRefAppelFccr(String refAppelFccr) {
    this.refAppelFccr = refAppelFccr;
  }

  @Column(name = "ID_TIERS_BNOT")
  public long getIdTiersBnot() {
    return idTiersBnot;
  }

  public void setIdTiersBnot(long idTiersBnot) {
    this.idTiersBnot = idTiersBnot;
  }

  @Column(name = "ID_RCT")
  public String getIdRct() {
    return idRct;
  }

  public void setIdRct(String idRct) {
    this.idRct = idRct;
  }

  @Column(name = "RAISOC")
  public String getRaisoc() {
    return raisoc;
  }

  public void setRaisoc(String raisoc) {
    this.raisoc = raisoc;
  }

  @Column(name = "SIREN")
  public String getSiren() {
    return siren;
  }

  public void setSiren(String siren) {
    this.siren = siren;
  }

  @Column(name = "SEGMENT")
  public String getSegment() {
    return segment;
  }

  public void setSegment(String segment) {
    this.segment = segment;
  }

  @Column(name = "SUBSEGMENT")
  public String getSubsegment() {
    return subsegment;
  }

  public void setSubsegment(String subsegment) {
    this.subsegment = subsegment;
  }

  @Column(name = "PAYS_GOUV")
  public String getPaysGouv() {
    return paysGouv;
  }

  public void setPaysGouv(String paysGouv) {
    this.paysGouv = paysGouv;
  }

  @Column(name = "PAYS_SOUSCRIPT")
  public String getPaysSouscript() {
    return paysSouscript;
  }

  public void setPaysSouscript(String paysSouscript) {
    this.paysSouscript = paysSouscript;
  }

  @Column(name = "PAYS_IMMAT")
  public String getPaysImmat() {
    return paysImmat;
  }

  public void setPaysImmat(String paysImmat) {
    this.paysImmat = paysImmat;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_DEB_REL")
  public Date getDateDebRel() {
    return dateDebRel;
  }

  public void setDateDebRel(Date dateDebRel) {
    this.dateDebRel = dateDebRel;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_CREATION_ENT")
  public Date getDateCreationEnt() {
    return dateCreationEnt;
  }

  public void setDateCreationEnt(Date dateCreationEnt) {
    this.dateCreationEnt = dateCreationEnt;
  }

  @Column(name = "IND_APTGOUV")
  public String getIndAptgouv() {
    return indAptgouv;
  }

  public void setIndAptgouv(String indAptgouv) {
    this.indAptgouv = indAptgouv;
  }

  @Column(name = "IND_PPE")
  public String getIndPpe() {
    return indPpe;
  }

  public void setIndPpe(String indPpe) {
    this.indPpe = indPpe;
  }

  @Column(name = "TYPE_ENTITE")
  public String getTypeEntite() {
    return typeEntite;
  }

  public void setTypeEntite(String typeEntite) {
    this.typeEntite = typeEntite;
  }

  @Column(name = "TYPE_ENTITE_COMMENT")
  public String getTypeEntiteComment() {
    return typeEntiteComment;
  }

  public void setTypeEntiteComment(String typeEntiteComment) {
    this.typeEntiteComment = typeEntiteComment;
  }

  @Column(name = "CA", nullable = true)
  public Long getCa() {
    return ca;
  }

  public void setCa(Long ca) {
    this.ca = ca;
  }

  @Column(name = "DATE_NOTE_LAB")
  public Date getDateNoteLab() {
    return dateNoteLab;
  }

  public void setDateNoteLab(Date dateNoteLab) {
    this.dateNoteLab = dateNoteLab;
  }

  @Column(name = "NOTE_LAB")
  public String getNoteLab() {
    return noteLab;
  }

  public void setNoteLab(String noteLab) {
    this.noteLab = noteLab;
  }

  @Column(name = "MODE_CALCUL")
  public String getModeCalcul() {
    return modeCalcul;
  }

  public void setModeCalcul(String modeCalcul) {
    this.modeCalcul = modeCalcul;
  }

  @Column(name = "RAISON_FORCAGE")
  public String getRaisonForcage() {
    return raisonForcage;
  }

  public void setRaisonForcage(String raisonForcage) {
    this.raisonForcage = raisonForcage;
  }

  @Column(name = "USER_ORI_OPE")
  public String getUserOriOpe() {
    return userOriOpe;
  }

  public void setUserOriOpe(String userOriOpe) {
    this.userOriOpe = userOriOpe;
  }

  @Column(name = "ORI_OPE")
  public String getOriOpe() {
    return oriOpe;
  }

  public void setOriOpe(String oriOpe) {
    this.oriOpe = oriOpe;
  }

  @Column(name = "CODE_NAF")
  public String getCodeNaf() {
    return codeNaf;
  }

  public void setCodeNaf(String codeNaf) {
    this.codeNaf = codeNaf;
  }

  @Column(name = "CORRESP_BANK")
  public Boolean getCorrespondentBanking() {
    return correspondentBanking;
  }

  public void setCorrespondentBanking(Boolean correspondentBanking) {
    this.correspondentBanking = correspondentBanking;
  }

  @Column(name = "CPT_NICHE")
  public Boolean getNestedAccount() {
    return nestedAccount;
  }

  public void setNestedAccount(Boolean nestedAccount) {
    this.nestedAccount = nestedAccount;
  }

  @OneToOne
  @JoinColumn(name = "REF_APPEL_FCCR", insertable = false, updatable = false)
  public SuiviAppelFccr getSuiviAppelFccr() {
    return suiviAppelFccr;
  }

  public void setSuiviAppelFccr(SuiviAppelFccr suiviAppelFccr) {
    this.suiviAppelFccr = suiviAppelFccr;
  }
  
  @Override
  public String toString() {
    return "FccrDataCommun [idFccrDataCommun=" + idFccrDataCommun + ", refAppelFccr=" + refAppelFccr
        + ", idTiersBnot=" + idTiersBnot + ", idRct=" + idRct + ", raisoc=" + raisoc + ", siren="
        + siren + ", segment=" + segment + ", subsegment=" + subsegment + ", paysGouv=" + paysGouv
        + ", paysSouscript=" + paysSouscript + ", paysImmat=" + paysImmat + ", dateDebRel="
        + dateDebRel + ", dateCreationEnt=" + dateCreationEnt + ", indAptgouv=" + indAptgouv
        + ", indPpe=" + indPpe + ", typeEntite=" + typeEntite + ", typeEntiteComment="
        + typeEntiteComment + ", ca=" + ca + ", dateNoteLab=" + dateNoteLab + ", noteLab=" + noteLab
        + ", modeCalcul=" + modeCalcul + ", raisonForcage=" + raisonForcage + ", userOriOpe="
        + userOriOpe + ", oriOpe=" + oriOpe + ", codeNaf=" + codeNaf + "]";
  }
}

/**
 * 
 */
package fr.franfinance.fae.kyc.fccr.batch.application;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import fr.franfinance.fae.kyc.fccr.batch.config.BatchSpringConfig;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;
import fr.franfinance.fae.kyc.fccr.batch.service.SuiviAppelFccrService;
import fr.franfinance.fae.kyc.fccr.batch.util.FccrFaeBatchConstants;
import fr.franfinance.fae.kyc.fccr.batch.util.FccrFaeBatchUtil;
import fr.franfinance.fae.kyc.fccr.batch.ws.rest.client.BatchWsClient;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.AmendRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;

/**
 * @author adeq685
 *
 */
public class BatchApplication {

  public static ApplicationContext context;
  public static BatchWsClient batchClient;

  private static final Logger LOGGER = LoggerFactory.getLogger(BatchApplication.class);


  public static void main(String[] args) {

    LOGGER.info(
        "=========== LANCEMENT DU BATCH FAE FCCR ===================================================");

    LOGGER.info(
        "============= INIT BATCH ==================================================================");
    batchClient = new BatchWsClient();

    // Initialize spring context and get Service bean
    context = new AnnotationConfigApplicationContext(BatchSpringConfig.class);
    SuiviAppelFccrService suiviAppelFccrService = context.getBean(SuiviAppelFccrService.class);
    
    // Get list SuiviAppelFccr a traiter
    List<SuiviAppelFccr> suiviAppelFccrList = suiviAppelFccrService.getAllSuiviAppelList();

    LOGGER.info("============= FIN INIT BATCH ============");

    LOGGER.info("============= APPEL GET TOKEN ============");
    // Get token
    FccrToken fccrToken = getToken();

    LOGGER.info("============= FIN APPEL GET TOKEN ============");

    LOGGER.info("============= DEBUT COMPUTE BULK ============");
    // Call compute Bulk method
    computeBulk(suiviAppelFccrList, fccrToken);
    LOGGER.info("============= FIN COMPUTE BULK ============");

    LOGGER.info("============= DEBUT AMEND ============");
    // Call amend method
    amend(suiviAppelFccrList, fccrToken);
    LOGGER.info("============= FIN AMEND ============");

    LOGGER.info("============= FIN DU BATCH FAE FCCR ============");
    // Return OK
    System.exit(0);
  }

  private static FccrToken getToken() {
    FccrToken fccrToken = new FccrToken();
    try {
      // Get Fccr token
      fccrToken = batchClient.getToken();
    } catch (Exception e) {
      LOGGER.error("====== TOKEN ERROR ================ :", e);
      System.exit(1);
    }
    return fccrToken;
  }

  private static void computeBulk(List<SuiviAppelFccr> suiviAppelFccrList, FccrToken fccrToken) {

    // Get list SuiviAppelFccr compute a traiter
    List<SuiviAppelFccr> suiviAppelInputList = FccrFaeBatchUtil.getFiltredList(suiviAppelFccrList,
        FccrFaeBatchConstants.TYPE_APPEL_WS_COMPUTE);

    LOGGER.info("NOMBRE APPELS COMPUTE :" + suiviAppelInputList.size());
    if (suiviAppelInputList != null && !suiviAppelInputList.isEmpty()) {
      // Prepare compute input (Mapping BTN-WS)
      List<ComputeRequest> computeRequestList =
          batchClient.convertBtnToComputeRequest(suiviAppelInputList);

      // Call computeBulk method
      List<CustomerResponse> computeBulkResponseList = new ArrayList<>();
      try {
        computeBulkResponseList = batchClient.computeBulkRatingsCustomer(computeRequestList,
            FccrClientConstants.TOKEN_BEARER_STRING + fccrToken.getAccessToken());


        // Get computeBulk output (Mapping WS-BTN)
        List<SuiviAppelFccr> suiviAppelFccrResponsetList =
            batchClient.convertCustomerResponseToBtn(computeBulkResponseList, suiviAppelInputList);

        // Update BTN Database
        context.getBean(SuiviAppelFccrService.class)
            .updateSuiviAppelFccr(suiviAppelFccrResponsetList);

      } catch (Exception e) {
        LOGGER.error("====== COMPUTE ERROR ================ :", e);
        System.exit(1);
      }
    }
  }

  private static void amend(List<SuiviAppelFccr> suiviAppelFccrList, FccrToken fccrToken) {

    // Get list SuiviAppelFccr amend a traiter
    List<SuiviAppelFccr> suiviAppelInputList = FccrFaeBatchUtil.getFiltredList(suiviAppelFccrList,
        FccrFaeBatchConstants.TYPE_APPEL_WS_AMEND);

    LOGGER.info("NOMBRE APPELS AMEND :" + suiviAppelInputList.size());
    // Prepare amend input(Mapping BTN-WS)
    if (suiviAppelInputList != null && !suiviAppelInputList.isEmpty()) {
      List<AmendRequest> amendRequestList =
          batchClient.convertBtnToAmendRequest(suiviAppelInputList);

      // Call amend method
      List<CustomerResponse> amendResponseList = new ArrayList<>();
      try {
        for (AmendRequest amendRequest : amendRequestList) {
          CustomerResponse amendResponse = batchClient.amendRatingsCustomer(amendRequest,
              FccrClientConstants.TOKEN_BEARER_STRING + fccrToken.getAccessToken());
          amendResponseList.add(amendResponse);
        }
        // Get amend output (Mapping WS-BTN)
        List<SuiviAppelFccr> suiviAppelFccrResponsetList =
            batchClient.convertCustomerResponseToBtn(amendResponseList, suiviAppelInputList);

        // Update BTN Database
        context.getBean(SuiviAppelFccrService.class)
            .updateSuiviAppelFccr(suiviAppelFccrResponsetList);
      } catch (Exception e) {
        LOGGER.error("====== AMEND ERROR ================ :", e);
        System.exit(1);
      }
    }
  }

}

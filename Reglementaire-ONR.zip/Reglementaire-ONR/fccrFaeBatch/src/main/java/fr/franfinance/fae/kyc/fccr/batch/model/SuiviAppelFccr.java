package fr.franfinance.fae.kyc.fccr.batch.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "SUIVI_APPEL_FCCR")
@DynamicUpdate
public class SuiviAppelFccr implements Serializable {
  private static final long serialVersionUID = -7086533943266223695L;

  private String refAppelFccr;
  private long idTiersBnot;
  private String idTiersFae;
  private Date dateCreationEvent;
  private String typeAppelWs;
  private String modeAppel;
  private Date date1erAppelFccr;
  private Date dateAppelFccr;
  private Date dateRetFccr;
  private String codeRetFccr;
  private String codeStatut;
  private String commentaire;
  private String codeMarche;
  private String codeProd;
  private List<String> codeProduitList;
  private List<String> codeSousProduitList;
  private List<String> placeCotbourseList;
  private List<String> autoregulList;

  private FccrDataCommun fccrDataCommun;
  private FccrDataRet fccrDataRet;

  private List<FccrDataDiver> fccrDataDiverList;
  private List<FccrDataProduit> fccrDataProduitList;
  private List<FccrDataBe> fccrDataBeList;

  @Id
  @Column(name = "REF_APPEL_FCCR")
  public String getRefAppelFccr() {
    return refAppelFccr;
  }

  public void setRefAppelFccr(String refAppelFccr) {
    this.refAppelFccr = refAppelFccr;
  }

  @Column(name = "ID_TIERS_BNOT")
  public long getIdTiersBnot() {
    return idTiersBnot;
  }

  public void setIdTiersBnot(long idTiersBnot) {
    this.idTiersBnot = idTiersBnot;
  }

  @Column(name = "ID_TIERS_FAE")
  public String getIdTiersFae() {
    return idTiersFae;
  }

  public void setIdTiersFae(String idTiersFae) {
    this.idTiersFae = idTiersFae;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_CREATION_EVENT")
  public Date getDateCreationEvent() {
    return dateCreationEvent;
  }

  public void setDateCreationEvent(Date dateCreationEvent) {
    this.dateCreationEvent = dateCreationEvent;
  }

  @Column(name = "TYPE_APPEL_WS")
  public String getTypeAppelWs() {
    return typeAppelWs;
  }

  public void setTypeAppelWs(String typeAppelWs) {
    this.typeAppelWs = typeAppelWs;
  }

  @Column(name = "MODE_APPEL")
  public String getModeAppel() {
    return modeAppel;
  }

  public void setModeAppel(String modeAppel) {
    this.modeAppel = modeAppel;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_APPEL_FCCR")
  public Date getDateAppelFccr() {
    return dateAppelFccr;
  }

  public void setDateAppelFccr(Date dateAppelFccr) {
    this.dateAppelFccr = dateAppelFccr;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_RET_FCCR")
  public Date getDateRetFccr() {
    return dateRetFccr;
  }

  public void setDateRetFccr(Date dateRetFccr) {
    this.dateRetFccr = dateRetFccr;
  }

  @Column(name = "CODE_RET_FCCR")
  public String getCodeRetFccr() {
    return codeRetFccr;
  }

  public void setCodeRetFccr(String codeRetFccr) {
    this.codeRetFccr = codeRetFccr;
  }

  @Column(name = "CODE_STATUT")
  public String getCodeStatut() {
    return codeStatut;
  }

  public void setCodeStatut(String codeStatut) {
    this.codeStatut = codeStatut;
  }

  @Column(name = "COMMENTAIRE")
  public String getCommentaire() {
    return commentaire;
  }

  public void setCommentaire(String commentaire) {
    this.commentaire = commentaire;
  }

  @Column(name = "CODE_MARCHE")
  public String getCodeMarche() {
    return codeMarche;
  }

  public void setCodeMarche(String codeMarche) {
    this.codeMarche = codeMarche;
  }

  @Column(name = "CODE_PROD")
  public String getCodeProd() {
    return codeProd;
  }

  public void setCodeProd(String codeProd) {
    this.codeProd = codeProd;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_1ER_APPEL_FCCR")
  public Date getDate1erAppelFccr() {
    return date1erAppelFccr;
  }

  public void setDate1erAppelFccr(Date date1erAppelFccr) {
    this.date1erAppelFccr = date1erAppelFccr;
  }

  @OneToOne(mappedBy = "suiviAppelFccr", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  public FccrDataCommun getFccrDataCommun() {
    return fccrDataCommun;
  }

  public void setFccrDataCommun(FccrDataCommun fccrDataCommun) {
    this.fccrDataCommun = fccrDataCommun;
  }

  @OneToOne(mappedBy = "suiviAppelFccr", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  public FccrDataRet getFccrDataRet() {
    return fccrDataRet;
  }

  public void setFccrDataRet(FccrDataRet fccrDataRet) {
    this.fccrDataRet = fccrDataRet;
  }
  
  @OneToMany(mappedBy = "suiviAppelFccr", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @Fetch(value = FetchMode.SUBSELECT)
  public List<FccrDataDiver> getFccrDataDiverList() {
    return fccrDataDiverList;
  }

  public void setFccrDataDiverList(List<FccrDataDiver> fccrDataDiverList) {
    this.fccrDataDiverList = fccrDataDiverList;
  }
  
  @OneToMany(mappedBy = "suiviAppelFccr", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @Fetch(value = FetchMode.SUBSELECT)
  public List<FccrDataBe> getFccrDataBeList() {
    return fccrDataBeList;
  }

  public void setFccrDataBeList(List<FccrDataBe> fccrDataBeList) {
    this.fccrDataBeList = fccrDataBeList;
  }
  
  
  @OneToMany(mappedBy = "suiviAppelFccr", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  public List<FccrDataProduit> getFccrDataProduitList() {
    return fccrDataProduitList;
  }

  public void setFccrDataProduitList(List<FccrDataProduit> fccrDataProduitList) {
    this.fccrDataProduitList = fccrDataProduitList;
  }

  
  
  @Transient
  public List<String> getCodeProduitList() {
    codeProduitList = new ArrayList<String>();
    if (fccrDataProduitList != null && fccrDataProduitList.size() > 0) {
      for (FccrDataProduit produit : fccrDataProduitList) {
        codeProduitList.add(produit.getCodeProd());
      }
    }
    return codeProduitList;
  }

  public void setCodeProduitList(List<String> codeProduitList) {
    this.codeProduitList = codeProduitList;
  }

  @Transient
  public List<String> getCodeSousProduitList() {
    codeSousProduitList = new ArrayList<String>();
    if (fccrDataProduitList != null && fccrDataProduitList.size() > 0) {
      for (FccrDataProduit produit : fccrDataProduitList) {
        codeSousProduitList.add(produit.getCodeSousProd());
      }
    }
    return codeSousProduitList;
  }

  public void setCodeSousProduitList(List<String> codeSousProduitList) {
    this.codeSousProduitList = codeSousProduitList;
  }

  @Transient
  public List<String> getPlaceCotbourseList() {
    placeCotbourseList = new ArrayList<String>();
    if (fccrDataDiverList != null && fccrDataDiverList.size() > 0) {
      for (FccrDataDiver dataDivers : fccrDataDiverList) {
        if (dataDivers.getPlaceCotbourse() != null) {
          placeCotbourseList.add(dataDivers.getPlaceCotbourse());
        }
      }
    }
    return placeCotbourseList;
  }

  public void setPlaceCotbourseList(List<String> placeCotbourseList) {
    this.placeCotbourseList = placeCotbourseList;
  }

  @Transient
  public List<String> getAutoregulList() {
    autoregulList = new ArrayList<String>();
    if (fccrDataDiverList != null && fccrDataDiverList.size() > 0) {
      for (FccrDataDiver dataDivers : fccrDataDiverList) {
        if (dataDivers.getAutoregul() != null) {
          autoregulList.add(dataDivers.getAutoregul());
        }
      }
    }
    return autoregulList;
  }

  public void setAutoregulList(List<String> autoregulList) {
    this.autoregulList = autoregulList;
  }

  @Override
  public String toString() {
    return "SuiviAppelFccr [refAppelFccr=" + refAppelFccr + ", idTiersBnot=" + idTiersBnot
        + ", idTiersFae=" + idTiersFae + ", dateCreationEvent=" + dateCreationEvent
        + ", typeAppelWs=" + typeAppelWs + ", modeAppel=" + modeAppel + ", date1erAppelFccr="
        + date1erAppelFccr + ", dateAppelFccr=" + dateAppelFccr + ", dateRetFccr=" + dateRetFccr
        + ", codeRetFccr=" + codeRetFccr + ", codeStatut=" + codeStatut + ", commentaire="
        + commentaire + ", codeMarche=" + codeMarche + ", codeProd=" + codeProd
        + ", fccrDataCommun=" + fccrDataCommun + ", fccrDataProduitList=" + fccrDataProduitList
        + ", fccrDataRet=" + fccrDataRet + ", codeProduitList=" + codeProduitList
        + ", codeSousProduitList=" + codeSousProduitList + "]";
  }

}

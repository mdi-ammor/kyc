package fr.franfinance.fae.kyc.fccr.batch.ws.rest.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import fr.franfinance.fae.kyc.fccr.batch.application.BatchApplication;
import fr.franfinance.fae.kyc.fccr.batch.config.BatchConfig;
import fr.franfinance.fae.kyc.fccr.batch.config.bean.UriBeanBatch;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataRet;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;
import fr.franfinance.fae.kyc.fccr.batch.util.FccrFaeBatchConstants;
import fr.franfinance.fae.kyc.fccr.batch.util.FccrFaeBatchUtil;
import fr.franfinance.fae.kyc.fccr.wsclient.exception.TechnicalException;
import fr.franfinance.fae.kyc.fccr.wsclient.model.RatingRawData;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.AmendRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.Customer;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;

public class BatchWsClient {

  RestTemplate fccrRestTemplate;
  DozerBeanMapper beanMapperInput;
  DozerBeanMapper beanMapperOutput;
  UriBeanBatch uriBeanBatch;

  private static final Logger LOGGER = LoggerFactory.getLogger(BatchApplication.class);

  public BatchWsClient() {
    fccrRestTemplate = BatchConfig.interceptFccrRestTemplate();
    beanMapperInput =
        new DozerBeanMapper(Arrays.asList(new String[] {FccrFaeBatchConstants.FILE_MAPPING_INPUT}));
    beanMapperOutput = new DozerBeanMapper(
        Arrays.asList(new String[] {FccrFaeBatchConstants.FILE_MAPPING_OUTPUT}));
    uriBeanBatch = BatchConfig.getUriBeanBatch();
  }

  /**
   * 
   * @return token as a fccrToken
   */
  public FccrToken getToken() {
    HttpEntity<FccrToken> request = new HttpEntity<>(new FccrToken());
    FccrToken responseToken =
        fccrRestTemplate.postForObject(uriBeanBatch.getBatchTokenUri(), request, FccrToken.class);
    return responseToken;
  }

  /**
   * 
   * @param customer
   * @return a customer response from ratings COMPUTE_BULK method
   * @throws Exception
   */
  public List<CustomerResponse> computeBulkRatingsCustomer(List<ComputeRequest> computeRequestList,
      String token) throws Exception {
    List<CustomerResponse> response = new ArrayList<CustomerResponse>();
    // add Header and request
    HttpEntity<List<ComputeRequest>> entity =
        new HttpEntity<>(computeRequestList, BatchConfig.createHttpHeaders(token));

    // call FCCR calculator web service - method POST compute bulk ratings
    try {
      ResponseEntity<List<CustomerResponse>> httpResponse =
          fccrRestTemplate.exchange(uriBeanBatch.getBatchComputeBulkRatingsUri(), HttpMethod.POST,
              entity, new ParameterizedTypeReference<List<CustomerResponse>>() {});
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      LOGGER.error("====== COMPUTE ERROR ================ :", e);
      response.add(e.getTechnicalException());
    }
    return response;
  }

  /**
   * 
   * @param customer
   * @return a customer response from ratings AMEND method
   * @throws Exception
   */
  public CustomerResponse amendRatingsCustomer(AmendRequest amendRequest, String token)
      throws Exception {

    CustomerResponse response = new CustomerResponse();
    // add Header and request
    HttpEntity<AmendRequest> entity =
        new HttpEntity<>(amendRequest, BatchConfig.createHttpHeaders(token));

    // call WS calculator web service - method POST amend ratings
    try {
      ResponseEntity<CustomerResponse> httpResponse = fccrRestTemplate
          .postForEntity(uriBeanBatch.getBatchAmendRatingsUri(), entity, CustomerResponse.class);
      response = httpResponse.getBody();
    } catch (TechnicalException e) {
      LOGGER.error("====== AMEND ERROR ================ :", e);
      response = e.getTechnicalException();
    }
    return response;
  }

  /**
   * Mapping BTN-WS
   * 
   * @param List<SuiviAppelFccr>
   * @return List<ComputeRequest>
   */
  public List<ComputeRequest> convertBtnToComputeRequest(List<SuiviAppelFccr> suiviAppelFccrList) {
    List<ComputeRequest> computeCustomerList = new ArrayList<>();
    try {
      for (SuiviAppelFccr suiviAppelFccr : suiviAppelFccrList) {
        computeCustomerList.add(convertBtnToComputeRequest(suiviAppelFccr));
      }
    } catch (Exception e) {
      LOGGER.error("====== COMPUTE MAPPING REQUEST ERROR ================ :", e);
    }
    return computeCustomerList;
  }

  /**
   * Mapping BTN-WS
   * 
   * @param SuiviAppelFccr
   * @return ComputeRequest
   */
  public ComputeRequest convertBtnToComputeRequest(SuiviAppelFccr suiviAppelFccr) {
    ComputeRequest computeCustomer = beanMapperInput.map(suiviAppelFccr, ComputeRequest.class);
    try {
      RatingRawData rawData = computeCustomer.getCustomer().getRating().getRawData();
      // Set localDb
      computeCustomer.getCustomer().getCustomerIdentifier()
          .setLocalDb(FccrFaeBatchConstants.LOCAL_DB);
      // Set country code
      rawData.setAccountOpeningCountryCodes(Arrays.asList(FccrFaeBatchConstants.COUNTRY_CODE));
      // Set country code in customerIdentifier if RCT ID NOT NULL (EREGL-1490)
      if (computeCustomer.getCustomer().getCustomerIdentifier().getRctId() != null) {
        computeCustomer.getCustomer().getCustomerIdentifier()
            .setCountryCode(FccrFaeBatchConstants.COUNTRY_CODE);
      }
      // Set userRatingStatus
      computeCustomer.getCustomer().getRating()
          .setUserRatingStatus(FccrFaeBatchConstants.LIBELLE_VALIDATED);
      // Set Sanctions & negativeNews
      rawData.setSanctions(false);
      rawData.setNegativeNews(false);
      // Set Comments by segment
      if (rawData.getSegment() != null) {
        FccrFaeBatchUtil.getRequestBySegment(computeCustomer);
      }
    } catch (Exception e) {
      LOGGER.error("====== COMPUTE MAPPING REQUEST ERROR ================ :", e);
    }
    return computeCustomer;
  }

  /**
   * Mapping BTN-WS
   * 
   * @param List<SuiviAppelFccr>
   * @return List<AmendRequest>
   */
  public List<AmendRequest> convertBtnToAmendRequest(List<SuiviAppelFccr> suiviAppelFccrList) {
    List<AmendRequest> amendCustomerList = new ArrayList<>();
    for (SuiviAppelFccr suiviAppelFccr : suiviAppelFccrList) {
      try {
        amendCustomerList.add(convertBtnToAmendRequest(suiviAppelFccr));
      } catch (Exception e) {
        LOGGER.error("====== AMEND MAPPING REQUEST ERROR ================ :", e);
      }
    }
    return amendCustomerList;
  }

  /**
   * Mapping BTN-WS
   * 
   * @param SuiviAppelFccr
   * @return AmendRequest
   */
  public AmendRequest convertBtnToAmendRequest(SuiviAppelFccr suiviAppelFccr) {
    AmendRequest amendRequest = new AmendRequest();
    try {
      amendRequest.setLocalId(String.valueOf(suiviAppelFccr.getIdTiersFae()));
      amendRequest.setLocalDb(FccrFaeBatchConstants.LOCAL_DB);
      amendRequest.setFccrRating(suiviAppelFccr.getFccrDataCommun().getNoteLab());
      amendRequest.setFccrRatingComment(suiviAppelFccr.getFccrDataCommun().getRaisonForcage());
    } catch (Exception e) {
      LOGGER.error("====== AMEND MAPPING REQUEST ERROR ================ :", e);
    }
    return amendRequest;

  }

  /**
   * Mapping BTN-WS
   * 
   * @param List<CustomerResponse>
   * @return List<SuiviAppelFccr>
   */
  public List<SuiviAppelFccr> convertCustomerResponseToBtn(
      List<CustomerResponse> customerResponseList, List<SuiviAppelFccr> suiviAppelInputList) {
    List<SuiviAppelFccr> suiviAppelOutputList = new ArrayList<>();
    for (CustomerResponse customerResponse : customerResponseList) {
      try {
        // Get Corresponding suiviAppel from Input List by localId
        if (customerResponse.getCustomer() != null) {
          String localId = customerResponse.getCustomer().getCustomerIdentifier().getLocalId();
          SuiviAppelFccr suiviAppelInput = suiviAppelInputList.stream().filter(suiviAppel -> {
            return localId.equals(String.valueOf(suiviAppel.getIdTiersFae()));
          }).findAny().orElse(null);
          suiviAppelOutputList.add(convertCustomerResponseToBtn(customerResponse, suiviAppelInput));
        }
      } catch (Exception e) {
        LOGGER.error("====== MAPPING RESPONSE ERROR ================ :", e);
      }
    }
    return suiviAppelOutputList;
  }

  /**
   * Mapping WS-BTN
   * 
   * @param CustomerResponse
   * @return SuiviAppelFccr
   */
  public SuiviAppelFccr convertCustomerResponseToBtn(CustomerResponse customerResponse,
      SuiviAppelFccr suiviAppelFccr) {
    try {
      // Setting Status
      suiviAppelFccr.setCodeRetFccr(customerResponse.getStatus());
      String codeStatus = FccrFaeBatchConstants.STATUS_CALCUL_EN_ERREUR;
      Date dateAppelFccr = new Date();
      Customer customer = customerResponse.getCustomer();
      if (FccrClientConstants.SUCCESS_STATUS.equals(customerResponse.getStatus())) {
        codeStatus = FccrFaeBatchConstants.STATUS_CALCUL_OK;
        dateAppelFccr = FccrFaeBatchUtil
            .convertStringToDate(customerResponse.getCustomer().getRating().getDateTime());
        FccrDataRet fccrDataRet = new FccrDataRet();
        // Setting generic fccrDataRet
        fccrDataRet = beanMapperOutput.map(customerResponse, FccrDataRet.class);
        if (customer.getAmendedRating() != null) {
          // Setting fccrDataRet for Amend Response
          fccrDataRet.setFccrRatingType(customer.getAmendedRating().getType());
          fccrDataRet.setAmendFccrrating(customer.getAmendedRating().getResult().getFccrRating());
          dateAppelFccr =
              FccrFaeBatchUtil.convertStringToDate(customer.getAmendedRating().getDateTime());
          fccrDataRet.setAmendFccrratingdatetime(dateAppelFccr);
        }
        fccrDataRet.setSuiviAppelFccr(suiviAppelFccr);
        suiviAppelFccr.setFccrDataRet(fccrDataRet);
      }
      // Setting Code Status
      suiviAppelFccr.setCodeStatut(codeStatus);
      // Setting DateTime
      if (suiviAppelFccr.getDate1erAppelFccr() == null) {
        suiviAppelFccr.setDate1erAppelFccr(dateAppelFccr);
      }
      suiviAppelFccr.setDateAppelFccr(dateAppelFccr);
      suiviAppelFccr.setDateRetFccr(new Date());
      // Setting Errors/Warnings
      if (customerResponse.getErrors() != null && !customerResponse.getErrors().isEmpty()) {
        suiviAppelFccr.setCommentaire(customerResponse.getErrors().toString());
      } else if (customerResponse.getWarnings() != null) {
        suiviAppelFccr.setCommentaire(customerResponse.getWarnings().toString());
      } else {
        suiviAppelFccr.setCommentaire("");
      }
    } catch (Exception e) {
      LOGGER.error("====== MAPPING RESPONSE ERROR ================ :", e);
    }
    return suiviAppelFccr;
  }
}

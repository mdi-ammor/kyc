package fr.franfinance.fae.kyc.fccr.batch.dao;

import java.util.List;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;

public interface SuiviAppelFccrDao {

  public List<SuiviAppelFccr> getAllSuiviAppelList();
  public void updateSuiviAppelFccr(SuiviAppelFccr suiviAppelFccr);
  public void updateSuiviAppelFccr(List<SuiviAppelFccr> suiviAppelFccrList);
}

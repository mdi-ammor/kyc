package fr.franfinance.fae.kyc.fccr.batch.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "FCCR_DATA_PRODUIT")
public class FccrDataProduit implements Serializable {

  private static final long serialVersionUID = -512700081162071454L;

  private String refAppelFccr;
  private long idFccrDataProduit;
  private long idTiersBnot;
  private String codeProd;
  private String codeSousProd;

  private SuiviAppelFccr suiviAppelFccr;

  @Id
  @Column(name = "ID_FCCR_DATA_PRODUIT")
  public long getIdFccrDataProduit() {
    return idFccrDataProduit;
  }

  public void setIdFccrDataProduit(long idFccrDataProduit) {
    this.idFccrDataProduit = idFccrDataProduit;
  }

  @Column(name = "REF_APPEL_FCCR")
  public String getRefAppelFccr() {
    return refAppelFccr;
  }

  public void setRefAppelFccr(String refAppelFccr) {
    this.refAppelFccr = refAppelFccr;
  }


  @Column(name = "ID_TIERS_BNOT")
  public long getIdTiersBnot() {
    return idTiersBnot;
  }

  public void setIdTiersBnot(long idTiersBnot) {
    this.idTiersBnot = idTiersBnot;
  }


  @Column(name = "CODE_PROD")
  public String getCodeProd() {
    return codeProd;
  }

 
  public void setCodeProd(String codeProd) {
    this.codeProd = codeProd;
  }

  @Column(name = "CODE_SOUS_PROD")
  public String getCodeSousProd() {
    return codeSousProd;
  }

  public void setCodeSousProd(String codeSousProd) {
    this.codeSousProd = codeSousProd;
  }

  
  @ManyToOne
  @JoinColumn(name = "REF_APPEL_FCCR", insertable = false, updatable = false)
  public SuiviAppelFccr getSuiviAppelFccr() {
    return suiviAppelFccr;
  }

  public void setSuiviAppelFccr(SuiviAppelFccr suiviAppelFccr) {
    this.suiviAppelFccr = suiviAppelFccr;
  }
  
  @Override
  public String toString() {
    return "FccrDataProduit [refAppelFccr=" + refAppelFccr + ", idFccrDataProduit="
        + idFccrDataProduit + ", idTiersBnotBe=" + idTiersBnot + "]";
  }
  
}

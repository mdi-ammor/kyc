package fr.franfinance.fae.kyc.fccr.batch.dao.impl;

import java.util.List;
import javax.persistence.TypedQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import fr.franfinance.fae.kyc.fccr.batch.dao.SuiviAppelFccrDao;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;
import fr.franfinance.fae.kyc.fccr.batch.util.FccrFaeBatchConstants;

@Repository
public class SuiviAppelFccrDaoImpl implements SuiviAppelFccrDao {

  @Autowired
  private SessionFactory sessionFactory;

  @Override
  public List<SuiviAppelFccr> getAllSuiviAppelList() {
    @SuppressWarnings("unchecked")
    TypedQuery<SuiviAppelFccr> query = sessionFactory.getCurrentSession()
        .createQuery("from SuiviAppelFccr where codeStatut = :codeStatut");
    query.setParameter("codeStatut", FccrFaeBatchConstants.STATUS_A_TRAITER);

    return query.getResultList();

  }

  @Override
  public void updateSuiviAppelFccr(SuiviAppelFccr suiviAppelFccr) {
    sessionFactory.getCurrentSession().update(suiviAppelFccr);
  }

  @Override
  public void updateSuiviAppelFccr(List<SuiviAppelFccr> suiviAppelFccrList) {
    for (SuiviAppelFccr suiviAppelFccr : suiviAppelFccrList) {
      updateSuiviAppelFccr(suiviAppelFccr);
    }
  }
}

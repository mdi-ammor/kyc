package fr.franfinance.fae.kyc.fccr.batch.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;
import fr.franfinance.fae.kyc.fccr.wsclient.model.RatingRawData;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;
public class FccrFaeBatchUtil {

  /**
   * Filtring Input List: Compute/Amend
   * 
   * @param List<SuiviAppelFccr>
   * @return List<SuiviAppelFccr>
   */
  public static List<SuiviAppelFccr> getFiltredList(List<SuiviAppelFccr> suiviAppelFccrList,
      String filter) {

    List<SuiviAppelFccr> filtredFccrList = new ArrayList<SuiviAppelFccr>();

    filtredFccrList = suiviAppelFccrList.stream()
        .filter(suiviAppelFccr -> suiviAppelFccr.getTypeAppelWs().equals(filter))
        .collect(Collectors.toList());
    return filtredFccrList;
  }

  /**
   * Parsing Date
   * 
   * @param String
   * @return Date
   */
  public static Date convertStringToDate(String dateInString) {
    SimpleDateFormat formatter = new SimpleDateFormat(FccrClientConstants.DATE_FORMAT, Locale.FRANCE);
    Date date = null;
    try {
      date = formatter.parse(dateInString);
    } catch (ParseException e) {
      e.printStackTrace();
    }
    return date;
  }

  /**
   * Get request by segment
   * 
   * @param String
   * @return Date
   */
  public static ComputeRequest getRequestBySegment(ComputeRequest computeRequest) {
    RatingRawData rawData = computeRequest.getCustomer().getRating().getRawData();
    switch (rawData.getSegment()) {
      case FccrFaeBatchConstants.SEGMENT_GOV:
        if (notSpecified(rawData.getDateOfCreation())) {
          rawData.setDateOfCreationComment(FccrFaeBatchConstants.LIBELLE_DONNEES_TIERS_NON_DISPO);
        }
        if (notSpecified(rawData.getEntityType())) {
          rawData.setEntityTypeComment(FccrFaeBatchConstants.LIBELLE_DONNEES_TIERS_NON_DISPO);
        }
        break;
      case FccrFaeBatchConstants.SEGMENT_BANK:
        if (notSpecified(rawData.getIndustry())) {
          rawData.setIndustryComment(FccrFaeBatchConstants.LIBELLE_DONNEES_TIERS_NON_DISPO);
        }
        if (notSpecified(rawData.getEntityType())) {
          rawData.setEntityTypeComment(FccrFaeBatchConstants.LIBELLE_DONNEES_TIERS_NON_DISPO);
        }
        break;
      case FccrFaeBatchConstants.SEGMENT_CORPS:
        if (!notSpecified(rawData.getEntityType()) && !notSpecified(rawData.getAnnualTurnover())
            && Double.valueOf(rawData.getAnnualTurnover()) == 0) {
          rawData.setEntityTypeComment(FccrFaeBatchConstants.LIBELLE_DONNEES_TIERS_NON_DISPO);
        }
        break;
    }
    return computeRequest;
  }

  /**
   * Check not Specified field
   * 
   * @param String
   * @return Boolean
   */
  public static Boolean notSpecified(String field) {
    return field == null || field.isEmpty();
  }
}

/**
 * 
 */
package fr.franfinance.fae.kyc.fccr.batch.config;

import java.util.Properties;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import fr.franfinance.fae.kyc.fccr.batch.config.bean.UriBeanBatch;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataBe;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataCommun;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataDiver;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataProduit;
import fr.franfinance.fae.kyc.fccr.batch.model.FccrDataRet;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;
import fr.franfinance.fae.kyc.fccr.batch.util.FccrFaeBatchConstants;

/**
 * @author adeq685
 *
 */

@Configuration
@PropertySources({
    @PropertySource(value = "file:${springConfigPath}/jdbc${envTarget:}.properties",
        ignoreResourceNotFound = true),
    @PropertySource(value = "file:${springConfigPath}/application${envTarget:}.properties",
        ignoreResourceNotFound = true),
    @PropertySource(value = "classpath:../config/jdbc${envTarget:}.properties",
        ignoreResourceNotFound = true),
    @PropertySource(value = "classpath:../config/application${envTarget:}.properties",
        ignoreResourceNotFound = true),
    @PropertySource(value = "classpath:/config/jdbc${envTarget:}.properties",
        ignoreResourceNotFound = true),
    @PropertySource(value = "classpath:/config/application${envTarget:}.properties",
        ignoreResourceNotFound = true)})
@EnableTransactionManagement
@ComponentScans(value = {@ComponentScan("fr.franfinance.fae.kyc.fccr.batch.dao"),
    @ComponentScan("fr.franfinance.fae.kyc.fccr.batch.service")})
public class BatchSpringConfig {

  @Autowired
  private Environment env;

  @Value("${BATCH_TOKEN_URI}")
  private String batchTokenUri;

  @Value("${BATCH_COMPUTE_URI}")
  private String batchComputeUri;

  @Value("${BATCH_COMPUTE_BULK_URI}")
  private String batchComputeBulkRatingsUri;

  @Value("${BATCH_AMEND_URI}")
  private String batchAmendRatingsUri;

  @Bean
  public DataSource getDataSource() {
    BasicDataSource dataSource = new BasicDataSource();
    dataSource.setDriverClassName(env.getProperty(FccrFaeBatchConstants.JDBC_DRIVER_NAME));
    dataSource.setUrl(env.getProperty(FccrFaeBatchConstants.JDBC_URL));
    dataSource.setUsername(env.getProperty(FccrFaeBatchConstants.JDBC_USERNAME));
    dataSource.setPassword(env.getProperty(FccrFaeBatchConstants.JDBC_PASSWORD));
    return dataSource;
  }

  @Bean
  public LocalSessionFactoryBean getSessionFactory() {
    LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
    sessionFactory.setDataSource(getDataSource());
    sessionFactory.setHibernateProperties(additionalProperties());

    sessionFactory.setAnnotatedClasses(SuiviAppelFccr.class, FccrDataCommun.class,
        FccrDataDiver.class, FccrDataProduit.class, FccrDataBe.class, FccrDataRet.class);

    return sessionFactory;
  }

  @Bean
  public HibernateTransactionManager getTransactionManager() {
    HibernateTransactionManager transactionManager = new HibernateTransactionManager();
    transactionManager.setSessionFactory(getSessionFactory().getObject());
    return transactionManager;
  }

  Properties additionalProperties() {
    Properties props = new Properties();
    props.put(FccrFaeBatchConstants.HIBERNATE_SHOW_SQL,
        env.getProperty(FccrFaeBatchConstants.HIBERNATE_SHOW_SQL));
    props.put(FccrFaeBatchConstants.HIBERNATE_HBM_DDL_AUTO,
        env.getProperty(FccrFaeBatchConstants.HIBERNATE_HBM_DDL_AUTO));
    props.put(FccrFaeBatchConstants.HIBERNATE_SCHEMA,
        env.getProperty(FccrFaeBatchConstants.HIBERNATE_SCHEMA));
    return props;
  }

  @Bean
  public UriBeanBatch getUriBean() {
    UriBeanBatch uri = new UriBeanBatch();
    uri.setBatchTokenUri(batchTokenUri);
    uri.setBatchAmendRatingsUri(batchAmendRatingsUri);
    uri.setBatchComputeUri(batchComputeUri);
    uri.setBatchComputeBulkRatingsUri(batchComputeBulkRatingsUri);

    return uri;
  }

}

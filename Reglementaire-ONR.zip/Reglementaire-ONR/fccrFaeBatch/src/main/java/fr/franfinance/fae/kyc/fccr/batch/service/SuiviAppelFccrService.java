package fr.franfinance.fae.kyc.fccr.batch.service;

import java.util.List;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;

public interface SuiviAppelFccrService {

  public List<SuiviAppelFccr> getAllSuiviAppelList();

  public void updateSuiviAppelFccr(List<SuiviAppelFccr> suiviAppelFccrResponsetList);
  
}
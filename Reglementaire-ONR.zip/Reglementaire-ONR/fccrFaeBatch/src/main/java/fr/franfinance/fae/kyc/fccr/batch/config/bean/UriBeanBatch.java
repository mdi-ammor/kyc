package fr.franfinance.fae.kyc.fccr.batch.config.bean;

/**
 * @author adeq709
 *
 */
public class UriBeanBatch {

  private String batchTokenUri;
  private String batchComputeUri;
  private String batchComputeBulkRatingsUri;
  private String batchAmendRatingsUri;

  
  
  public String getBatchComputeUri() {
    return batchComputeUri;
  }

  public void setBatchComputeUri(String batchComputeUri) {
    this.batchComputeUri = batchComputeUri;
  }

  public String getBatchComputeBulkRatingsUri() {
    return batchComputeBulkRatingsUri;
  }

  public void setBatchComputeBulkRatingsUri(String batchComputeBulkRatingsUri) {
    this.batchComputeBulkRatingsUri = batchComputeBulkRatingsUri;
  }

  public String getBatchTokenUri() {
    return batchTokenUri;
  }

  public void setBatchTokenUri(String batchTokenUri) {
    this.batchTokenUri = batchTokenUri;
  }

  public String getBatchAmendRatingsUri() {
    return batchAmendRatingsUri;
  }

  public void setBatchAmendRatingsUri(String batchAmendRatingsUri) {
    this.batchAmendRatingsUri = batchAmendRatingsUri;
  }

}

package fr.franfinance.fae.kyc.fccr.batch.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


@Entity
@Table(name = "FCCR_DATA_DIVERS")
public class FccrDataDiver implements Serializable {
  private static final long serialVersionUID = 1L;
  private long idFccrDataDivers;
  private String autoregul;
  private BigDecimal idTiersBnot;
  private String placeCotbourse;
  private SuiviAppelFccr suiviAppelFccr;


  @Id
  @Column(name = "ID_FCCR_DATA_DIVERS")
  public long getIdFccrDataDivers() {
    return this.idFccrDataDivers;
  }

  public void setIdFccrDataDivers(long idFccrDataDivers) {
    this.idFccrDataDivers = idFccrDataDivers;
  }


  public String getAutoregul() {
    return this.autoregul;
  }

  public void setAutoregul(String autoregul) {
    this.autoregul = autoregul;
  }


  @Column(name = "ID_TIERS_BNOT")
  public BigDecimal getIdTiersBnot() {
    return this.idTiersBnot;
  }

  public void setIdTiersBnot(BigDecimal idTiersBnot) {
    this.idTiersBnot = idTiersBnot;
  }


  @Column(name = "PLACE_COTBOURSE")
  public String getPlaceCotbourse() {
    return this.placeCotbourse;
  }

  public void setPlaceCotbourse(String placeCotbourse) {
    this.placeCotbourse = placeCotbourse;
  }


  @ManyToOne
  @JoinColumn(name = "REF_APPEL_FCCR", insertable = false, updatable = false)
  public SuiviAppelFccr getSuiviAppelFccr() {
    return this.suiviAppelFccr;
  }

  public void setSuiviAppelFccr(SuiviAppelFccr suiviAppelFccr) {
    this.suiviAppelFccr = suiviAppelFccr;
  }

  @Override
  public String toString() {
    return "FccrDataDiver [idFccrDataDivers=" + idFccrDataDivers + ", autoregul=" + autoregul
        + ", idTiersBnot=" + idTiersBnot + ", placeCotbourse=" + placeCotbourse
        + ", suiviAppelFccr=" + suiviAppelFccr + "]";
  }

}

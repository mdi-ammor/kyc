package fr.franfinance.fae.kyc.fccr.batch.util;

public final class FccrFaeBatchConstants {

  public static final String LOCAL_DB = "FRF_FAE";
  public static final String LIBELLE_VALIDATED = "VALIDATED";
  public static final String COUNTRY_CODE = "FR";
  public static final String LIBELLE_DONNEES_TIERS_NON_DISPO =
      "DONNEE TIERS NON DISPONIBLE POUR LE MOMENT";

  public static final String SEGMENT_GOV = "GOV";
  public static final String SEGMENT_BANK = "BANK";
  public static final String SEGMENT_CORPS = "CORP";

  public static final String STATUS_A_TRAITER = "ATRA";
  public static final String STATUS_CALCUL_OK = "CALC";
  public static final String STATUS_CALCUL_EN_ERREUR = "ERR";

  public static final String TYPE_APPEL_WS_AMEND = "AMEND";
  public static final String TYPE_APPEL_WS_COMPUTE = "COMPUTE";
  public static final String HEADER_TOKEN_LIBELLE = "token";
  
  public static final String JDBC_DRIVER_NAME = "jdbc.driverClassName";
  public static final String JDBC_URL = "jdbc.databaseurl";
  public static final String JDBC_USERNAME = "jdbc.username";
  public static final String JDBC_PASSWORD = "jdbc.password";
  
  public static final String HIBERNATE_SHOW_SQL = "hibernate.show_sql";
  public static final String HIBERNATE_HBM_DDL_AUTO = "hibernate.hbm2ddl.auto";
  public static final String HIBERNATE_SCHEMA = "hibernate.default_schema";
  
  public static final String FILE_MAPPING_INPUT = "btn-ws-mapper.xml";
  public static final String FILE_MAPPING_OUTPUT = "ws-btn-mapper.xml";
}

package fr.franfinance.fae.kyc.fccr.batch.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import fr.franfinance.fae.kyc.fccr.batch.dao.SuiviAppelFccrDao;
import fr.franfinance.fae.kyc.fccr.batch.model.SuiviAppelFccr;
import fr.franfinance.fae.kyc.fccr.batch.service.SuiviAppelFccrService;

@Service
public class SuiviAppelFccrServiceImpl implements SuiviAppelFccrService {

  @Autowired
  private SuiviAppelFccrDao suiviAppelFccrDao;

  @Transactional
  public List<SuiviAppelFccr> getAllSuiviAppelList() {
    return suiviAppelFccrDao.getAllSuiviAppelList();
  }
  
  @Transactional
  public void updateSuiviAppelFccr(List<SuiviAppelFccr> suiviAppelFccrResponsetList) {
    suiviAppelFccrDao.updateSuiviAppelFccr(suiviAppelFccrResponsetList);
  }
}

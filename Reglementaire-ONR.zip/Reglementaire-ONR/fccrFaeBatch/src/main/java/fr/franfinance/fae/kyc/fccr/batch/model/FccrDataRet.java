package fr.franfinance.fae.kyc.fccr.batch.model;

import java.io.Serializable;
import javax.persistence.*;
import org.hibernate.annotations.DynamicUpdate;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "FCCR_DATA_RET")
@DynamicUpdate
public class FccrDataRet implements Serializable {
  private static final long serialVersionUID = 1L;
  private long idFccrDataRet;
  private String amendFccrrating;
  private Date amendFccrratingdatetime;
  private String appStockExchange;
  private String businessRelShip;
  private String computeFccrrating;
  private Date computeFccrRatingDatetime;
  private String contractingRisk;
  private String correspBanking;
  private String entityType;
  private String expActivity;
  private String fccrRatingType;
  private String governmentCountry;
  private BigDecimal idCaractTiers;
  private String industry;
  private String localDb;
  private String localId;
  private String localRegId;
  private String modeCalcul;
  private String nestedAccount;
  private String newEnterprise;
  private String pep;
  private String pepGovOwnership;
  private String priRegulBody;
  private String raisonForcage;
  private String registration;
  private String userOriOpe;
  private SuiviAppelFccr suiviAppelFccr;

  @Id
  @Column(name = "ID_FCCR_DATA_RET")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "FCCR_DATA_RET_SQ")
  @SequenceGenerator(name = "FCCR_DATA_RET_SQ", sequenceName = "FCCR_DATA_RET_SQ",
      allocationSize = 1, initialValue = 1)
  public long getIdFccrDataRet() {
    return this.idFccrDataRet;
  }

  public void setIdFccrDataRet(long idFccrDataRet) {
    this.idFccrDataRet = idFccrDataRet;
  }

  @Column(name = "AMEND_FCCRRATING")
  public String getAmendFccrrating() {
    return this.amendFccrrating;
  }

  public void setAmendFccrrating(String amendFccrrating) {
    this.amendFccrrating = amendFccrrating;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "AMEND_FCCRRATINGDATETIME")
  public Date getAmendFccrratingdatetime() {
    return this.amendFccrratingdatetime;
  }

  public void setAmendFccrratingdatetime(Date amendFccrratingdatetime) {
    this.amendFccrratingdatetime = amendFccrratingdatetime;
  }

  @Column(name = "APPSTOCKEXCHANGE")
  public String getAppStockExchange() {
    return appStockExchange;
  }

  public void setAppStockExchange(String appStockExchange) {
    this.appStockExchange = appStockExchange;
  }

  @Column(name = "BUSINESSRELSHIP")
  public String getBusinessRelShip() {
    return businessRelShip;
  }

  public void setBusinessRelShip(String businessRelShip) {
    this.businessRelShip = businessRelShip;
  }

  @Column(name = "COMPUTE_FCCRRATING")
  public String getComputeFccrrating() {
    return this.computeFccrrating;
  }

  public void setComputeFccrrating(String computeFccrrating) {
    this.computeFccrrating = computeFccrrating;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "COMPUTE_FCCRRATINGDATETIME")
  public Date getComputeFccrRatingDatetime() {
    return computeFccrRatingDatetime;
  }

  public void setComputeFccrRatingDatetime(Date computeFccrRatingDatetime) {
    this.computeFccrRatingDatetime = computeFccrRatingDatetime;
  }

  @Column(name = "CONTRACTINGRISK")
  public String getContractingRisk() {
    return contractingRisk;
  }

  public void setContractingRisk(String contractingRisk) {
    this.contractingRisk = contractingRisk;
  }

  @Column(name = "CORRESPBANKING")
  public String getCorrespBanking() {
    return correspBanking;
  }

  public void setCorrespBanking(String correspBanking) {
    this.correspBanking = correspBanking;
  }

  @Column(name = "ENTITYTYPE")
  public String getEntityType() {
    return entityType;
  }

  public void setEntityType(String entityType) {
    this.entityType = entityType;
  }

  @Column(name = "EXPACTIVITY")
  public String getExpActivity() {
    return expActivity;
  }

  public void setExpActivity(String expActivity) {
    this.expActivity = expActivity;
  }

  @Column(name = "FCCRRATINGTYPE")
  public String getFccrRatingType() {
    return fccrRatingType;
  }

  public void setFccrRatingType(String fccrRatingType) {
    this.fccrRatingType = fccrRatingType;
  }

  @Column(name = "GOVERNMENTCOUNTRY")
  public String getGovernmentCountry() {
    return governmentCountry;
  }

  public void setGovernmentCountry(String governmentCountry) {
    this.governmentCountry = governmentCountry;
  }

  @Column(name = "ID_CARACT_TIERS")
  public BigDecimal getIdCaractTiers() {
    return this.idCaractTiers;
  }

  public void setIdCaractTiers(BigDecimal idCaractTiers) {
    this.idCaractTiers = idCaractTiers;
  }

  @Column(name = "INDUSTRY")
  public String getIndustry() {
    return this.industry;
  }

  public void setIndustry(String industry) {
    this.industry = industry;
  }

  @Column(name = "LOCALDB")
  public String getLocalDb() {
    return localDb;
  }

  public void setLocalDb(String localDb) {
    this.localDb = localDb;
  }

  @Column(name = "LOCALID")
  public String getLocalId() {
    return localId;
  }

  public void setLocalId(String localId) {
    this.localId = localId;
  }

  @Column(name = "LOCALREGID")
  public String getLocalRegId() {
    return localRegId;
  }

  public void setModeCalcul(String modeCalcul) {
    this.modeCalcul = modeCalcul;
  }

  @Column(name = "MODE_CALCUL")
  public String getModeCalcul() {
    return this.modeCalcul;
  }

  public void setLocalRegId(String localRegId) {
    this.localRegId = localRegId;
  }

  @Column(name = "NESTEDACCOUNT")
  public String getNestedAccount() {
    return nestedAccount;
  }

  public void setNestedAccount(String nestedAccount) {
    this.nestedAccount = nestedAccount;
  }

  @Column(name = "NEWENTERPRISE")
  public String getNewEnterprise() {
    return newEnterprise;
  }

  public void setNewEnterprise(String newEnterprise) {
    this.newEnterprise = newEnterprise;
  }

  @Column(name = "PEP")
  public String getPep() {
    return this.pep;
  }

  public void setPep(String pep) {
    this.pep = pep;
  }

  @Column(name = "PEPGOVOWNERSHIP")
  public String getPepGovOwnership() {
    return pepGovOwnership;
  }

  public void setPepGovOwnership(String pepGovOwnership) {
    this.pepGovOwnership = pepGovOwnership;
  }

  @Column(name = "PRIREGULBODY")
  public String getPriRegulBody() {
    return priRegulBody;
  }

  public void setPriRegulBody(String priRegulBody) {
    this.priRegulBody = priRegulBody;
  }

  @Column(name = "RAISON_FORCAGE")
  public String getRaisonForcage() {
    return this.raisonForcage;
  }

  public void setRaisonForcage(String raisonForcage) {
    this.raisonForcage = raisonForcage;
  }

  @Column(name = "REGISTRATION")
  public String getRegistration() {
    return this.registration;
  }

  public void setRegistration(String registration) {
    this.registration = registration;
  }

  @Column(name = "USER_ORI_OPE")
  public String getUserOriOpe() {
    return this.userOriOpe;
  }

  public void setUserOriOpe(String userOriOpe) {
    this.userOriOpe = userOriOpe;
  }

  @OneToOne
  @JoinColumn(name = "REF_APPEL_FCCR")
  public SuiviAppelFccr getSuiviAppelFccr() {
    return this.suiviAppelFccr;
  }

  public void setSuiviAppelFccr(SuiviAppelFccr suiviAppelFccr) {
    this.suiviAppelFccr = suiviAppelFccr;
  }

  @Override
  public String toString() {
    return "FccrDataRet [idFccrDataRet=" + idFccrDataRet + ", amendFccrrating=" + amendFccrrating
        + ", amendFccrratingdatetime=" + amendFccrratingdatetime + ", appStockExchange="
        + appStockExchange + ", businessRelShip=" + businessRelShip + ", computeFccrrating="
        + computeFccrrating + ", computeFccrRatingDatetime=" + computeFccrRatingDatetime
        + ", contractingRisk=" + contractingRisk + ", correspBanking=" + correspBanking
        + ", entityType=" + entityType + ", expActivity=" + expActivity + ", fccrRatingType="
        + fccrRatingType + ", governmentCountry=" + governmentCountry + ", idCaractTiers="
        + idCaractTiers + ", industry=" + industry + ", localDb=" + localDb + ", localId=" + localId
        + ", localRegId=" + localRegId + ", modeCalcul=" + modeCalcul + ", nestedAccount="
        + nestedAccount + ", newEnterprise=" + newEnterprise + ", pep=" + pep + ", pepGovOwnership="
        + pepGovOwnership + ", priRegulBody=" + priRegulBody + ", raisonForcage=" + raisonForcage
        + ", registration=" + registration + ", userOriOpe=" + userOriOpe + "]";
  }
}

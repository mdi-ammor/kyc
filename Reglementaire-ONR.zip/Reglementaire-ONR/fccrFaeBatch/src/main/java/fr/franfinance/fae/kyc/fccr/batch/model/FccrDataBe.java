package fr.franfinance.fae.kyc.fccr.batch.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "FCCR_DATA_BE")
public class FccrDataBe implements Serializable {

  private static final long serialVersionUID = -512700081162071454L;

  private String refAppelFccr;
  private long idFccrDataBe;
  private long idTiersBnotBe;
  private String nom;
  private String prenom;
  private Date dateNai;
  private String paysRes;

  private SuiviAppelFccr suiviAppelFccr;

  @Column(name = "REF_APPEL_FCCR")
  public String getRefAppelFccr() {
    return refAppelFccr;
  }

  public void setRefAppelFccr(String refAppelFccr) {
    this.refAppelFccr = refAppelFccr;
  }

  @Id
  @Column(name = "ID_FCCR_DATA_BE")
  public long getIdFccrDataBe() {
    return idFccrDataBe;
  }

  public void setIdFccrDataBe(long idFccrDataBe) {
    this.idFccrDataBe = idFccrDataBe;
  }

  @Column(name = "ID_TIERS_BNOT_BE")
  public long getIdTiersBnotBe() {
    return idTiersBnotBe;
  }

  public void setIdTiersBnotBe(long idTiersBnotBe) {
    this.idTiersBnotBe = idTiersBnotBe;
  }

  @Column(name = "NOM")
  public String getNom() {
    return nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }

  @Column(name = "PRENOM")
  public String getPrenom() {
    return prenom;
  }

  public void setPrenom(String prenom) {
    this.prenom = prenom;
  }

  @Temporal(TemporalType.DATE)
  @Column(name = "DATE_NAIS")
  public Date getDateNai() {
    return dateNai;
  }

  public void setDateNai(Date dateNai) {
    this.dateNai = dateNai;
  }

  @Column(name = "PAYS_RES")
  public String getPaysRes() {
    return paysRes;
  }

  public void setPaysRes(String paysRes) {
    this.paysRes = paysRes;
  }
  
  @ManyToOne
  @JoinColumn(name = "REF_APPEL_FCCR", insertable = false, updatable = false)
  public SuiviAppelFccr getSuiviAppelFccr() {
    return suiviAppelFccr;
  }

  public void setSuiviAppelFccr(SuiviAppelFccr suiviAppelFccr) {
    this.suiviAppelFccr = suiviAppelFccr;
  }

  @Override
  public String toString() {
    return "FccrDataBe [refAppelFccr=" + refAppelFccr + ", idFccrDataBe=" + idFccrDataBe
        + ", idTiersBnotBe=" + idTiersBnotBe + ", nom=" + nom + ", prenom=" + prenom + ", dateNai="
        + dateNai + ", paysRes=" + paysRes + "]";
  }
  
}

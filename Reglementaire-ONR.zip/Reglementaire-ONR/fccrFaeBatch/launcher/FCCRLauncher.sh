#! /bin/ksh
/usr/java8_64/jre/bin/java -DenvTarget=$1 -jar lib/fccrFaeBatch.jar
STATUS=$?
echo $STATUS
exit $STATUS
package fr.franfinance.fae.kyc.fccr.ws.controller;

import java.util.List;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import fr.franfinance.fae.kyc.fccr.wsclient.client.FccrRestfulClient;
import fr.franfinance.fae.kyc.fccr.wsclient.exception.FunctionalException;
import fr.franfinance.fae.kyc.fccr.wsclient.model.CustomerIdentifier;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.AmendFinalRatingDataRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.AmendRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.ComputeRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.FccrRating;
import fr.franfinance.fae.kyc.fccr.wsclient.model.request.FccrRatingRequest;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.Customer;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.CustomerResponse;
import fr.franfinance.fae.kyc.fccr.wsclient.model.response.FccrToken;
import fr.franfinance.fae.kyc.fccr.wsclient.util.FccrClientConstants;

@RestController
@RequestMapping("/")
public class FccrFaeController {
  FccrRestfulClient fccrRestClient = new FccrRestfulClient();

  /**
   * 
   * @return String
   * @throws Exception
   */
  @RequestMapping(value = "/getToken", method = RequestMethod.POST)
  public FccrToken getToken() throws Exception {
    return FccrRestfulClient.getToken();
  }

  /**
   * 
   * @param localDb
   * @param localId
   * @param rctId
   * @param countryCode
   * @param localCountryCode
   * @param ratingStatus
   * @return CustomerResponse
   * @throws Exception
   */
  @RequestMapping(value = "/readRatings", method = RequestMethod.GET)
  public CustomerResponse read(@RequestParam(value = "localDb") String localDb,
      @RequestParam(value = "localId") String localId,
      @RequestParam(value = "rctId", required = false) String rctId,
      @RequestParam(value = "countryCode", required = false) String countryCode,
      @RequestParam(value = "localCountryCode", required = false) String localCountryCode,
      @RequestParam(value = "ratingStatus", required = false) String ratingStatus,
      @RequestHeader(value = "token") String token) throws Exception {

    CustomerResponse response = new CustomerResponse();
    try {
      CustomerIdentifier customerId = new CustomerIdentifier();
      customerId.setLocalId(localId);
      customerId.setLocalDb(localDb);
      customerId.setCountryCode(localCountryCode);
      customerId.setRctId(rctId);
      customerId.setLocalCountryCode(localCountryCode);
      response = fccrRestClient.readRatingsCustomer(customerId, token);
    } catch (FunctionalException e) {
      response = e.getResponse();
    }
    return response;

  }

  /**
   * 
   * @body ComputeRequest
   * @return CustomerResponse
   * @throws Exception
   */
  @RequestMapping(value = "/compute", method = RequestMethod.POST)
  public CustomerResponse compute(@RequestBody ComputeRequest computeCustomer,
      @RequestHeader(value = "token") String token) throws Exception {

    return fccrRestClient.computeRatingsCustomer(computeCustomer, token);
  }

  /**
   * 
   * @body List<ComputeRequest>
   * @return List<CustomerResponse>
   * @throws Exception
   */
  @RequestMapping(value = "/computeBulk", method = RequestMethod.POST)
  public List<CustomerResponse> computeBulk(@RequestBody List<ComputeRequest> computeRequestList,
      @RequestHeader(value = "token") String token) throws Exception {

    return fccrRestClient.computeBulkRatingsCustomer(computeRequestList, token);
  }

  /**
   * 
   * @body AmendRequest (local)
   * @return CustomerResponse
   * @throws Exception
   */
  @RequestMapping(value = "/amend", method = RequestMethod.POST)
  public CustomerResponse amend(@RequestBody AmendRequest amendRequest,
      @RequestHeader(value = "token") String token) throws Exception {
    // read
    CustomerIdentifier customerIdentifier = new CustomerIdentifier();
    customerIdentifier.setLocalId(amendRequest.getLocalId());
    customerIdentifier.setLocalDb(amendRequest.getLocalDb());
    Customer customer = new Customer();
    customer.setCustomerIdentifier(customerIdentifier);
    CustomerResponse amendResponse = new CustomerResponse();
    try {
      CustomerResponse readResponse = fccrRestClient.readRatingsCustomer(customerIdentifier, token);

      if (readResponse.getStatus().equals(FccrClientConstants.SUCCESS_STATUS)) {
        // Check read rating status before launching amend
        String ratingId = readResponse.getCustomer().getRating().getId().toString();
        // amend
        FccrRating fccrRating = new FccrRating();
        fccrRating.setFccrRating(amendRequest.getFccrRating());
        fccrRating.setFccrRatingComment(amendRequest.getFccrRatingComment());

        FccrRatingRequest fccrRatingRequest = new FccrRatingRequest(fccrRating);

        AmendFinalRatingDataRequest fccrAmendRequest = new AmendFinalRatingDataRequest();
        fccrAmendRequest.setAmendedRating(fccrRatingRequest);

        amendResponse = fccrRestClient.amendRatingsCustomer(fccrAmendRequest, ratingId, token);
        // Add Customer to FaeWs amend response in case of failure
        if (amendResponse.getStatus().equals(FccrClientConstants.FAILURE_STATUS)) {
          amendResponse.setCustomer(customer);
        } else {
          amendResponse.getCustomer().setCustomerIdentifier(customerIdentifier);
        }
      } else {
        amendResponse = readResponse;
        amendResponse.setCustomer(customer);
      }
    } catch (FunctionalException e) {
      amendResponse = e.getResponse();
      amendResponse.setCustomer(customer);
    }
    return amendResponse;
  }

}


                         README
                         
               ${project.artifactId} VERSION ${project.version}

  What is it?
  -----------

  ${project.artifactId} is a 100% pure Java application designed to 
  [xxxxx].  It may be used as a highly portable 
  server benchmark as well as multiclient load generator.

  The Latest Version
  ------------------

  Details of the latest version can be found on the  
  Project web site : ${project.url}.

  Requirements
  ------------

  The following requirements exist for running :

   o  Java Interpreter:

      A fully compliant Java 1.4 (or later) Runtime Environment is required.

   o  Optional jars:
   
      If required, these should be placed in the lib directory
   
      JavaMail (activation.jar, mail.jar) - java.sun.com
      JMS (jms.jar) - java.sun.com
      JDBC - available from database supplier
      commons-logging-1.1.1.jar

   o  Java Compiler [OPTIONAL]:

      A Java compiler is not needed since the distribution includes a 
      precompiled java binary archive. 

  Installation Instructions
  -------------------------

  Note that spaces in directory names can cause problems.

  - Release builds
  Unpack the binary archive into a suitable directory structure.
  
  - Nightly builds
  Unpack BOTH the _bin and _lib archives into the SAME directory structure
  
  Running ${project.artifactId}
  --------------
  For Windows  JBoss Server & Websphere server :
  For Windows  Un*x system :
  
  For Windows (2K, XP etc), there are also some other scripts:
  
  Documentation
  -------------
  The documentation as of the date of this release is available at 
 ${project.url}.

  Build instructions
  ------------------

  Please note:
  To avoid unnecessary duplication, the source archives do not contain 
  the source files which are needed to run (for example properties files and scripts).
    
  - Release builds
  Unpack both the binary and source archives into the same directory structure.
  
  - Nightly builds
  Unpack the _src, _bin and _lib archives into the same directory structure.
  
  Any optional jars (see above) should be placed in lib.

  JMeter is built using Maven 2. This will compile and run the unit tests.
  The optional property definition is required if the system does not have 
  a suitable GUI display.
  
  Licensing and legal issues
  --------------------------

  For legal and licensing issues, please look the files:
  LICENSE
  NOTICE

Cryptographic Software Notice
-----------------------------

This distribution may include software that has been designed for use
with cryptographic software. The country in which you currently reside
may have restrictions on the import, possession, use, and/or re-export
to another country, of encryption software. BEFORE using any encryption
software, please check your country's laws, regulations and policies
concerning the import, possession, or use, and re-export of encryption
software, to see if this is permitted. See <http://www.wassenaar.org/>
for more information.

The U.S. Government Department of Commerce, Bureau of Industry and
Security (BIS), has classified this software as Export Commodity
Control Number (ECCN) 5D002.C.1, which includes information security
software using or performing cryptographic functions with asymmetric
algorithms. The form and manner of this Apache Software Foundation
distribution makes it eligible for export under the License Exception
ENC Technology Software Unrestricted (TSU) exception (see the BIS
Export Administration Regulations, Section 740.13) for both object
code and source code.

  Thank you for using ${project.artifactId}.